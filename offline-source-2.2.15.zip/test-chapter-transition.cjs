// A pending galaxy animation must not restore C11 after selecting only C13.
const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
(async()=>{
 const exe=process.platform==='darwin'?'dist/teacher/mac-universal/Universe Teacher.app/Contents/MacOS/Universe Teacher':'dist/teacher/win-unpacked/Universe Teacher.exe';
 const app=await _electron.launch({executablePath:exe,env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-chapter-transition-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.emulateMedia({reducedMotion:'no-preference'});await page.reload();
  await page.waitForFunction(()=>document.querySelector('#labels')?.style.visibility!=='hidden'&&document.querySelector('#space canvas'));
  // Send these UI events in one task so GPU load cannot move the checkbox click
  // past the 900 ms transition and accidentally test an already-entered lesson.
  async function duringEntry(chapters){assert(await page.evaluate(chapters=>{
   document.querySelector('[data-object-id="cosmos-m32"]').click();
   const diving=document.body.classList.contains('diving');document.querySelector('#teacherToggle').click();
   for(const ch of chapters)document.querySelector(`.chapterCheck input[value="${ch}"]`).click();
   document.querySelector('#teacherPanel header button').click();return diving;
  },chapters));}
  // Removing an unrelated chapter also cancels the pending entrance, but keeps
  // the current allowed overview instead of opening an arbitrary lesson.
  await duringEntry([13]);await page.waitForTimeout(1200);
  assert((await page.locator('#location').textContent()).includes('本星系群'));
  assert(!(await page.evaluate(()=>document.body.classList.contains('diving'))));
  await page.locator('#teacherToggle').click();await page.locator('.chapterCheck input[value="13"]').check();await page.locator('#teacherPanel header button').click();
  await duringEntry([11,12]);
  await page.waitForTimeout(1200);await page.waitForFunction(()=>document.querySelector('#labels').style.visibility!=='hidden');
  assert((await page.locator('#location').textContent()).includes('太阳系'));
  await page.keyboard.press('Escape');
  assert((await page.locator('#location').textContent()).includes('太阳系'));assert.deepEqual(errors,[]);
  console.log('PASS: changing unrelated or current chapters during galaxy entry cancels pending navigation and retains the chapter boundary');
 }finally{await app.close();}
})().catch(e=>{console.error(e);process.exit(1);});
