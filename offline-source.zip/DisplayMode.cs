using System;
using System.Runtime.InteropServices;
using System.Reflection;
[assembly: AssemblyTitle("Universe Display Mode")]
[assembly: AssemblyVersion("1.0.1.0")]
internal static class DisplayMode {
 [DllImport("user32.dll", ExactSpelling=true)]
 private static extern int SetDisplayConfig(uint pathCount, IntPtr paths, uint modeCount, IntPtr modes, uint flags);
 [STAThread]
 private static int Main() {
  // SDC_APPLY | SDC_TOPOLOGY_EXTEND. Called only after an explicit slideshow click.
  return SetDisplayConfig(0, IntPtr.Zero, 0, IntPtr.Zero, 0x80 | 0x04);
 }
}
