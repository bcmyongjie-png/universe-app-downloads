import {oceanImpact} from './ocean-impact.js';
import {axialTilts,spinSign,lockMoon} from './celestial-motion.js';
import {loadSceneTexture} from './scene-textures.js';
import * as T from 'three';
import {saturnRings} from './body-art.js';
import {planetNotes,planetStats,teaching} from './teaching-content.js';
import earthURL from './earth.jpg';
const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z);
export function extendJourneys(j){
 j.solar.push(...planetStats.map(p=>({kind:'planet',planet:p[0],zh:p[1],bm:p[2],en:p[3],points:planetNotes[p[0]],source:'新笔记 · 行星特征与比较表'})));
 j.solar.push({kind:'comparison',zh:'行星数据实验室',bm:'Makmal perbandingan planet',en:'Planet comparison lab',points:teaching.comparison,source:'新双语笔记 · 4–7 页'});
 j.solar.push({kind:'conversion',zh:'宇宙距离换算',bm:'Penukaran jarak angkasa',en:'Space distance conversion',points:teaching.conversion,source:'新笔记 · AU 与光年计算'});
 j.earth.push({kind:'locked',zh:'月球同步自转',bm:'Putaran segerak Bulan',en:'Synchronous lunar rotation',points:teaching.locked,source:'新双语笔记 · 8 页'});
 j.visitors.push({kind:'impact',zh:'撞击与海啸',bm:'Impak dan tsunami',en:'Impacts and tsunamis',points:teaching.impact,source:'新笔记 · 撞击、恐龙与海啸题'});
 j.galaxy.push({kind:'sextant',zh:'测量星体高度',bm:'Mengukur altitud bintang',en:'Measuring stellar altitude',points:teaching.sextant,source:'新双语笔记 · 15 页'});
}
function body(w,id,r,x=0,y=0){const m=w.sphere('viz-'+id,r,'#d1d6dd');m.position.set(x,y,0);if(id==='earth'){m.material.dispose();const tx=loadSceneTexture(earthURL,{colorSpace:T.SRGBColorSpace});tx.colorSpace=T.SRGBColorSpace;m.material=new T.MeshPhongMaterial({map:tx});}if(id==='saturn')saturnRings(m,r);return m;}
export function drawNotesScene(w,d){
 if(d.kind==='planet'){
  const m=body(w,d.planet,3.7),tilts=axialTilts;
  const axis=new T.Group();w.root.add(axis);axis.add(m);axis.rotation.z=(tilts[d.planet]||0)*Math.PI/180;
  if(m.material.uniforms?.spin)m.material.uniforms.spin.value=0;
  const indicator=new T.ArrowHelper(V(0,1,0),V(0,-5,0),10,'#8bb5c8',.3,.13);axis.add(indicator);
  const marker=new T.Mesh(new T.SphereGeometry(.1,12,8),new T.MeshBasicMaterial({color:'#fff3bb'}));marker.position.set(0,0,3.76);m.add(marker);
  w.camera.position.set(0,4,23);w.controls.update();return p=>{m.rotation.y=p*Math.PI*2*spinSign(d.planet);};
 }
 if(d.kind==='comparison'){
  const bars=planetStats.map((p,i)=>{const mat=new T.MeshStandardMaterial({color:i<4?'#78c8e8':'#d8ab6a',metalness:.3,roughness:.5});const b=new T.Mesh(new T.BoxGeometry(1.3,1,1.3),mat);b.position.x=(i-3.5)*2.5;w.root.add(b);const m=body(w,p[0],.45,b.position.x);w.label('viz-'+p[0],p[1],m,V(0,1.1,0));return{b,m};});w.camera.position.set(0,10,32);w.controls.update();
  return p=>{const metric=Number(document.querySelector('#compareMetric')?.value||4),mx=Math.max(...planetStats.map(p=>Math.abs(p[metric])));bars.forEach(({b,m},i)=>{const h=Math.abs(planetStats[i][metric])/mx*8*T.MathUtils.smoothstep(p,0,.65);b.scale.y=Math.max(.04,h);b.position.y=h/2-4;m.position.y=h-3.4;});};
 }
 if(d.kind==='conversion'){body(w,'sun',1.2,-8);body(w,'earth',.7,8);const light=w.sphere('viz-photon',.16,'#ffffff',5);const pts=[V(-6,0,0),V(7,0,0)];w.root.add(new T.Line(new T.BufferGeometry().setFromPoints(pts),new T.LineBasicMaterial({color:'#77d2ff'})));return(p,t)=>{light.position.x=-6+p*13;};}
 if(d.kind==='locked'){const e=body(w,'earth',2.4),moon=body(w,'moon',.7);w.orbit(6);const spot=new T.Mesh(new T.SphereGeometry(.15,16,12),new T.MeshBasicMaterial({color:'#ffcb78'}));spot.position.x=-.72;moon.add(spot);moon.material.uniforms.spin.value=0;w.label('viz-moon','同一面朝向地球',moon,V(0,1.6,0));w.camera.position.set(0,13,19);w.controls.update();return(p,t)=>{const a=p*Math.PI*2;lockMoon(moon,a,6);e.rotation.y=a*27.3;};}
 if(d.kind==='impact')return oceanImpact(w);
 if(d.kind==='sextant'){const line=pts=>w.root.add(new T.Line(new T.BufferGeometry().setFromPoints(pts),new T.LineBasicMaterial({color:'#9bbfcb'})));line([V(-7,-3,0),V(8,-3,0)]);const star=w.sphere('viz-star',.25,'#fff3bf',5);const ray=line([V(-7,-3,0),V(5,4,0)]);return p=>{const a=.2+p*.9;star.position.set(-7+14*Math.cos(a),-3+14*Math.sin(a),0);w.root.children.filter(m=>m.isLine)[1].geometry.setFromPoints([V(-7,-3,0),star.position]);document.querySelector('#visualMeasure').textContent='Altitud / Altitude · '+Math.round(a*180/Math.PI)+'°';};}
 return null;
}

