// Keep lessons, video Range requests and audience windows on the network.
// Cache only a small offline notice, never an outdated course or slide deck.
const CACHE='universe-offline-v2';
self.addEventListener('install',e=>e.waitUntil((async()=>{
 const response=await fetch('/offline.html');if(!response.ok)throw new Error('Offline notice unavailable');
 // Hosts may redirect .html to clean URLs. Store a fresh response so that
 // a redirected response cannot make an offline navigation fail.
 const cache=await caches.open(CACHE);await cache.put('/offline.html',new Response(await response.text(),{headers:{'Content-Type':'text/html; charset=utf-8'}}));
 await self.skipWaiting();
})()));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
 const url=new URL(e.request.url);
 if(e.request.method!=='GET'||e.request.mode!=='navigate'||url.origin!==self.location.origin||url.pathname!=='/')return;
 e.respondWith(fetch(e.request).catch(()=>caches.open(CACHE).then(c=>c.match('/offline.html'))));
});
