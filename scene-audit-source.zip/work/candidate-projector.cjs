const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
  const context=await browser.newContext();context.setDefaultTimeout(20000);
  await context.addInitScript(()=>{window.getScreenDetails=undefined;Object.defineProperty(navigator,'platform',{get:()=> 'Win32'});Object.defineProperty(navigator,'userAgentData',{get:()=>undefined});});
  const page=await context.newPage();page.setDefaultTimeout(30000);
  const origin='https://projector-audit.local',handler=require('./native/offline/local-content.cjs').createContentHandler(__dirname+'/vercel-release',origin);await context.route('**/*',async route=>{if(!route.request().url().startsWith(origin))return route.abort();const r=await handler(new Request(route.request().url()));await route.fulfill({status:r.status,headers:Object.fromEntries(r.headers),body:Buffer.from(await r.arrayBuffer())})});await page.goto(origin);
  const click=name=>page.getByRole('button',{name,exact:true}).click();
  await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption({label:'C12 · 行星大小'});await page.locator('#startLesson').click();
  await click('打开本主题考题');await click('查看第 1 张幻灯片');await click('更多放映选项');await click('全屏 / 退出全屏');await page.locator('.slidePresentationDialog').waitFor({state:'visible'});
  async function open(){
   await click('连接投影仪');assert.equal(await page.getByRole('link',{name:'下载 Windows App',exact:true}).getAttribute('href'),'https://universe-science-classroom.vercel.app/#versions');assert((await page.getByRole('link',{name:'打开独立学生画面',exact:true}).getAttribute('href')).includes('audience-window'));const pending=context.waitForEvent('page');await click('打开学生投影窗口');const audience=await pending;
   await audience.waitForFunction(()=>document.querySelector('#screen')?.naturalWidth>0);
   console.log('opened audience');return audience;
  }
  let audience=await open();await audience.getByRole('button',{name:'全屏显示',exact:true}).click();await audience.waitForFunction(()=>!!document.fullscreenElement);let closed=audience.waitForEvent('close');await audience.getByRole('button',{name:'结束投影',exact:true}).click();await closed;console.log('closed audience');await click('关闭投影设置');
  audience=await open();closed=audience.waitForEvent('close');await audience.keyboard.press('Escape').catch(e=>{if(!audience.isClosed())throw e;});await closed;console.log('closed audience');await click('关闭投影设置');
  audience=await open();closed=audience.waitForEvent('close');await click('结束投影');await closed;console.log('closed audience');assert.equal(await page.locator('.projectorSetup').count(),0);
  audience=await open();await click('关闭投影设置');closed=audience.waitForEvent('close');await click('更多放映选项');await click('结束放映');await closed;console.log('closed audience');
  assert.equal(await page.locator('.slidePresentationDialog').count(),0);assert.equal(context.pages().length,1);console.log('PASS: audience exit button, Escape, teacher stop projection, end slideshow, reopen between exits');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
