import * as T from 'three';
import {cometAtmosphere} from './comet-art.js';
import {ellipsePosition} from './orbital-motion.js';

function hitTarget(w,body,id,r){
 const hit=new T.Mesh(new T.SphereGeometry(r,12,8),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));
 hit.userData={id,r};body.add(hit);w.meshes.push(hit);return hit;
}
// Representative teaching events; sizes and orbital time are compressed.
export function addSceneDiscoveries(w,mode){
 if(mode==='galaxy'){
  // One entrance to the full lifecycle; its stages live inside the diagram.
  const star=w.sphere('star',.65,'#d7e6ff',5);star.position.set(-11,1,-10);
  w.addGlow(star,'#d7e6ff',2.6);hitTarget(w,star,'star',1.7);
  w.label('star','恒星的一生',star,new T.Vector3(0,2,0));
  if(w.solarAnchor)hitTarget(w,w.solarAnchor,'enter-solar',2);
 }
 if(mode==='solar'){
  const comet=w.sphere('comet',.18,'#655d53',0);comet.userData.id='discover-comet';
  hitTarget(w,comet,'discover-comet',1.6);
  const tail=cometAtmosphere(w,9);w.label('discover-comet','彗星',comet,new T.Vector3(0,2,0));
  const belt=new T.Object3D();belt.position.set(-18,0,-9);w.root.add(belt);hitTarget(w,belt,'discover-belt',2);w.label('discover-belt','小行星带',belt);
  w.lessonUpdate=()=>{comet.position.set(...ellipsePosition(24,16,.55+w.t*.015));tail.position.copy(comet.position);tail.quaternion.setFromUnitVectors(new T.Vector3(1,0,0),comet.position.clone().normalize());tail.scale.setScalar(T.MathUtils.clamp(15/comet.position.length(),.22,1.6));};
  w.lessonUpdate();
 }
 if(mode==='earth'){
  if(w.station){hitTarget(w,w.station,'station',.9);w.label('station','空间站',w.station,new T.Vector3(0,.7,0));}
  const event=new T.Group();event.position.set(4,0,0);w.root.add(event);
  const anchor=new T.Object3D();anchor.position.set(-5.35,3.72,.65);event.add(anchor);hitTarget(w,anchor,'discover-shower',1.2);w.label('discover-shower','流星雨',anchor,new T.Vector3(-1,0,0));
  const trails=[];
  for(let i=0;i<4;i++){const geo=new T.BufferGeometry().setFromPoints([new T.Vector3(),new T.Vector3()]);const line=new T.Line(geo,new T.LineBasicMaterial({color:'#fff2d6',transparent:true,opacity:0,depthWrite:false}));event.add(line);trails.push(line);}
  w.lessonUpdate=()=>{trails.forEach((line,i)=>{const phase=(w.t*.25+i*.23)%1,a=2.1+phase*.48,r=6.7+i*.07,positions=line.geometry.attributes.position;positions.setXYZ(0,Math.cos(a)*r,Math.sin(a)*r,.65);positions.setXYZ(1,Math.cos(a-.16)*r,Math.sin(a-.16)*r,.65);positions.needsUpdate=true;line.material.opacity=Math.sin(phase*Math.PI);line.geometry.computeBoundingSphere();});};
  w.lessonUpdate();
 }
}
