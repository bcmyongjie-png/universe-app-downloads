# Desktop updates (2.1.1 consent policy)

Install 2.1.1 to enable the choice policy. Older installed clients retain their old behavior until upgraded.

- Windows: electron-updater 6.8.9 checks its edition channel, offers a download choice, verifies the chosen full NSIS download with SHA-512, and installs only on explicit confirmation. Ordinary App exit never installs an update. No forced mid-class restart. The settings button can request an explicit install-and-exit confirmation.
- macOS: checks an edition-specific manifest, offers a download choice and downloads the chosen DMG to the user-data updates directory, verifies byte count and SHA-512, and exposes “Open new installer”. Automatic replacement of the signed App is not enabled without a stable Developer ID signing identity; the user completes the normal macOS installation flow.
- Both: check 30 seconds after launch and every four hours while running, and on reconnect (throttled). No update is downloaded without consent. Checks are quiet and failure does not prevent offline classroom use. A settings status/button supports manual checks. No version downgrades are offered.
- Renderer course requests remain local-only. Windows updater uses its own Electron network session; Mac updater uses main-process fetch. No renderer-provided URL can be downloaded or installed.

Release procedure:

1. Change `package.json`/lockfile to a higher semantic version; rebuild lesson assets with `../prepare-offline.cjs` if content changes. Do not rerun the initial scaffold `../configure-offline.cjs` over the updater implementation.
2. Upload the audited source archive as `offline-source.zip`. The workflow builds both editions on Windows/macOS, runs offline and updater tests, and publishes a versioned release only after both pass.
3. Each release must include `teacher.yml`, `student.yml`, `teacher-mac.json`, `student-mac.json`, and all four installers. The workflow generates them; installer filenames include the version and must remain immutable.
4. The client reads `https://github.com/bcmyongjie-png/universe-app-downloads/releases/latest/download/`. Keep release publication limited to these complete desktop release sets. Never make a release containing only unrelated files the latest release.

Trust: HTTPS GitHub release metadata and its hashes protect transport/content consistency. These Windows builds currently have no Authenticode publisher certificate; macOS builds have ad-hoc signatures, not Developer ID/notarization. The updater does not disable platform security checks.

Tests cover numeric version comparison, wrong-edition/host/size rejection, verified downloads, corrupt or offline failure cleanup, and preservation of existing downloads. Packaged CI tests also check the settings control and the offline failure state before testing every scene/video. An actual end-to-end installed-version replacement is not claimed by these tests.

## Verified release

2.1.0 was published after Windows and macOS jobs passed: https://github.com/bcmyongjie-png/universe-app-downloads/actions/runs/34669818386

The production Windows teacher and student feeds were exercised through the actual NsisUpdater library with a simulated older app version. Both real installers were automatically downloaded, hash-verified and reached the ready state. Installer execution was excluded. Both Mac manifests passed edition/URL validation and their real installer sizes matched. All four production website download buttons and Chromium/WebKit responsive checks passed.

Teacher and student have separate packaged updater cache names (`universe-teacher-offline-updater` and `universe-student-offline-updater`), checked in the Windows packaged tests.

Download website deployment: `dpl_4UXwUrfzoTenbjZVxTuBPge9PfMq` at https://universe-science-classroom.vercel.app/

## Verified consent release 2.1.1

Windows and macOS packaged offline checks passed: https://github.com/bcmyongjie-png/universe-app-downloads/actions/runs/34671368044 . Consent policy tests passed for both platforms. UI tests confirmed Later sends no download/install command and reconnect requests a check. Real production Windows feeds were checked with autoDownload disabled: no download promise or ready event before explicit downloadUpdate; both installers then downloaded and passed hash verification. Mac metadata and file sizes passed validation. Actual installer replacement was not executed by these checks.

All four live download links and Chromium/WebKit responsive checks passed. Website deployment: dpl_jLXPXCZyGoEvih3WS67kXZSjFqDG. Users must install 2.1.1 to enable this consent policy; old installed versions retain old behavior until upgraded.
