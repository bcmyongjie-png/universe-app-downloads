import {learnerTopics,learnerPlanets} from './learner-content.js';
export const planets=[
 {id:'mercury',name:'水星',en:'Mercury',bm:'Utarid',color:'#a79988',size:.48,orbit:8,au:.39,kind:0,desc:'离太阳最近，也是八大行星中最小的一颗。',facts:['岩石行星，表面布满撞击坑。','大气极其稀薄，难以保留热量。','课件记忆点：最近、最小。'],source:'C12 · 第 7、16 页'},
 {id:'venus',name:'金星',en:'Venus',bm:'Zuhrah',color:'#d8aa66',size:.8,orbit:11,au:.72,kind:1,desc:'浓厚的大气，让这颗行星成为炽热的温室。',facts:['大气中含大量二氧化碳，温室效应强。','表面温度在八大行星中最高。','自转方向与地球相反；大小与地球相近。'],source:'C12 · 第 7 页'},
 {id:'earth',name:'地球',en:'Earth',bm:'Bumi',color:'#4c97e5',size:.85,orbit:14,au:1,kind:2,desc:'我们在宇宙中的家。一颗拥有液态水与生命的蓝色星球。',facts:['太阳系由内向外的第三颗行星。','液态水、适宜的温度和大气，为生命提供条件。','自转带来昼夜交替，公转是绕太阳的运动。'],source:'C12 · 第 7、25、28 页'},
 {id:'mars',name:'火星',en:'Mars',bm:'Marikh',color:'#c26641',size:.62,orbit:17,au:1.52,kind:0,desc:'红色的岩石世界，带着两颗小小的天然卫星。',facts:['课件称它为「红色星球」。','拥有两颗天然卫星。','火星轨道外侧到木星轨道内侧，是小行星主带。'],source:'C12 · 第 7 页；C13 · 第 4 页'},
 {id:'jupiter',name:'木星',en:'Jupiter',bm:'Musytari',color:'#c8a080',size:2.15,orbit:24,au:5.2,kind:3,desc:'太阳系最大的行星，云带在巨大的球体上延展。',facts:['八大行星中体积最大。','强大的引力影响附近天体的运动。','观察：自转是绕自己的轴旋转，公转是绕太阳运行。'],source:'C12 · 第 8 页'},
 {id:'saturn',name:'土星',en:'Saturn',bm:'Zuhal',color:'#d3bd8d',size:1.75,orbit:31,au:9.54,kind:3,desc:'明亮的环系，环绕着太阳系第二大的行星。',facts:['八大行星中大小排名第二。','拥有显著的环系统。','可以拖动视角，从侧面和上方观察环。'],source:'C12 · 第 8 页'},
 {id:'uranus',name:'天王星',en:'Uranus',bm:'Uranus',color:'#8bd4d9',size:1.22,orbit:37,au:19.2,kind:4,desc:'一颗仿佛侧躺着旋转的冰巨星。',facts:['八大行星中大小排名第三。','自转轴倾斜接近直角，课件用「接近 90°」帮助记忆。','课件将金星与天王星列为自转方向的特例。'],source:'C12 · 第 8 页'},
 {id:'neptune',name:'海王星',en:'Neptune',bm:'Neptun',color:'#376add',size:1.18,orbit:43,au:30,kind:4,desc:'八大行星的最外一站，一个深蓝色的遥远世界。',facts:['八大行星中离太阳最远。','八大行星中公转周期最长。','距太阳约 30 AU，课件练习换算为 45 亿千米。'],source:'C12 · 第 6、8 页'}
];
export const entries={moon:{name:'月球',en:'The Moon',bm:'Bulan',desc:'地球的天然卫星。靠近观察，可以看见表面明暗不同的区域和撞击坑。',facts:['这里加入月球近景，帮助观察前后距离与三维视差。','地球与月球的大小及距离在此经过艺术化调整。'],source:'扩展观察场景；关联 C12 行星与天然卫星主题'},
 milky:{name:'银河系',en:'The Milky Way',bm:'Bima Sakti',desc:'太阳只是银河系众多恒星中的一颗，而我们的太阳系位于其中一条旋臂的区域。',facts:['星系由大量恒星、气体和尘埃组成。','课件将银河系归入螺旋星系。','课件用约 2,000 亿颗恒星描述它的规模；这是估算值。'],source:'C11 · 第 4 页'},
 spiral:{name:'螺旋星系',en:'Spiral galaxy',bm:'Galaksi berpilin',desc:'从明亮的中心向外舒展的旋臂，是螺旋星系的鲜明特征。',facts:['课件例子：银河系、仙女座星系。','拖动场景，观察盘状结构的厚度。'],source:'C11 · 第 4 页'},
 elliptical:{name:'椭圆星系',en:'Elliptical galaxy',bm:'Galaksi elips',desc:'恒星形成平滑的椭球形分布，没有明显的螺旋臂。',facts:['课件例子：Messier 87。','与螺旋星系对照，观察轮廓及中心分布。'],source:'C11 · 第 4 页'},
 irregular:{name:'不规则星系',en:'Irregular galaxy',bm:'Galaksi tidak seragam',desc:'没有清晰的螺旋或椭圆轮廓，恒星分布呈现不规则结构。',facts:['课件例子：大麦哲伦云、小麦哲伦云。','尝试切换三类星系，比较外形。'],source:'C11 · 第 4 页'},
 sun:{name:'太阳',en:'The Sun',bm:'Matahari',desc:'照亮我们家园的恒星，也是太阳系的中心天体。',facts:['恒星内部的核聚变释放光和热。','八大行星沿各自轨道绕太阳公转。','太阳也是银河系的一颗恒星。'],source:'C11 · 第 4、8、13 页；C12 · 第 7–8 页'},
 asteroid:{name:'小行星带',en:'Asteroid belt',bm:'Jalur asteroid',desc:'在火星与木星的轨道之间，许多岩石天体绕太阳运行。',facts:['小行星主要由岩石与金属构成。','课件例子：Ceres、Pallas、Juno、Vesta。','轨道若与地球轨道接近或相交，才可能产生碰撞风险。'],source:'C13 · 第 4、12、19 页'},
 comet:{name:'彗星',en:'Comet',bm:'Komet',desc:'当冰冷的访客接近太阳，冰升华成气体，尘埃与气体形成彗发和彗尾。',facts:['主要由冰、尘埃及冻结的气体等物质组成。','沿自己的轨道绕太阳运行，课件强调椭圆轨道。','彗尾总体背离太阳。场景演示这一方向关系，尾长为视觉示意。'],source:'C13 · 第 4、24 页'},
 meteor:{name:'流星体 → 流星 → 陨石',en:'Meteoroid → Meteor → Meteorite',bm:'Meteoroid → Meteor → Meteorit',desc:'同一颗太空碎片，在不同阶段有不同名称。点击阶段按钮观察变化。',facts:['在太空：岩石或金属碎片，称为流星体。','进入大气：加热并产生发光轨迹，这种现象称为流星。','未完全烧蚀、落到地表的残留物，称为陨石。'],source:'C13 · 第 3、7 页'},
 nebula:{name:'星云',en:'Nebula',bm:'Nebula',desc:'恒星的故事，从一片气体与尘埃开始。',facts:['星云含尘埃、氢和氦等气体。','引力使物质聚集、收缩，核心温度与压力升高。','核心核聚变开始后，新的恒星发出光与热。'],source:'C11 · 第 8、13、16 页'},
 star:{name:'恒星',en:'Star',bm:'Bintang',desc:'核心的核聚变让恒星闪耀，初始质量影响它未来的演化道路。',facts:['课件以大小、颜色、温度、距离和亮度描述恒星。','表面颜色从红到蓝，整体对应从较低到较高的温度。','看到的亮度与恒星大小、表面温度和距离有关。'],source:'C11 · 第 8、20 页'},
 giant:{name:'红巨星 / 红超巨星',en:'Red giant / Red supergiant',bm:'Raksasa merah / Super raksasa merah',desc:'当核心的氢逐渐耗尽，恒星会进入新的演化阶段，外层可能大幅膨胀。',facts:['中等质量恒星沿红巨星道路演化。','大质量恒星可进入红超巨星阶段。','选择不同初始质量，比较最终留下的天体。'],source:'C11 · 第 8、14–15 页'},
 remnant:{name:'恒星的终点',en:'Stellar remnants',bm:'Kematian bintang',desc:'课件将恒星的终点分成三条简化路线。',facts:['中等质量 → 红巨星 → 白矮星。','大质量 → 红超巨星 → 超新星 → 中子星。','更大质量 → 红超巨星 → 超新星 → 黑洞。实际结局还受质量损失等因素影响。'],source:'C11 · 第 8、10、13 页'}
};
export const quizzes=[
{q:'太阳系位于哪一个星系？',options:['仙女座星系','银河系','小麦哲伦云'],a:1,why:'太阳也是银河系众多恒星中的一颗。',source:'C11 · 第 4 页'},
{q:'星云中的气体与尘埃，主要在什么作用下聚集？',options:['引力','声音','反射光'],a:0,why:'引力把气体拉在一起，中心变得更紧、更热。',source:'C11 · 第 16 页'},
{q:'以下哪种恒星表面颜色对应更高的温度？',options:['红色','黄色','蓝色'],a:2,why:'课件的颜色顺序中，红色较冷，蓝色较热。',source:'C11 · 第 20 页'},
{q:'1 AU 表示什么？',options:['光传播一年的时间','地球与太阳的平均距离','太阳的直径'],a:1,why:'课件取 1 AU ≈ 1.5 × 10⁸ km。光年也是距离单位。',source:'C12 · 第 4 页'},
{q:'小行星主带在哪里？',options:['水星与金星之间','地球与火星之间','火星与木星之间'],a:2,why:'主带位于火星和木星的轨道之间。',source:'C13 · 第 4 页'},
{q:'太空碎片落到地面后，叫什么？',options:['流星体','流星','陨石'],a:2,why:'太空中叫流星体，发光轨迹叫流星，掉到地面的固体叫陨石。',source:'C13 · 第 7 页'}
];

// Object close-ups use the same age-appropriate explanations as lesson panels.
const plain=s=>s.replace(/\*\*/g,'');
for(const planet of planets){const points=learnerPlanets[planet.id];planet.desc=plain(points[0][2]);planet.facts=points.map(p=>plain(p[2]));}
const entryTopics={moon:'moons',milky:'galaxy-0',spiral:'galaxy-0',elliptical:'galaxy-1',irregular:'galaxy-2',sun:'fusion',asteroid:'belt',comet:'comet',meteor:'meteor',nebula:'birth',star:'starsize',giant:'giant',remnant:'remnants'};
for(const [key,topic] of Object.entries(entryTopics)){if(entries[key]){entries[key].desc=plain(learnerTopics[topic][0][2]);entries[key].facts=learnerTopics[topic].map(p=>plain(p[2]));}}

