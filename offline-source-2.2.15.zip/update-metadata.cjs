const fs=require('fs'),crypto=require('crypto'),path=require('path');
const version=require('./package.json').version;
const manifests=['Teacher','Student'].map(label=>{
 const edition=label.toLowerCase(),dir=path.join('dist',edition),name=`Universe-${label}-Offline-${version}-Mac.dmg`;
 // Read both exact-version packages before changing either update feed.
 const file=fs.readFileSync(path.join(dir,name));
 return {destination:path.join(dir,edition+'-mac.json'),metadata:{edition,version,size:file.length,sha512:crypto.createHash('sha512').update(file).digest('base64'),url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/download/offline-v'+version+'/'+name}};
});
for(const {destination,metadata} of manifests)fs.writeFileSync(destination,JSON.stringify(metadata,null,2));
