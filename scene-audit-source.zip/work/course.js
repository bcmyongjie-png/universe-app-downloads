export const chapters={
11:{zh:'恒星与星系',bm:'Bintang dan galaksi dalam alam semesta',en:'Stars and galaxies in the universe',sections:[
 ['星系与银河系','Galaksi dan Bima Sakti','Galaxies and the Milky Way','星系里有许多恒星、气体和尘埃。先比较旋涡、椭圆和不规则这三种形状。',4,7],
 ['恒星的诞生与死亡','Kelahiran dan kematian bintang','Birth and death of stars','星云里的气体聚在一起，中心越来越热。恒星最后留下什么，和它的质量有关。',8,19],
 ['恒星的特征','Ciri-ciri bintang','Characteristics of stars','比较恒星的颜色、温度和大小。红色较冷，蓝色较热；距离也会影响我们看到的亮度。',20,24],
 ['应用与复习','Aplikasi dan ulang kaji','Applications and revision','认识马来西亚首位进入太空的人，再复习太阳、恒星和星系。',25,28]
 ]},
12:{zh:'太阳系',bm:'Sistem suria',en:'Solar system',sections:[
 ['距离与换算','Jarak dan penukaran unit','Distance and unit conversion','1 AU 是地球到太阳的平均距离。光年是光走一年的距离。两者都表示距离。',4,6],
 ['八大行星','Lapan planet','Eight planets','先记住八颗行星的顺序，再比较它们的大小和特点。',7,19],
 ['引力、自转与公转','Graviti, putaran dan peredaran','Gravity, rotation and revolution','引力把物体拉在一起。自转是自己转，公转是绕太阳走。',20,23],
 ['天然卫星与宜居地球','Satelit semula jadi dan Bumi','Natural satellites and habitable Earth','月球绕地球运行。地球有水、合适的温度和大气，能帮助生命生存。',24,28]
 ]},
13:{zh:'流星体、小行星与彗星',bm:'Meteoroid, asteroid dan komet',en:'Meteoroids, asteroids and comets',sections:[
 ['天体的组成与比较','Komposisi dan perbandingan jasad','Composition and comparison of bodies','比较流星体、小行星和彗星。看看它们由什么组成、跑得多快。',3,6],
 ['流星体的旅程','Pergerakan meteoroid','Movement of meteoroids','太空中叫流星体，发光轨迹叫流星，掉到地面的固体叫陨石。',7,18],
 ['小行星轨道与碰撞','Orbit asteroid dan perlanggaran','Asteroid orbits and collisions','小行星带在火星与木星之间。路线交叉不代表一定会撞上地球。',19,23],
 ['彗星运动与总复习','Pergerakan komet dan ulang kaji','Comet motion and revision','彗星靠近太阳时，冰直接变成气体，彗尾更加明显。离子尾背向太阳。',24,26]
 ]}
};
// Every source vocabulary row is included, with standard spelling and additional topic terms.
export const glossary=[
 [11,'宇宙','Alam semesta','Universe'],[11,'星系','Galaksi','Galaxy'],[11,'太阳系','Sistem suria','Solar system'],[11,'银河系','Bima Sakti','Milky Way'],[11,'螺旋','Berpilin','Spiral'],[11,'椭圆','Elips','Elliptical'],[11,'不规则','Tidak seragam','Irregular'],[11,'诞生','Kelahiran','Birth'],[11,'死亡','Kematian','Death'],[11,'星云','Nebula','Nebula'],[11,'引力','Tarikan graviti','Gravitational force'],[11,'压力','Tekanan','Pressure'],[11,'温度','Suhu','Temperature'],[11,'核反应','Tindak balas nuklear','Nuclear reaction'],
 [11,'恒星','Bintang','Star'],[11,'核聚变','Pelakuran nuklear','Nuclear fusion'],[11,'氢','Hidrogen','Hydrogen'],[11,'氦','Helium','Helium'],[11,'尘埃','Debu','Dust'],[11,'气体','Gas','Gas'],[11,'核心','Teras','Core'],[11,'热能','Tenaga haba','Heat energy'],[11,'光能','Tenaga cahaya','Light energy'],[11,'红巨星','Raksasa merah','Red giant'],[11,'超巨星','Super raksasa','Supergiant'],[11,'白矮星','Kerdil putih','White dwarf'],[11,'中子星','Bintang neutron','Neutron star'],[11,'黑洞','Lohong hitam','Black hole'],[11,'超新星','Supernova','Supernova'],[11,'大小','Saiz','Size'],[11,'质量','Jisim','Mass'],[11,'密度','Ketumpatan','Density'],[11,'颜色','Warna','Colour'],[11,'距离','Jarak','Distance'],[11,'亮度','Kecerahan','Brightness'],[11,'表面温度','Suhu permukaan','Surface temperature'],[11,'红色','Merah','Red'],[11,'橙色','Jingga','Orange'],[11,'黄色','Kuning','Yellow'],[11,'黄白色','Kuning-putih','Yellowish-white'],[11,'白色','Putih','White'],[11,'蓝白色','Biru-putih','Bluish-white'],[11,'蓝色','Biru','Blue'],[11,'宇航员','Angkasawan','Astronaut'],
 [12,'太阳系','Sistem suria','Solar system'],[12,'天文单位','Unit astronomi','Astronomical unit'],[12,'光年','Tahun cahaya','Light year'],[12,'振幅','Amplitud','Amplitude'],[12,'行星','Planet','Planet'],[12,'生态足迹','Jejak ekologi','Ecological footprint'],[12,'太阳','Matahari','Sun'],[12,'水星','Utarid','Mercury'],[12,'金星','Zuhrah','Venus'],[12,'地球','Bumi','Earth'],[12,'火星','Marikh','Mars'],[12,'木星','Musytari','Jupiter'],[12,'土星','Zuhal','Saturn'],[12,'天王星','Uranus','Uranus'],[12,'海王星','Neptun','Neptune'],[12,'月球','Bulan','Moon'],[12,'光速','Halaju cahaya','Speed of light'],[12,'自转','Putaran','Rotation'],[12,'公转','Peredaran','Revolution'],[12,'轨道','Orbit','Orbit'],[12,'自转轴','Paksi putaran','Axis of rotation'],[12,'天然卫星','Satelit semula jadi','Natural satellite'],[12,'大气层','Atmosfera','Atmosphere'],[12,'温室效应','Kesan rumah hijau','Greenhouse effect'],[12,'二氧化碳','Karbon dioksida','Carbon dioxide'],[12,'氧气','Oksigen','Oxygen'],[12,'呼吸作用','Respirasi','Respiration'],[12,'水','Air','Water'],[12,'生命','Hidupan','Life'],[12,'昼与夜','Siang dan malam','Day and night'],[12,'潮汐','Pasang surut','Tides'],[12,'从西向东','Barat ke timur','West to east'],[12,'从东向西','Timur ke barat','East to west'],[12,'环系统','Sistem gelang','Ring system'],
 [13,'流星体','Meteoroid','Meteoroid'],[13,'流星','Meteor','Meteor'],[13,'陨石','Meteorit','Meteorite'],[13,'小行星','Asteroid','Asteroid'],[13,'彗星','Komet','Comet'],[13,'小行星带','Jalur asteroid','Asteroid belt'],[13,'流星雨','Pancuran meteor','Meteor shower'],[13,'撞击坑','Kawah','Crater'],[13,'岩石','Batuan','Rock'],[13,'金属','Logam','Metal'],[13,'镍','Nikel','Nickel'],[13,'铁','Besi','Iron'],[13,'冰','Ais','Ice'],[13,'彗头','Kepala komet','Comet head'],[13,'彗尾','Ekor komet','Comet tail'],[13,'升华','Pemejalwapan','Sublimation'],[13,'太阳风','Angin suria','Solar wind'],[13,'椭圆轨道','Orbit elips','Elliptical orbit'],[13,'碰撞','Perlanggaran','Collision'],[13,'组成','Komposisi','Composition'],[13,'速度','Kelajuan','Speed'],[13,'太空','Angkasa lepas','Outer space'],[13,'引力','Tarikan graviti','Gravitational force'],[13,'大气层','Atmosfera','Atmosphere']
];

