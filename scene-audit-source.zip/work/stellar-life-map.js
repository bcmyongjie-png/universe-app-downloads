import * as T from 'three';
import {nebula,accretion} from './body-art.js';
import {neutronStar} from './neutron-star.js';

// A lifecycle diagram, not a map of neighbouring stars or a common timescale.
// Sun-like stars lose their envelopes; only the massive branch has a supernova.
const definitions=[
 ['nebula','星云','Nebula','Nebula',[-18,0],[0,19],0,2.2,'#bc9cdd'],
 ['ordinary','普通恒星','Bintang biasa','Ordinary star',[-10,5.2],[-7,10],.16,1,'#ffe0a0'],
 ['red','红巨星','Raksasa merah','Red giant',[-1,5.2],[-7,0],.28,1.65,'#ef713f'],
 ['white','白矮星','Kerdil putih','White dwarf',[9,5.2],[-7,-10],.4,.48,'#e7f3ff'],
 ['massive','大质量恒星','Bintang besar','Massive star',[-10,-4.8],[7,10],.52,1.3,'#b7d7ff'],
 ['super','红超巨星','Super raksasa','Red supergiant',[-1,-4.8],[7,0],.64,2.15,'#e85e32'],
 ['nova','超新星','Supernova','Supernova',[9,-4.8],[7,-10],.76,.8,'#ffe3b3'],
 ['neutron','中子星','Bintang neutron','Neutron star',[19,-.2],[-5,-21],.88,.35,'#a8daff'],
 ['black','黑洞','Lohong hitam','Black hole',[19,-8.4],[9,-21],.88,.65,'#000000']
];
const routes=[['nebula','ordinary'],['ordinary','red'],['red','white'],['nebula','massive'],['massive','super'],['super','nova'],['nova','neutron'],['nova','black']];
const smooth=(p,a,b)=>T.MathUtils.smoothstep(p,a,b);

function debris(group,color,count=450){
 const positions=[];for(let i=0;i<count;i++){const z=1-2*(i+.5)/count,a=i*2.399963,s=Math.sqrt(1-z*z),r=.7+(i%17)/34;positions.push(Math.cos(a)*s*r,z*r,Math.sin(a)*s*r)}
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));
 const points=new T.Points(geometry,new T.PointsMaterial({color,size:.055,transparent:true,opacity:.7,depthWrite:false,blending:T.AdditiveBlending}));group.add(points);return points;
}

export function stellarLifeMap(w){
 document.body.classList.add('stellar-life-map');
 const nodes=new Map();let inspecting=null,selectedStage=null,lastP=0,lastT=0;
 for(const [id,zh,bm,en,wide,tall,start,r,color] of definitions){
  const group=new T.Group();w.root.add(group);
  const body=w.sphere('life-stage-'+id,r,color,['black','neutron'].includes(id)?0:5,group);
  body.geometry.dispose();body.geometry=new T.SphereGeometry(r,64,48);
  if(id==='black'){body.material.dispose();body.material=new T.MeshBasicMaterial({color:'#000'});accretion(w,body,r)}
  else if(id==='neutron')neutronStar(w,body,r);
  else w.addGlow(body,color,r*3);
  let cloud;if(id==='nebula'){cloud=nebula(w,2400,2.7);group.add(cloud);body.visible=false;}
  let dust;if(id==='nova'||id==='white')dust=debris(group,id==='white'?'#94b8d4':'#ffba7b');
  const outline=new T.Mesh(new T.RingGeometry(r*1.04,r*1.04+.025,48),new T.MeshBasicMaterial({color:'#7c97ac',transparent:true,opacity:.2,side:T.DoubleSide,depthWrite:false}));group.add(outline);
  const pick=new T.Mesh(new T.SphereGeometry(Math.max(1.25,r),12,8),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));pick.userData={id:'life-stage-'+id,r};group.add(pick);w.meshes.push(pick);
  const anchor=new T.Object3D();anchor.position.y=-r-1.05;group.add(anchor);w.label('life-stage-'+id,zh,anchor);
  const label=w.hotspots.at(-1).el;label.classList.add('lifeMapLabel');label.replaceChildren();
  const term=document.createElement('span');term.className='lifeMapTerm';term.lang='ms';term.textContent=bm+' ';
  const gloss=document.createElement('span');gloss.lang='zh';gloss.textContent=zh;term.append(gloss);label.append(term);
  const english=document.createElement('span');english.lang='en';english.textContent=en;label.append(english);
  label.setAttribute('aria-label','查看演化阶段：'+zh);label.title=bm+' / '+en;
  nodes.set(id,{id,group,body,cloud,dust,outline,label,anchor,start,r,wide,tall});
 }
 const edges=routes.map(([from,to])=>{
  const base=new T.ArrowHelper(new T.Vector3(1,0,0),new T.Vector3(),1,'#385161',.34,.19);
  const light=new T.ArrowHelper(new T.Vector3(1,0,0),new T.Vector3(),1,['ordinary','red','white'].includes(to)?'#f2cd88':'#a7d9ee',.36,.2);
  w.root.add(base,light);base.line.material.transparent=base.cone.material.transparent=true;base.line.material.opacity=base.cone.material.opacity=.45;
  const packet=new T.Mesh(new T.SphereGeometry(.09,10,8),new T.MeshBasicMaterial({color:'#e3f8ff'}));w.root.add(packet);
  return {from:nodes.get(from),to:nodes.get(to),base,light,packet,a:new T.Vector3(),direction:new T.Vector3(),length:0};
 });
 const allMeshes=[...w.meshes],panel=document.createElement('section');panel.id='stellarInspect';panel.hidden=true;panel.setAttribute('aria-label','近看天体');
 panel.innerHTML='<strong class="inspectName"></strong><span>拖动旋转 · 滚轮或双指缩放</span><div><button type="button" aria-label="缩小天体">−</button><button type="button" aria-label="放大天体">＋</button><button type="button" class="inspectBack">返回全图</button></div>';
 document.querySelector('#minimalHud').append(panel);
 function zoom(factor){w.fly=null;w.zoomReturn=null;const offset=w.camera.position.clone().sub(w.controls.target),length=T.MathUtils.clamp(offset.length()*factor,w.controls.minDistance,w.controls.maxDistance);w.camera.position.copy(w.controls.target).add(offset.setLength(length));w.controls.update();}
 panel.querySelector('[aria-label="缩小天体"]').onclick=()=>zoom(1.3);panel.querySelector('[aria-label="放大天体"]').onclick=()=>zoom(1/1.3);
 function close(){inspecting=null;panel.hidden=true;document.body.classList.remove('stellar-inspecting');w.meshes=allMeshes;w.controls.minDistance=2;w.controls.maxDistance=220;w.controls.zoomToCursor=true;resize();update(lastP,lastT);}
 panel.querySelector('.inspectBack').onclick=close;
 const onKey=e=>{if(e.key==='Escape'&&inspecting){e.preventDefault();e.stopImmediatePropagation();close();}};window.addEventListener('keydown',onKey,true);
 function inspect(id){
  const n=nodes.get(id||selectedStage)||[...nodes.values()].filter(n=>lastP>=n.start).at(-1)||nodes.get('nebula');inspecting=n;w.fly=null;w.follow=null;w.zoomReturn=null;
  document.body.classList.add('stellar-inspecting');panel.hidden=false;panel.querySelector('.inspectName').textContent=[...n.label.children].map(el=>el.textContent).join(' · ');
  w.meshes=allMeshes.filter(m=>m.userData.id==='life-stage-'+n.id);w.controls.zoomToCursor=false;w.controls.minDistance=Math.max(.8,n.r*1.5);w.controls.maxDistance=Math.max(12,n.r*18);fitInspection();update(lastP,lastT);
 }
 function fitInspection(){const n=inspecting,extent=n.id==='black'?n.r*3.3:n.id==='nova'?3:n.id==='neutron'?n.r*3.5:n.r*1.6;const distance=Math.max(extent*3.4,extent*2.8/w.camera.aspect);w.controls.target.copy(n.group.position);w.camera.position.copy(n.group.position).add(new T.Vector3(0,extent*.25,distance));w.controls.update();}
 function resize(){
  if(inspecting){fitInspection();return;}
  const portrait=innerWidth<650;
  for(const n of nodes.values()){const [x,y]=portrait?n.tall:n.wide;n.group.position.set(x,y,0);n.anchor.position.y=-n.r-(portrait?2.6:1.1);n.label.classList.toggle('portrait',portrait)}
  for(const e of edges){
   const start=e.from.group.position,end=e.to.group.position;e.direction.copy(end).sub(start).normalize();
   e.a.copy(start).addScaledVector(e.direction,e.from.r+.5);e.length=Math.max(.1,start.distanceTo(end)-e.from.r-e.to.r-1);
   for(const arrow of [e.base,e.light]){arrow.position.copy(e.a);arrow.setDirection(e.direction);arrow.setLength(e.length,.34,.19)}
  }
  const width=portrait?32:46,height=portrait?52:22,top=portrait?175:160,bottom=portrait?235:175;
  const available=Math.max(innerHeight*.4,innerHeight-top-bottom),tan=Math.tan(T.MathUtils.degToRad(w.camera.fov/2));
  const distance=Math.max(width/(2*tan*w.camera.aspect),height/(2*tan*available/innerHeight));
  const center=new T.Vector3(portrait?1:1.5,portrait?-2:-2,0);
  w.controls.target.copy(center);w.camera.position.copy(center).add(new T.Vector3(0,0,distance));w.controls.update();
 }
 w.stellarDiagram={resize,inspect,close,get inspecting(){return inspecting?.id},stageProgress:id=>{selectedStage=id;return nodes.get(id)?.start},dispose(){window.removeEventListener('keydown',onKey,true);panel.remove();document.body.classList.remove('stellar-inspecting');w.controls.minDistance=2;w.controls.maxDistance=220;w.controls.zoomToCursor=true;}};resize();
 function update(p,t){
  lastP=p;lastT=t;
  for(const n of nodes.values()){
   n.group.visible=!inspecting||inspecting===n;n.label.classList.toggle('inspectHidden',!!inspecting);
   const growth=inspecting?1:smooth(p,n.start,n.start+.1),active=!!inspecting||p>=n.start;
   n.body.visible=active&&n.id!=='nebula';n.body.rotation.y=inspecting&&n.id==='black'?0:t*(n.id==='neutron'?1.1:.11);n.body.rotation.z=0;
   n.body.scale.setScalar(Math.max(.02,.15+.85*growth));n.outline.visible=!active;
   n.label.style.opacity=active?'1':'.7';n.label.dataset.active=String(active);
   if(n.cloud){n.cloud.visible=active;n.cloud.rotation.y=t*.07;n.cloud.scale.setScalar(1-.35*smooth(p,0,.16));}
   if(n.id==='white'){n.body.scale.setScalar(Math.max(.08,growth));n.dust.visible=p>.33;n.dust.scale.setScalar(1+smooth(p,.33,.5)*3.2);n.dust.material.opacity=.45*(1-smooth(p,.5,.6));}
   if(n.id==='nova'){
    const expansion=inspecting?.id==='nova'?.7:smooth(p,n.start,.9);n.body.visible=active&&(inspecting||p<.86);n.body.scale.setScalar(Math.max(.03,1-expansion));
    n.dust.visible=active;n.dust.scale.setScalar(.3+expansion*3);n.dust.material.opacity=.85-.45*expansion;n.dust.rotation.z=t*.03;
   }
  }
  for(const e of edges){
   if(inspecting){e.base.visible=e.light.visible=e.packet.visible=false;continue;}e.base.visible=true;
   const from=e.to.id==='massive'?.44:e.from.start+.03,to=e.to.start,progress=smooth(p,from,to);
   e.light.visible=progress>0;e.light.setLength(Math.max(.01,e.length*progress),Math.min(.34,e.length*progress*.3),.19);
   e.packet.visible=p>from&&p<to;if(e.packet.visible)e.packet.position.copy(e.a).addScaledVector(e.direction,e.length*progress);
  }
 }
 return update;
}
