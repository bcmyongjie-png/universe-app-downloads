import * as T from 'three';
import {createTexturePool,collectSceneTextures} from './texture-pool.js';
const pool=createTexturePool(T);
export const loadSceneTexture=pool.load;
export const uploadTextures=pool.upload;
export function prepareTextures(world){return pool.upload(world.renderer,collectSceneTextures(world.scene));}
