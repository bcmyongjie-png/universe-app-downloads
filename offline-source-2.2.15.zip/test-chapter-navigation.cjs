const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const out=path.join(os.tmpdir(),'universe-native-chapters');fs.mkdirSync(out,{recursive:true});
(async()=>{for(const edition of process.env.EDITION?[process.env.EDITION]:['Teacher','Student']){
 const lower=edition.toLowerCase();
 const executablePath=process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`;
 const app=await _electron.launch({executablePath,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-chapter-app-'))},timeout:60000});
 try{
  assert.equal(await app.evaluate(({app})=>app.getVersion()),require('./package.json').version);
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  const ready=()=>page.waitForFunction(()=>document.querySelector('#space canvas')&&document.querySelector('#labels')?.style.visibility!=='hidden'&&!document.body.classList.contains('diving'));
  await ready();
  for(const ch of [11,12,13]){
   await page.locator('#teacherToggle').click();await page.locator('.chapterCheck input[value="'+ch+'"]').check();
   for(const other of [11,12,13].filter(n=>n!==ch))await page.locator('.chapterCheck input[value="'+other+'"]').uncheck();
   await page.locator('#teacherPanel header button').click();await ready();if(await page.locator('#chapterTopics').isVisible())await page.locator('.chapterTopicsHeader button').click();
   for(let n=0;n<3;n++){
    await page.keyboard.press('Escape');await ready();
    const location=await page.locator('#location').textContent();
    assert(ch===11?/本星系群|银河系|太阳系|地球|^C11/.test(location):ch===12?/太阳系|地球|^C12/.test(location):/太阳系|地球|^C13/.test(location),location);
   }
   if(ch===11){await page.locator('[data-object-id="cosmos-milky"]').click();await page.waitForFunction(()=>document.body.dataset.level==='0');await ready();assert.equal(await page.getByRole('button',{name:'探索太阳系',exact:true}).count(),1);}
   if(ch===12){for(const name of ['探索太阳','探索彗星','探索小行星带'])assert.equal(await page.getByRole('button',{name,exact:true}).count(),0);}
   await page.reload();await ready();
   assert(ch===11?(await page.locator('#location').textContent()).includes('本星系群'):ch===12?(await page.locator('#location').textContent()).includes('太阳系'):(await page.locator('#location').textContent()).includes('太阳系'));
   await page.screenshot({path:path.join(out,lower+'-c'+ch+'.png')});
   console.log(edition+' C'+ch+' PASS: real offline app, filtered scene entrances, Escape and reload');
  }
  assert.deepEqual(errors,[]);
 }finally{await app.close();}
}})().catch(e=>{console.error(e);process.exit(1);});
