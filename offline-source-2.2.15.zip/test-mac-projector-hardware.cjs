// Opt-in physical MacBook + projector test. Start with the two screens mirrored.
// The app owns/restores its change; this test never overrides a later user change.
const {_electron}=require('playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {execFileSync}=require('node:child_process');
if(process.platform!=='darwin'||process.env.UNIVERSE_HARDWARE_DISPLAY_TEST!=='1'){
 console.log('SKIP: requires macOS, an open MacBook with a mirrored projector, and UNIVERSE_HARDWARE_DISPLAY_TEST=1');
}else (async()=>{
 const bundle=process.env.QA_MAC_APP||path.resolve('dist/teacher/mac-universal/Universe Teacher.app');
 const helper=path.join(bundle,'Contents/Resources/mac-display-helper');
 const displays=()=>{const r=JSON.parse(execFileSync(helper,['snapshot'],{encoding:'utf8',timeout:15000}));assert.equal(r.ok,true,r.error);return r.displays;};
 const initial=displays();assert.equal(initial.length,2);assert.ok(initial.some(d=>d.builtin));assert.ok(initial.some(d=>d.mirror));
 assert.ok(initial.every(d=>!d.fixedMirror),'This adapter must support independent screens');
 const output=path.resolve(process.env.QA_OUTPUT||'smoke-results/mac-projector');fs.mkdirSync(output,{recursive:true});
 const report={initial,chip:process.arch,version:require('./package.json').version,physicalVisualConfirmation:'pending'};
 const app=await _electron.launch({executablePath:path.join(bundle,'Contents/MacOS/Universe Teacher'),env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-mac-projector-'))},timeout:60000});
 const waitUntil=async fn=>{for(let i=0;i<60;i++){if(await fn())return;await new Promise(resolve=>setTimeout(resolve,250));}throw Error('Timed out waiting for physical display state');};
 try{
  assert.equal(await app.evaluate(({app})=>app.getVersion()),report.version);
  const page=await app.firstWindow();page.setDefaultTimeout(30000);
  const dialogs=[],errors=[];page.on('dialog',async d=>{dialogs.push(d.message());await d.dismiss();});page.on('pageerror',e=>errors.push(e.message));
  await page.locator('#space canvas').waitFor();await page.locator('#teacherToggle').click();
  await page.locator('#lessonSelect').selectOption({label:'C12 · 行星大小'});await page.locator('#startLesson').click();
  const click=name=>page.getByRole('button',{name,exact:true}).click();
  await click('打开本主题考题');await click('查看第 1 张幻灯片');
  const opening=app.waitForEvent('window');await click('连接投影仪');const audience=await opening;
  await audience.waitForFunction(()=>document.querySelector('#screen')?.naturalWidth>0);
  const windowState=()=>app.evaluate(({BrowserWindow,screen})=>BrowserWindow.getAllWindows().map(w=>({
   url:w.webContents.getURL(),bounds:w.getBounds(),visible:w.isVisible(),enabled:w.isEnabled(),minimized:w.isMinimized(),
   simple:w.isSimpleFullScreen(),nativeFullscreen:w.isFullScreen(),display:screen.getDisplayMatching(w.getBounds())
  })));
  await waitUntil(async()=>{const state=await windowState();return state.some(w=>w.url.includes('audience-window-')&&w.simple);});
  report.windows=await windowState();const teacher=report.windows.find(w=>!w.url.includes('audience-window-')),projector=report.windows.find(w=>w.url.includes('audience-window-'));
  assert.ok(teacher.visible&&teacher.enabled&&!teacher.minimized&&teacher.display.internal);
  assert.equal(teacher.nativeFullscreen,false);assert.equal(projector.nativeFullscreen,false);assert.equal(projector.simple,true);
  assert.notEqual(projector.display.id,teacher.display.id);assert.equal(projector.display.internal,false);
  assert.equal(await page.evaluate(()=>document.visibilityState),'visible');
  await page.screenshot({path:path.join(output,'teacher-controls.png')});await audience.screenshot({path:path.join(output,'projector-slide.png')});
  const slide=await audience.locator('#screen').getAttribute('src');await click('打开幻灯片总览');await click('查看第 2 张幻灯片');
  await audience.waitForFunction(old=>document.querySelector('#screen')?.getAttribute('src')!==old,slide);
  report.extended=displays();
  let closed=audience.waitForEvent('close');await audience.keyboard.press('Escape').catch(e=>{if(!audience.isClosed())throw e;});await closed;
  await waitUntil(()=>JSON.stringify(displays())===JSON.stringify(initial));
  const reopening=app.waitForEvent('window');await click('连接投影仪');const reopened=await reopening;
  await reopened.waitForFunction(()=>document.querySelector('#screen')?.naturalWidth>0);
  closed=reopened.waitForEvent('close');await click('更多放映选项');await click('结束放映');await closed;
  await waitUntil(()=>JSON.stringify(displays())===JSON.stringify(initial));
  assert.deepEqual(dialogs,[]);assert.deepEqual(errors,[]);report.automatedChecks='pass';
  console.log('PASS: physical Mirror → Extend; teacher visible/enabled on laptop; Space-free projector, slide sync, Escape, reopen, end and original mode restored. Visually confirm BOTH screens before release.');
 }catch(error){report.automatedChecks='fail';report.error=error.stack;throw error;}
 finally{await app.close();report.final=displays();fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(report,null,2));}
})().catch(error=>{console.error(error);process.exitCode=1;});
