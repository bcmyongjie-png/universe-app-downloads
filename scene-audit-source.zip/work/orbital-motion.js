// Kepler ellipse in the XZ plane. The attracting body lies at focusX.
export function ellipsePosition(a,b,meanAnomaly,focusX=0){
 const e=Math.sqrt(1-b*b/(a*a));
 const m=((meanAnomaly+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;
 let E=m;
 for(let i=0;i<12;i++)E-=(E-e*Math.sin(E)-m)/(1-e*Math.cos(E));
 return [focusX+a*(Math.cos(E)-e),0,b*Math.sin(E)];
}
