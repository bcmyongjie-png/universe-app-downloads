export function createTexturePool(T,yieldFrame=()=>new Promise(resolve=>requestAnimationFrame(resolve))){
 const cache=new Map(),uploads=new WeakMap();
 function load(url,options={}){
  const key=JSON.stringify([url,options.colorSpace||'',options.wrapS||0,options.anisotropy||1]);
  if(cache.has(key))return cache.get(key);
  let ready;const promise=new Promise(resolve=>{ready=resolve;});
  const texture=new T.TextureLoader().load(url,async loaded=>{
   if(typeof createImageBitmap==='function')try{
    loaded.image=await createImageBitmap(loaded.image,{imageOrientation:loaded.flipY?'flipY':'none',premultiplyAlpha:'none',colorSpaceConversion:'none'});
    loaded.needsUpdate=true;
   }catch{ /* Keep the decoded image on browsers without bitmap support. */ }
   ready(true);
  },undefined,()=>ready(false));
  Object.assign(texture,options);texture.userData.ready=promise;cache.set(key,texture);return texture;
 }
 function upload(renderer,textures){
  let state=uploads.get(renderer);if(!state){state={tail:Promise.resolve(),versions:new WeakMap(),pending:new WeakMap()};uploads.set(renderer,state);}
  return Promise.all([...new Set(textures)].map(texture=>{
   if(state.pending.has(texture))return state.pending.get(texture);
   const job=Promise.resolve(texture.userData?.ready).then(ready=>{
    if(ready===false||!texture.image||state.versions.get(texture)===texture.version)return;
    const next=state.tail.catch(()=>{}).then(yieldFrame).then(()=>{renderer.initTexture(texture);state.versions.set(texture,texture.version);});
    state.tail=next;return next;
   }).finally(()=>state.pending.delete(texture));
   state.pending.set(texture,job);return job;
  }));
 }
 return {load,upload};
}

export function collectSceneTextures(scene){
 const textures=new Set();
 scene.traverse(object=>{for(const material of [].concat(object.material||[])){
  for(const value of Object.values(material)){if(value?.isTexture)textures.add(value);}
  for(const uniform of Object.values(material.uniforms||{})){if(uniform.value?.isTexture)textures.add(uniform.value);}
 }});return [...textures];
}
