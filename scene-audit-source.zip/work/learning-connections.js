import {chapterOf} from './teaching-content.js';
// Edges are learning relationships, never a claim of neighbouring physical positions.
export const connections={
 'galaxy:0':[['galaxy:3','星系中的气体怎样形成恒星'],['galaxy:1','比较：没有旋臂的星系'],['galaxy:2','比较：没有规则轮廓的星系']],
 'galaxy:1':[['galaxy:0','比较星系的形状'],['galaxy:8','观察恒星的颜色']],
 'galaxy:2':[['galaxy:3','从气体云到恒星'],['galaxy:0','比较有旋臂的星系']],
 'galaxy:3':[['galaxy:4','压缩后的中心为什么会发光'],['galaxy:7','观察恒星一生的完整分支路线']],
 'galaxy:4':[['galaxy:5','像太阳的恒星：燃料减少之后'],['galaxy:6','另一分支：大质量恒星的结局'],['galaxy:8','表面温度怎样影响颜色'],['solar:0','太阳周围有哪些行星']],
 'galaxy:5':[['galaxy:7','像太阳的恒星最终留下白矮星'],['galaxy:12','比较恒星大小']],
 'galaxy:6':[['galaxy:7','比较爆炸后留下的天体'],['galaxy:3','散出的物质参与下一代恒星形成']],
 'galaxy:7':[['galaxy:3','物质回到星际空间'],['galaxy:12','比较不同恒星的大小']],
 'galaxy:8':[['galaxy:9','温度相似，为什么看起来不同亮'],['galaxy:12','大小也是一个因素']],
 'galaxy:9':[['galaxy:13','用仪器观察星体的位置'],['solar:2','远方恒星的距离怎样表示']],
 'galaxy:10':[['solar:1','近地太空与太阳距离的差别'],['earth:1','回看适合生命的地球']],
 'galaxy:11':[['earth:1','太阳能量与生命的关系'],['earth:3','怎样减少对环境的影响']],
 'galaxy:12':[['galaxy:8','大小和温度分别比较'],['galaxy:5','像太阳的恒星如何变大'],['galaxy:6','比较大质量恒星的演化']],
 'galaxy:13':[['galaxy:10','从地面观测到太空探索'],['galaxy:9','理解看到的亮度']],
 'solar:0':[['solar:8','先观察最靠近太阳的行星'],['solar:16','用数据比较八颗行星'],['solar:3','看这些行星怎样运行']],
 'solar:1':[['solar:2','把距离扩展到恒星之间'],['solar:17','亲手换算距离单位']],
 'solar:2':[['solar:17','比较千米、天文单位和光年'],['galaxy:9','距离怎样影响看见的亮度']],
 'solar:3':[['solar:4','绕太阳运行与自转的区别'],['solar:1','比较轨道距离'],['visitors:2','火星与木星之间还有什么']],
 'solar:4':[['earth:0','地球自转怎样产生昼夜'],['solar:9','观察金星的特殊自转']],
 'solar:5':[['solar:8','比较几乎没有厚大气的水星'],['earth:1','地球为什么温度适宜']],
 'solar:6':[['solar:7','引力与天然卫星'],['visitors:5','引力怎样改变小天体轨道']],
 'solar:7':[['earth:4','为什么总看见月球同一面'],['earth:2','月球与潮汐有什么关系']],
 'solar:8':[['solar:9','比较下一颗行星'],['solar:5','距离最近，为什么不是最热']],
 'solar:9':[['solar:10','比较地球'],['solar:5','厚大气怎样留住热量'],['solar:4','比较自转方向']],
 'solar:10':[['earth:1','深入地球的宜居条件'],['earth:0','观察昼夜分界'],['solar:11','比较火星']],
 'solar:11':[['solar:12','越过主小行星带看木星'],['visitors:2','探索两者之间的小行星带']],
 'solar:12':[['solar:13','比较另一颗气态巨行星'],['solar:6','比较表面引力'],['visitors:5','木星怎样影响小天体']],
 'solar:13':[['solar:14','继续比较冰巨行星'],['solar:7','行星环与卫星的区别']],
 'solar:14':[['solar:15','比较海王星'],['solar:4','观察极度倾斜的自转轴']],
 'solar:15':[['solar:16','回顾八颗行星的数据'],['visitors:7','认识含冰的小天体']],
 'solar:16':[['solar:6','质量与半径怎样影响引力'],['solar:1','比较行星与太阳的距离'],['solar:0','回到相同尺度的大小比较']],
 'solar:17':[['solar:1','回顾天文单位'],['solar:2','回顾光年']],
 'earth:0':[['earth:2','假设自转变慢会怎样'],['earth:1','光照与适合生命的环境']],
 'earth:1':[['galaxy:11','假设太阳停止发光'],['earth:3','怎样保护地球环境'],['solar:7','探索月球与地球的关系']],
 'earth:2':[['earth:4','理解同步自转'],['earth:0','回到正常的昼夜变化']],
 'earth:3':[['earth:1','回顾生命依赖的条件']],
 'earth:4':[['solar:7','回顾天然卫星'],['earth:2','区分同步自转与停止自转']],
 'visitors:0':[['visitors:2','小行星主要分布在哪里'],['visitors:7','彗星靠近太阳会怎样'],['visitors:1','比较速度和大小']],
 'visitors:1':[['visitors:3','碎片高速进入大气层'],['visitors:8','速度怎样影响撞击能量']],
 'visitors:2':[['visitors:0','分清小行星、彗星与流星体'],['visitors:3','碎片进入地球大气会怎样']],
 'visitors:3':[['visitors:4','地球穿过碎屑流时形成流星雨'],['visitors:8','较大撞击可能造成什么']],
 'visitors:4':[['visitors:7','流星雨碎屑常来自彗星'],['visitors:8','另外比较较大天体造成的撞击'],['visitors:5','接近地球是否一定撞上']],
 'visitors:5':[['visitors:6','怎样及早降低撞击风险'],['visitors:1','了解速度与尺度']],
 'visitors:6':[['visitors:8','理解需要避免的撞击影响'],['galaxy:13','观测仪器怎样帮助追踪']],
 'visitors:7':[['visitors:4','地球穿过彗星留下的碎屑'],['visitors:0','比较小天体的组成']],
 'visitors:8':[['visitors:6','及早发现并改变轨道'],['earth:1','撞击为什么影响生命']]
};
export function createLearningConnections(hud,journeys,{state,enter,allows}){
 const all=new Map(Object.entries(journeys).flatMap(([track,items])=>items.map((d,i)=>[track+':'+i,{...d,track,index:i}])));
 const panel=document.createElement('aside');panel.id='learningConnections';panel.setAttribute('aria-label','与当前天体相关的探索');hud.append(panel);
 let previous='';
 function rootKey(s){if(s.visual)return s.visual.track+':'+s.visual.index;
  if(s.focused?.startsWith('cosmos-'))return s.focused.includes('m32')||s.focused.includes('m110')?'galaxy:1':s.focused.includes('mc')?'galaxy:2':'galaxy:0';
  const match=[...all].find(([,d])=>d.planet===s.focused);if(match)return match[0];
  return ({sun:'galaxy:4',moon:'solar:7',asteroid:'visitors:2',comet:'visitors:7',meteor:'visitors:3'})[s.focused]||(s.level<=0?'galaxy:0':s.level===1?'solar:0':'earth:1');
 }
 function update(){const s=state(),key=rootKey(s),edges=(connections[key]||[]).filter(([id])=>all.has(id)&&allows(chapterOf(all.get(id).track))),stamp=key+':'+edges.map(e=>e[0]).join(',');if(stamp===previous)return;previous=stamp;
  panel.hidden=!edges.length;panel.innerHTML='<div class="connectionEyebrow">从这里继续探索 <small>知识关联</small></div>'+edges.map(([id,why])=>{const d=all.get(id);return '<a href="#explore-'+id.replace(':','-')+'" data-explore="'+id+'"><span class="connectionDot" aria-hidden="true"></span><span><strong>'+d.zh+'</strong><small>'+why+'</small></span><span aria-hidden="true">↗</span></a>';}).join('');
  panel.querySelectorAll('a').forEach(a=>a.onclick=e=>{e.preventDefault();e.stopPropagation();const d=all.get(a.dataset.explore);if(d&&allows(chapterOf(d.track)))enter(d.track,d.index);});
 }
 new MutationObserver(update).observe(document.querySelector('#location'),{childList:true,subtree:true,characterData:true});
 new MutationObserver(update).observe(document.body,{attributes:true,attributeFilter:['class','data-level']});update();return {update};
}
