const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const out=path.resolve('smoke-results','stellar-three-paths');fs.mkdirSync(out,{recursive:true});
(async()=>{for(const edition of process.env.EDITION?[process.env.EDITION]:['Teacher','Student']){
 const lower=edition.toLowerCase(),exe=process.env.QA_EXECUTABLE||(process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`);
 const app=await _electron.launch({executablePath:exe,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-three-paths-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error'&&/THREE|shader|WebGL/i.test(m.text()))errors.push(m.text());});
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption('galaxy:7');await page.locator('#startLesson').click();
  await page.waitForFunction(()=>document.querySelector('#lessonTimeline')?.dataset.kind==='remnants'&&document.querySelector('#labels').style.visibility!=='hidden');
  assert.equal(await page.locator('.lifeMapLabel').count(),14,'Three complete stellar paths need separate large-star and very-large-star stages');
  assert.equal(await page.locator('.lifeMapLabel [lang=ms]').count(),14);assert.equal(await page.locator('.lifeMapLabel [lang=en]').count(),14);
  assert.equal(await page.locator('.lifeMapLabel [lang=zh-Hans]').count(),14,'Every stage keeps Malay and English and adds a Chinese meaning');
  assert(await page.locator('.lifeMapLabel').evaluateAll(els=>els.every(el=>[...el.children].map(n=>n.lang).join(',')==='ms,en,zh-Hans'&&[...el.children].every(n=>n.textContent.trim()))));
  const seek=async value=>{await page.locator('.motionSeek').evaluate((el,v)=>{el.value=String(v);el.dispatchEvent(new Event('input',{bubbles:true}));},value);await page.waitForFunction(v=>document.querySelector('.motionSeek').getAttribute('aria-valuetext').startsWith(Math.round(v/10)+'%'),value);};
  await seek(200);await page.waitForFunction(()=>['ordinary','massive','very-massive'].every(id=>document.querySelector(`[data-life-stage="${id}"]`)?.dataset.active==='true'));
  for(const id of ['white','neutron','black'])assert.equal(await page.locator(`[data-life-stage="${id}"]`).getAttribute('data-active'),'false');
  await seek(550);await page.waitForFunction(()=>document.querySelector('[data-life-stage="white"]').dataset.active==='true');assert.equal(await page.locator('[data-life-stage="nova"]').getAttribute('data-active'),'false');
  await seek(1000);await page.waitForFunction(()=>[...document.querySelectorAll('.lifeMapLabel')].every(el=>el.dataset.active==='true'));
  await page.screenshot({path:path.join(out,lower+'-three-paths.png')});
  async function noOverlap(){const boxes=await page.locator('.lifeMapLabel').evaluateAll(els=>els.map(el=>{const b=el.getBoundingClientRect();return {id:el.dataset.lifeStage,x:b.x,y:b.y,w:b.width,h:b.height};}));const viewport=await page.evaluate(()=>({w:innerWidth,h:innerHeight}));for(const b of boxes)assert(b.x>=0&&b.y>=0&&b.x+b.w<=viewport.w&&b.y+b.h<=viewport.h,`Offscreen label ${b.id}`);for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],b=boxes[j];assert(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y),`Labels overlap: ${a.id}, ${b.id}`);}}
  await noOverlap();
  for(const id of ['white','neutron','black','very-super','very-nova']){
   await page.locator(`[data-life-stage="${id}"]`).waitFor({state:'visible'});await page.locator(`[data-life-stage="${id}"]`).press('Enter');await page.locator('.motionInspect').click();await page.locator('#stellarInspect').waitFor({state:'visible'});
   assert.equal(await page.locator('#stellarInspect').getAttribute('data-stage'),id);assert.equal(await page.locator('.motionPlay').getAttribute('aria-pressed'),'false');
   await page.getByRole('button',{name:'放大天体',exact:true}).click();await page.getByRole('button',{name:'缩小天体',exact:true}).click();
   if(id==='black')await page.screenshot({path:path.join(out,lower+'-inspect-black.png')});await page.keyboard.press('Escape');await page.locator('#lessonTimeline').waitFor({state:'visible'});
  }
  await seek(0);await page.locator('.motionSpeed').selectOption('2');await page.locator('.motionPlay').click();await page.waitForFunction(()=>Number(document.querySelector('.motionSeek').value)>15);await page.locator('.motionPlay').click();assert.equal(await page.locator('.motionSpeed').inputValue(),'2');
  for(const height of [700,844]){
   await app.evaluate(({BrowserWindow},height)=>{const w=BrowserWindow.getAllWindows()[0];w.setMinimumSize(320,400);w.setContentSize(390,height);},height);await seek(1000);await page.waitForFunction(()=>document.querySelector('.lifeMapLabel').classList.contains('portrait'));await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await page.screenshot({path:path.join(out,lower+'-mobile-'+height+'-three-paths.png')});await noOverlap();
  }
  await page.locator('[data-life-stage="black"]').dblclick();await page.locator('#stellarInspect').waitFor({state:'visible'});assert.equal(await page.locator('#stellarInspect').getAttribute('data-stage'),'black');await page.locator('.inspectBack').click();
  assert.deepEqual(errors,[]);console.log(edition+' PASS: 14 stages, three independent endings, timed growth, playback, inspection/zoom/return, desktop/mobile labels, no runtime errors');
 }finally{await app.close();}
}})().catch(e=>{console.error(e);process.exit(1);});
