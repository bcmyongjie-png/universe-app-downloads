const assert=require('assert/strict'),fs=require('fs/promises'),os=require('os'),path=require('path'),crypto=require('crypto');
const {newer,validMac,downloadMac}=require('./updates.cjs');
(async()=>{
 assert(newer('2.10.0','2.9.9'));assert(!newer('2.1.0','2.1.0'));assert(!newer('1.9.9','2.0.0'));assert(!newer('bad','2.0.0'));
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'universe-updater-test-')),bytes=Buffer.from('verified download fixture');
 const info={edition:'teacher',version:'2.2.0',url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/download/offline-v2.2.0/Teacher.dmg',size:bytes.length,sha512:crypto.createHash('sha512').update(bytes).digest('base64')};
 assert.equal(validMac(info,'teacher'),info);assert.throws(()=>validMac({...info,edition:'student'},'teacher'));assert.throws(()=>validMac({...info,url:'https://example.com/evil.dmg'},'teacher'));assert.throws(()=>validMac({...info,size:3e9},'teacher'));
 const fake=async()=>new Response(bytes),file=await downloadMac(info,dir,fake);assert.deepEqual(await fs.readFile(file),bytes);
 await assert.rejects(downloadMac({...info,version:'2.3.0'},dir,async()=>new Response(Buffer.from('tampered'))));
 assert(!(await fs.readdir(dir)).some(n=>n.endsWith('.partial')));
 await assert.rejects(downloadMac({...info,version:'2.3.0'},dir,async()=>{throw Error('offline')}));assert.deepEqual(await fs.readFile(file),bytes);
 console.log('Update policy PASS: no downgrade, edition/host/size validation, verified downloads, corrupt/offline rejection, partial cleanup and prior download preservation');
})().catch(e=>{console.error(e);process.exit(1)});
