import {openAudience,audienceLink,fullscreenAudience,closeAudience} from './audience-bridge.js';
export function showProjectorSetup(){
 if(window.universeDesktop?.openProjector){
  void window.universeDesktop.openProjector(new URL(audienceLink(),location.href).href).then(result=>{if(!result.ok)alert(result.message||'请检查投影连接。');}).catch(()=>alert('无法打开投影窗口，请重试。'));
  return;
 }
 const platform=navigator.userAgentData?.platform||navigator.platform||'';
 const appleMobile=/iPhone|iPad|iPod/.test(navigator.userAgent)||(/Mac/i.test(platform)&&navigator.maxTouchPoints>1);
 const mac=/Mac/i.test(platform)&&!appleMobile;
 const instructions=appleMobile?'iPhone / iPad：打开学生画面后，可通过控制中心的「屏幕镜像」投屏。镜像显示相同画面，老师选页也会被看到；需要私下选页时，请使用电脑扩展屏幕。':mac?'Mac：系统设置 → 显示器 → 扩展显示。教师窗口留在电脑，将学生窗口拖到投影屏幕，再点击全屏。':'Windows：Win + P → 扩展。在学生窗口按 Win + Shift + ← / → 移到投影仪，再点击全屏。';
 const manualStep=appleMobile?'打开学生画面后使用系统投屏。':mac?'将学生窗口拖到外接屏幕，再全屏。':'将学生窗口移到投影仪并全屏。';
 const panel=document.createElement('dialog');panel.className='projectorSetup';panel.setAttribute('aria-label','连接投影仪');
 panel.innerHTML='<div class="projectorHeading"><h2>连接投影仪</h2><button type="button" aria-label="关闭投影设置">×</button></div><details><summary>连接说明</summary><p>'+instructions+'</p><p>老师在本页选课件，投影保持当前页，选定后才切换。</p></details><button type="button" data-detect>查找投影屏幕</button><label hidden>投影到<select aria-label="选择投影屏幕"></select></label><p class="projectorStatus" role="status"></p><button type="button" data-connect>打开学生投影窗口</button><a target="_blank" rel="noopener" aria-label="打开独立学生画面">在新标签页打开 ↗</a>';
 if(/Win/.test(platform)){const help=document.createElement('p');help.textContent='像 PowerPoint 一样自动切换 Extend，请在 Windows App 1.0.1 或更新版中打开课件，再点全屏播放。浏览器不能自动切换 Windows 显示模式。';const download=document.createElement('a');download.href='https://universe-science-classroom.vercel.app/#versions';download.target='_blank';download.rel='noopener';download.textContent='下载 Windows App';help.append(' ',download);panel.querySelector('.projectorHeading').after(help);}
 document.body.append(panel);panel.showModal();let screens=[];
 const stop=document.createElement('button');stop.type='button';stop.textContent='结束投影';stop.onclick=()=>{closeAudience();panel.close();};panel.append(stop);
 const status=panel.querySelector('[role="status"]'),select=panel.querySelector('select'),detect=panel.querySelector('[data-detect]'),connect=panel.querySelector('[data-connect]'),link=panel.querySelector('a[aria-label="打开独立学生画面"]');link.href=audienceLink();
 const manual=message=>{screens=[];select.parentElement.hidden=true;connect.textContent='打开学生投影窗口';status.textContent=message+' 点击下方按钮打开窗口。'+manualStep;};
 manual('可以手动投影，也可查找外接屏幕。');
 const displayStatus=e=>{if(e.detail.fullscreenSupported===false){retry.hidden=true;status.textContent='学生画面已打开，此浏览器不支持网页全屏。可使用浏览器全屏或系统投屏；系统镜像会显示相同画面，不能隐藏老师的选页操作。';return;}retry.hidden=!screens.length||(e.detail.fullscreen&&e.detail.onTarget);if(e.detail.fullscreen&&e.detail.onTarget){panel.close();return;}status.textContent=e.detail.fullscreen?'学生画面已确认全屏。请确认它在投影仪上；老师可关闭此面板继续选页。':'学生窗口已打开，但尚未全屏。先把学生窗口移到投影仪，再点其顶部「点一下，全屏投影」。';};window.addEventListener('audience-display-status',displayStatus);panel.addEventListener('close',()=>window.removeEventListener('audience-display-status',displayStatus),{once:true});
 const retry=document.createElement('button');retry.type='button';retry.textContent='在投影屏幕全屏';retry.hidden=true;retry.onclick=()=>{if(!fullscreenAudience())status.textContent='请先打开学生投影窗口。';};connect.after(retry);
 if(!mac&&!appleMobile)panel.querySelector('details').insertAdjacentHTML('beforeend','<p><a href="/Universe-Projector.zip" download>下载 Windows 投影启动工具</a><br>解压后运行：自动切换扩展，并在独立 Chrome / Edge 打开教师版。</p>');
 panel.querySelector('.projectorHeading button').onclick=()=>panel.close();panel.addEventListener('close',()=>panel.remove(),{once:true});
 if(!window.getScreenDetails){detect.hidden=true;manual('此浏览器不支持自动选择屏幕。');}
 detect.onclick=async()=>{detect.disabled=true;try{
  const details=await window.getScreenDetails();screens=Array.from(details.screens).filter(s=>s!==details.currentScreen&&s.isInternal!==true);select.replaceChildren();
  if(!screens.length&&details.currentScreen.isInternal===false&&Array.from(details.screens).some(s=>s.isInternal===true)){manual('老师窗口目前在外接屏幕。请先将老师窗口移回电脑，再查找投影屏幕；避免误投到笔记本。');return;}
  if(!screens.length){manual('目前只识别到一个可用画面。'+instructions);return;}
  let saved='';try{saved=localStorage.getItem('universe.projector')||'';}catch{}
  screens.forEach((s,i)=>{const option=document.createElement('option');option.value=String(i);option.textContent=s.label||'外接屏幕 '+(i+1);select.append(option);});const remembered=screens.findIndex(s=>JSON.stringify([s.label,s.availLeft,s.availTop])===saved);select.value=String(Math.max(0,remembered));select.parentElement.hidden=false;connect.textContent='发送到投影屏幕';status.textContent='选择外接屏幕，再点击发送。';
  if(screens.length===1||remembered>=0)connect.click();
 }catch{manual('屏幕访问未获允许，仍可手动投影。');}finally{detect.disabled=false;}};
 connect.onclick=()=>{const target=screens[Number(select.value)];let opened=false;try{opened=openAudience(target,!target);}catch{}
  if(opened){status.textContent=target?'已请求在外接屏幕打开，正在等待学生窗口确认。若仍有窗口栏，请点投影画面的全屏提示。':'学生窗口已打开。'+manualStep;if(target){try{localStorage.setItem('universe.projector',JSON.stringify([target.label,target.availLeft,target.availTop]));}catch{}}}
  else manual('浏览器未能打开窗口。请允许此网站的弹出窗口，或使用下面的新标签页链接。');
 };
 if(window.getScreenDetails)void detect.onclick();
}
