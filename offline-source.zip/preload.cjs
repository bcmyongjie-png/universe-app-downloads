const {contextBridge,ipcRenderer}=require('electron');
const allowed=['https://universe-teacher.local','https://universe-student.local'];
if(allowed.includes(location.origin))contextBridge.exposeInMainWorld('universeDesktop',{openProjector:url=>ipcRenderer.invoke('universe:projector',url)});
