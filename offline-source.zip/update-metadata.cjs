const fs=require('fs'),crypto=require('crypto'),path=require('path');
for(const edition of ['teacher','student']){
 const dir=path.join('dist',edition),name=fs.readdirSync(dir).find(f=>f.endsWith('.dmg'));if(!name)continue;const file=fs.readFileSync(path.join(dir,name)),version=require('./package.json').version;
 fs.writeFileSync(path.join(dir,edition+'-mac.json'),JSON.stringify({edition,version,size:file.length,sha512:crypto.createHash('sha512').update(file).digest('base64'),url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/download/offline-v'+version+'/'+name},null,2));
}
