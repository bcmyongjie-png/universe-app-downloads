import {toolIcon} from './ppt-tools.js';
import {mountSlidePlayback} from './slide-playback.js';
import {isStudent} from './edition.js';
import {sourceLabel} from './source-labels.js';
import {newSources} from './new-source-pages.js';
import {pages} from './course-pages.js';
import pageMap from './topic-page-map.json';
import inventory from './video-inventory.json';
import {journeys} from './visual-lessons.js';
import {pointsFor,pairHTML,escape} from './teaching-content.js';

import birth from './topic-videos/27a02d4749fc354e.mp4';
import motion from './topic-videos/7010f0ef9a5eef0e.mp4';
import structure from './topic-videos/bad79e6d54ffa028.mp4';
import myths from './topic-videos/7c00dfca3995a7ed.mp4';
import birthPoster from './extracted-video/27a02d4749fc354e-1.jpg';
import motionPoster from './extracted-video/7010f0ef9a5eef0e-1.jpg';
import structurePoster from './extracted-video/bad79e6d54ffa028-2.jpg';
import mythsPoster from './extracted-video/7c00dfca3995a7ed-2.jpg';
export const topicVideos=[
 {id:'27a02d4749fc354e.mp4',url:birth,poster:birthPoster,zh:'恒星的诞生',bm:'Kelahiran bintang',en:'Birth of a star',duration:'2:25',topics:['galaxy:3','galaxy:4'],note:['Perhatikan awan gas termampat, cakera dan teras yang semakin panas.','Observe the collapsing gas cloud, disc and increasingly hot core.']},
 {id:'7010f0ef9a5eef0e.mp4',url:motion,poster:motionPoster,zh:'行星运动动画',bm:'Animasi pergerakan planet',en:'Planetary motion animation',duration:'1:13',topics:['solar:0','solar:3','solar:4','solar:14'],note:['Animasi bergaya untuk membandingkan gerakan planet; saiz dan masa bukan skala sebenar.','A stylised animation for comparing planetary motion; sizes and timing are not to scale.']},
 {id:'bad79e6d54ffa028.mp4',url:structure,poster:structurePoster,zh:'太阳系结构与小天体',bm:'Struktur Sistem Suria dan jasad kecil',en:'Solar System structure and small bodies',duration:'5:49',topics:['solar:0','solar:3','solar:12','solar:16','visitors:2','visitors:5'],extension:true,note:['Video lanjutan tentang planet dan taburan jasad kecil. Gunakan istilah dan penerangan yang telah disemak pada papan untuk ulang kaji.','An extension video about planets and small-body distributions. Use the reviewed terms and board explanations for revision.']},
 {id:'7c00dfca3995a7ed.mp4',url:myths,poster:mythsPoster,zh:'行星名称与神话背景',bm:'Nama planet dan latar mitologi',en:'Planet names and mythology',duration:'8:32',topics:['solar:0',...Array.from({length:8},(_,i)=>'solar:'+(8+i))],extension:true,note:['Bahan budaya, bukan fakta astronomi atau jawapan peperiksaan. Mengandungi kisah mitologi bertema dewasa; guru boleh pratonton sebelum ditayangkan.','Cultural material, not astronomy facts or examination answers. Includes adult themes in mythology; teachers can preview it before showing it.']}
];
const sourceLookup=new Map(newSources.flatMap(d=>d.pages.map(p=>[d.id+':'+p.number,{...p,doc:d.id,name:d.name}])));
for(const [ch,rows] of Object.entries(pages))for(const p of rows)sourceLookup.set('old'+ch+':'+p.number,{...p,chapter:Number(ch),doc:'old'+ch,name:'C'+ch+' SEP 原课件'});
export const relatedPages=key=>pageMap.filter(x=>x.topics.includes(key)&&['new1','new2','new4','new5'].includes(x.id.split(':')[0])).map(x=>({...sourceLookup.get(x.id),...x})).sort((a,b)=>Number(b.exam)-Number(a.exam)||a.doc.localeCompare(b.doc)||a.number-b.number);
export function resourceKey(d,track,index){const exact=Object.entries(journeys).flatMap(([t,a])=>a.map((v,i)=>({v,key:t+':'+i}))).find(x=>x.v.zh===(d.zh||d.name));return exact?.key||(track?track+':'+index:null);}
export function resourceButtons(d,track,index){const key=resourceKey(d,track,index);if(!key)return '';const videos=topicVideos.filter(v=>v.topics.includes(key)),refs=isStudent?[]:relatedPages(key);return '<div class="topicActions">'+(videos.length?'<button data-topic-video="'+key+'">▶ 视频</button>':'')+(isStudent?'':'<button data-topic-notes="'+key+'">考试重点与原题'+(refs.length?' · '+refs.length:'')+'</button>')+'</div>';}
let dialog,previousFocus;
function getDialog(){if(dialog)return dialog;dialog=document.createElement('dialog');dialog.id='topicResources';dialog.setAttribute('aria-label','主题视频与考试重点');document.body.append(dialog);dialog.addEventListener('close',()=>{dialog.querySelectorAll('video').forEach(v=>{v.pause();v.removeAttribute('src');v.load();});document.body.classList.remove('topic-resource-open');document.dispatchEvent(new CustomEvent('teaching-media',{detail:{open:false}}));previousFocus?.focus();});dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});return dialog;}
export function openTopic(key,tab='notes'){
 if(isStudent){if(!topicVideos.some(v=>v.topics.includes(key)))return;tab='video';}
 const [track,n]=key.split(':'),index=Number(n),d=key==='videos:0'?{zh:'课件视频',bm:'Video pelajaran',en:'Lesson videos'}:journeys[track]?.[index];if(!d)return;const panel=getDialog();previousFocus=document.activeElement;const videos=key==='videos:0'?topicVideos:topicVideos.filter(v=>v.topics.includes(key)),refs=relatedPages(key);
 const videoHTML=videos.map(v=>'<article class="topicVideo"><h3>'+v.zh+'</h3><video controls playsinline preload="metadata" poster="'+v.poster+'" src="'+v.url+'" aria-label="'+v.zh+'"></video><div class="videoSeekControls"><input type="range" class="videoSeek" aria-label="视频进度" min="0" max="0" step="0.1" value="0" disabled><div class="videoSeekRow"><button data-video-skip="-10" disabled>↶ 10 秒</button><output class="videoTime">0:00 / 0:00</output><button data-video-skip="10" disabled>10 秒 ↷</button></div></div><p class="videoError" hidden role="alert">视频暂时无法播放。<a href="'+v.url+'" target="_blank" rel="noopener">单独打开 ↗</a></p></article>').join('');
 panel.innerHTML='<div class="resourceTop"><span>'+(tab==='video'?'视频':'考试重点')+'</span><div class="resourceAppearance" role="group" aria-label="资源面板外观"><button data-resource-theme="glass" aria-pressed="false">透明</button><button data-resource-theme="white" aria-pressed="false">白板</button></div><button class="closeResources" aria-label="关闭主题资源">×</button></div><h2>'+d.zh+'</h2><div class="resourceNames"><span lang="ms">'+d.bm+'</span><br><em lang="en">'+d.en+'</em></div><div class="resourceTabs">'+(videos.length?'<button data-resource-tab="video" aria-pressed="'+(tab==='video')+'">观看视频 · '+videos.length+'</button>':'')+'<button data-resource-tab="notes" aria-pressed="'+(tab==='notes')+'">考试重点与原题</button></div><section id="topicVideoPane" '+(tab==='video'?'':'hidden')+'>'+videoHTML+'</section><section id="topicNotesPane" '+(tab==='notes'?'':'hidden')+'><h3>掌握这些重点</h3>'+pointsFor(d,track,index).map((p,i)=>'<article class="examPoint"><span class="examNumber">'+String(i+1).padStart(2,'0')+'</span>'+pairHTML(p)+'</article>').join('')+'<h3>相关幻灯片 · '+refs.length+' 页</h3>'+(refs.length?'<div class="examSlide"><div class="examSlideStage"><img id="examSlideImage" alt=""></div><div class="slideMotionControls"></div><div class="examSlideNav"><button id="previousExamSlide" aria-label="上一张考题幻灯片">← 上一张</button><span id="examSlideCount" role="status"></span><button id="nextExamSlide" aria-label="下一张考题幻灯片">下一张 →</button></div></div>':'<p>本主题暂无相关幻灯片。</p>')+'</section>'; let theme='glass';try{theme=localStorage.getItem('universe.resourceTheme')||document.body.dataset.board||'glass';}catch{}
 if(isStudent){panel.querySelector('.resourceTabs').remove();panel.querySelector('#topicNotesPane').remove();}
 const applyTheme=value=>{panel.dataset.theme=value;panel.querySelectorAll('[data-resource-theme]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.resourceTheme===value)));};applyTheme(theme);
 panel.querySelectorAll('[data-resource-theme]').forEach(b=>b.onclick=()=>{applyTheme(b.dataset.resourceTheme);try{localStorage.setItem('universe.resourceTheme',b.dataset.resourceTheme);}catch{}});
 if(refs.length){
 const host=panel.querySelector('.examSlide');
 const overview=document.createElement('div');overview.className='examSlideOverview';overview.setAttribute('aria-label','本主题全部幻灯片');
 overview.innerHTML=refs.map((p,i)=>'<button type="button" data-exam-slide="'+i+'" aria-label="查看第 '+(i+1)+' 张幻灯片"><img src="'+p.image+'" loading="lazy" alt=""><span>'+(i+1)+'</span></button>').join('');
 host.prepend(overview);
 const player=mountSlidePlayback(host);
 const toggle=document.createElement('button');toggle.type='button';toggle.className='slideOverviewToggle';toggle.innerHTML=toolIcon('grid');toggle.title='全部幻灯片';toggle.setAttribute('aria-label','打开幻灯片总览');host.querySelector('[data-build="audience"]').after(toggle);
 const heading=document.createElement('div');heading.className='slideOverviewHeading';heading.innerHTML='<strong>选择幻灯片</strong><span>'+refs.length+' 页 · 点击任意一页开始</span><button type="button" class="resumeCurrentSlide">返回当前页</button>';host.prepend(heading);
 let slide=0;
 const setOverview=visible=>{host.classList.toggle('showSlideOverview',visible);overview.hidden=!visible;heading.hidden=!visible;toggle.setAttribute('aria-expanded',String(visible));if(visible){overview.querySelector('[aria-pressed="true"]')?.focus({preventScroll:true});}else host.querySelector('.examSlideStage').focus({preventScroll:true});};
 toggle.onclick=()=>setOverview(true);heading.querySelector('button').onclick=()=>setOverview(false);
 const renderSlide=()=>{const p=refs[slide];player.load(p,d.zh+' · 第 '+p.number+' 页');host.querySelector('#examSlideCount').textContent=(slide+1)+' / '+refs.length;host.querySelector('#previousExamSlide').disabled=slide===0;host.querySelector('#nextExamSlide').disabled=slide===refs.length-1;overview.querySelectorAll('button').forEach((b,i)=>b.setAttribute('aria-pressed',String(i===slide)));};
 host.querySelector('#previousExamSlide').onclick=()=>{slide--;renderSlide();setOverview(false);};host.querySelector('#nextExamSlide').onclick=()=>{slide++;renderSlide();setOverview(false);};
 renderSlide();setOverview(true);
 overview.querySelectorAll('button').forEach(b=>b.onclick=()=>{slide=Number(b.dataset.examSlide);renderSlide();setOverview(false);if(!host.classList.contains('slidePresentation'))host.scrollIntoView({block:'center',behavior:'smooth'});});
 }

 panel.querySelector('.closeResources').onclick=()=>panel.close();
 panel.querySelectorAll('[data-resource-tab]').forEach(b=>b.onclick=()=>{panel.querySelectorAll('video').forEach(v=>v.pause());panel.querySelector('#topicVideoPane').hidden=b.dataset.resourceTab!=='video';panel.querySelector('#topicNotesPane').hidden=b.dataset.resourceTab!=='notes';panel.querySelectorAll('[data-resource-tab]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));});
 panel.querySelectorAll('video').forEach(v=>{
 const host=v.closest('article'),range=host.querySelector('.videoSeek'),time=host.querySelector('.videoTime'),buttons=host.querySelectorAll('[data-video-skip]');
 const play=document.createElement('button');play.type='button';play.className='videoPlayToggle';play.textContent='\u25b6';play.setAttribute('aria-label','\u64ad\u653e\u6216\u6682\u505c\uff1a'+v.getAttribute('aria-label'));play.setAttribute('aria-pressed','false');host.querySelector('.videoSeekRow').prepend(play);
 const syncPlay=()=>{play.textContent=v.paused?'\u25b6':'\u2161';play.setAttribute('aria-pressed',String(!v.paused));};play.onclick=()=>{if(v.paused)v.play().catch(()=>{host.querySelector('.videoError').hidden=false;});else v.pause();};['play','pause','ended','emptied'].forEach(event=>v.addEventListener(event,syncPlay));
 const format=t=>Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0');
 const sync=()=>{const ready=Number.isFinite(v.duration)&&v.duration>0;range.disabled=!ready;buttons.forEach(b=>b.disabled=!ready);range.max=ready?v.duration:0;range.value=v.currentTime;range.setAttribute('aria-valuetext',format(v.currentTime)+' / '+format(ready?v.duration:0));time.textContent=format(v.currentTime)+' / '+format(ready?v.duration:0);};
 const seek=t=>{if(Number.isFinite(v.duration)&&v.duration>0){v.currentTime=Math.max(0,Math.min(v.duration,t));sync();}};
 range.oninput=()=>seek(Number(range.value));buttons.forEach(b=>b.onclick=()=>seek(v.currentTime+Number(b.dataset.videoSkip)));
 ['loadedmetadata','durationchange','timeupdate','seeked','emptied'].forEach(event=>v.addEventListener(event,sync));sync();
 v.addEventListener('play',()=>{panel.querySelectorAll('video').forEach(other=>{if(other!==v)other.pause();});});v.addEventListener('error',()=>v.closest('article').querySelector('.videoError').hidden=false);});
 document.body.classList.add('topic-resource-open');document.dispatchEvent(new CustomEvent('teaching-media',{detail:{open:true}}));if(!panel.open)panel.showModal();panel.scrollTop=0;panel.querySelector('.closeResources').focus();
}
export function bindResourceButtons(host){host.querySelectorAll('[data-topic-video],[data-topic-notes]').forEach(b=>b.onclick=e=>{e.stopPropagation();openTopic(b.dataset.topicVideo||b.dataset.topicNotes,b.dataset.topicVideo?'video':'notes');});}
export function createVideoLibrary(hud){
 const group=document.createElement('div');group.id='sceneLearningControls';hud.append(group);
 const button=document.createElement('button');button.id='videoLibrary';button.textContent='▶ 视频';button.hidden=true;group.append(button);
 const exam=document.createElement('button');exam.id='topicExam';exam.textContent='考题';exam.setAttribute('aria-label','打开本主题考题');exam.hidden=true;group.append(exam);
 let key=null,examKey=null;const update=()=>{const board=document.querySelector('#microDetail'),available=board?.classList.contains('shown');key=available?board.querySelector('[data-topic-video]')?.dataset.topicVideo:null;examKey=available?board.querySelector('[data-topic-notes]')?.dataset.topicNotes:null;button.hidden=!key;exam.hidden=!examKey;};
 button.onclick=()=>{if(key)openTopic(key,'video');};exam.onclick=()=>{if(examKey)openTopic(examKey,'notes');};new MutationObserver(update).observe(document.querySelector('#microDetail'),{childList:true,attributes:true,attributeFilter:['class'],subtree:true});update();
}
