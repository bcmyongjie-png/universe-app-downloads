import audienceUrl from './audience-window.html';
let popup,channel,latest,handlers,url,decoration,targetScreen;
export function closeAudience(){
 targetScreen=null;
 channel?.postMessage({type:'end-projection'});
 if(popup&&!popup.closed)popup.close();
 popup=null;
}
export function fullscreenAudience(){
 if(!popup||popup.closed||!targetScreen)return false;
 try{popup.postMessage({type:'universe-fullscreen',target:targetScreen},{targetOrigin:location.origin,delegate:'fullscreen'});return true;}catch{return false;}
}
window.addEventListener('message',e=>{
 if(e.origin!==location.origin||e.source!==popup)return;
 if(e.data?.type==='universe-ready')fullscreenAudience();
});
export function updateDecoration(state){decoration=state;if(channel)channel.postMessage({type:'decoration',...state});}
export function audienceLink(){prepareAudience();return url;}
export function updateAudience(state,actions){latest=state;handlers=actions;if(channel)channel.postMessage({type:'slide',...state});}
function prepareAudience(){
 if(!channel){const id='universe-presenter-'+crypto.randomUUID();channel=new BroadcastChannel(id);
 channel.onmessage=e=>{if(e.data?.type==='display-status'){window.dispatchEvent(new CustomEvent('audience-display-status',{detail:{fullscreen:e.data.fullscreen===true,fullscreenSupported:e.data.fullscreenSupported!==false,onTarget:!!targetScreen&&e.data.left+e.data.width/2>=targetScreen.left&&e.data.left+e.data.width/2<targetScreen.left+targetScreen.width&&e.data.top+e.data.height/2>=targetScreen.top&&e.data.top+e.data.height/2<targetScreen.top+targetScreen.height}}));return;}if(e.data?.type==='ready'&&latest){channel.postMessage({type:'slide',...latest});if(decoration)channel.postMessage({type:'decoration',...decoration});}if(e.data?.type==='advance')handlers?.advance();if(e.data?.type==='back')handlers?.back();};
 url=audienceUrl+'#'+id;}}
export function openAudience(screen,manual=false){
 if(!screen&&!manual)return false;
 prepareAudience();
 targetScreen=screen?{left:screen.availLeft,top:screen.availTop,width:screen.availWidth,height:screen.availHeight}:null;
 if(popup&&!popup.closed){if(screen){popup.moveTo(screen.availLeft,screen.availTop);popup.resizeTo(screen.availWidth,screen.availHeight);fullscreenAudience();}else popup.focus();channel.postMessage({type:'status-request'});return true;}
 const placement=screen?`,left=${screen.availLeft},top=${screen.availTop},width=${screen.availWidth},height=${screen.availHeight},fullscreen=yes`:',width=960,height=640';const launchUrl=screen?url.replace('#','?autofull=1#'):url;popup=window.open(launchUrl,'universe-student-screen','popup'+placement);
 if(!popup)return false;return true;
}
