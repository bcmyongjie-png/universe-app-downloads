const {setupUpdates}=require('./updates.cjs'),{EventEmitter}=require('events'),assert=require('assert/strict'),crypto=require('crypto'),fs=require('fs'),os=require('os'),path=require('path');
(async()=>{for(const platform of ['win32','darwin']){
 const handlers={},frame={},contents={mainFrame:frame,send(){}},event={sender:contents,senderFrame:frame};let downloaded=0,installed=0,response=0,finishPreparation;const preparation=new Promise(resolve=>{finishPreparation=resolve;});
 const bytes=Buffer.from('verified Mac test download'),manifest={edition:'teacher',version:'2.1.2',size:bytes.length,sha512:crypto.createHash('sha512').update(bytes).digest('base64'),url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/download/offline-v2.1.2/teacher.dmg'};
 const updater=new EventEmitter();updater.setFeedURL=()=>{};updater.checkForUpdates=async()=>{updater.emit('update-available',{version:'2.1.2'});return {updateInfo:{version:'2.1.2'}}};updater.downloadUpdate=async()=>{downloaded++;updater.emit('update-downloaded',{version:'2.1.2'})};updater.quitAndInstall=()=>{installed++};
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'universe-consent-'));
 const controller=setupUpdates({platform,updater,beforeInstall:()=>preparation,app:{getVersion:()=> '2.1.1',isPackaged:false,getPath:()=>root},ipcMain:{handle:(name,fn)=>handlers[name]=fn},main:{webContents:contents,isDestroyed:()=>false},edition:{student:false},runtime:{dialog:{showMessageBox:async()=>({response})},shell:{openPath:async()=>{installed++;return ''}}},fetcher:async url=>{if(url.endsWith('-mac.json'))return new Response(JSON.stringify(manifest));downloaded++;return new Response(bytes)}});
 await controller.check();assert.equal(controller.getState().phase,'available');assert.equal(downloaded,0,'Checking must never download');
 if(platform==='win32'){assert.equal(updater.autoDownload,false);assert.equal(updater.autoInstallOnAppQuit,false)}
 await handlers['universe:update-download']({sender:{},senderFrame:{}});assert.equal(downloaded,0,'Untrusted frame cannot approve');
 await handlers['universe:update-download'](event);assert.equal(downloaded,1);assert.equal(controller.getState().phase,'ready');assert.equal(installed,0,'Download completion must not install');
 if(platform==='win32'){
  await handlers['universe:update-install'](event);assert.equal(installed,0,'Declining installation keeps the current app');
  response=1;const pending=handlers['universe:update-install'](event);await new Promise(resolve=>setImmediate(resolve));
  assert.equal(installed,0,'The installer must wait for projector cleanup, before it can replace the running app');
  finishPreparation();await pending;assert.equal(installed,1);
 }else{
  assert.equal(await handlers['universe:update-install']({sender:{},senderFrame:{}}),false);assert.equal(installed,0);
  assert.equal(await handlers['universe:update-install'](event),true);assert.equal(installed,1,'Only the approved Mac action may open the verified DMG');
 }
 console.log(platform+': consent gates PASS; no automatic download/install, explicit trusted download only');
 // An immediate network failure can send its final event before IPC resolves.
 // The IPC response must not overwrite that event with the stale checking state.
 const sent=[],failedUpdater=new EventEmitter();failedUpdater.setFeedURL=()=>{};failedUpdater.checkForUpdates=async()=>{throw Error('offline')};
 const failedContents={...contents,send:(_name,s)=>sent.push(s)};
 const retryHandlers={};setupUpdates({platform,updater:failedUpdater,app:{getVersion:()=> '2.2.14',isPackaged:false},ipcMain:{handle:(name,fn)=>retryHandlers[name]=fn},main:{webContents:failedContents,isDestroyed:()=>false},edition:{student:false},runtime:{dialog:{},shell:{}},fetcher:async()=>{throw Error('offline')}});
 const finalState=await retryHandlers['universe:update-check']({sender:failedContents,senderFrame:frame});
 assert.equal(finalState.phase,'unavailable','IPC must resolve to the final state, never stale checking');
 assert.equal(sent.at(-1).phase,finalState.phase);
 console.log(platform+': immediate offline failure cannot overwrite the final update status PASS');
}})().catch(e=>{console.error(e);process.exit(1)});
