const {build,Platform,Arch}=require('electron-builder');
const fs=require('fs'),path=require('path');
(async()=>{
 if(process.platform==='win32')require('child_process').execFileSync(path.join(process.env.SystemRoot,'Microsoft.NET/Framework64/v4.0.30319/csc.exe'),['/nologo','/target:winexe','/platform:x64','/out:'+path.join(__dirname,'Universe-Display.exe'),path.join(__dirname,'DisplayMode.cs')],{stdio:'inherit',windowsHide:true});
 for(const student of [false,true]){
  const edition=student?'Student':'Teacher',lower=edition.toLowerCase();
  fs.writeFileSync('edition.json',JSON.stringify({student}));fs.copyFileSync(lower+'-512.png','icon.png');
  const mac=process.platform==='darwin';
  await build({publish:'never',targets:mac?Platform.MAC.createTarget(['dmg'],Arch.universal):Platform.WINDOWS.createTarget(['nsis'],Arch.x64),config:{
   appId:'net.yurenedu.universe.'+lower,productName:'Universe '+edition,
   artifactName:'Universe-'+edition+'-Offline-'+require('./package.json').version+'-'+(mac?'Mac.dmg':'Setup.exe'),directories:{output:'dist/'+lower},
   files:['main.cjs','preload.cjs','updates.cjs','local-content.cjs','edition.json','icon.png','package.json'],asar:true,
   extraResources:[{from:'web/'+lower,to:'course'},...(!mac?[{from:'Universe-Display.exe',to:'Universe-Display.exe'}]:[])],
   mac:{category:'public.app-category.education',icon:'icon.png',identity:'-',hardenedRuntime:false,notarize:false},
   dmg:{format:'ULFO',writeUpdateInfo:false,title:'Universe '+edition,contents:[{x:130,y:150,type:'file'},{x:410,y:150,type:'link',path:'/Applications'}]},
   win:{signAndEditExecutable:false},nsis:{differentialPackage:false,oneClick:true,perMachine:false,createDesktopShortcut:true,runAfterFinish:false,deleteAppDataOnUninstall:false},publish:{provider:'generic',url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/latest/download/',channel:lower}
  }});
 }
})().catch(e=>{console.error(e);process.exit(1)});
