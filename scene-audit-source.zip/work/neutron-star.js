import * as T from 'three';

// Pulsar illustration: a compact star and two radiation beams, not a solid jet
// through the star. Rotation is deliberately slowed for classroom viewing.
export function neutronStar(w,body,r){
 body.material.dispose();
 body.material=new T.ShaderMaterial({
  vertexShader:`varying vec3 localNormal,worldNormal,worldPosition;
   void main(){localNormal=normal;worldNormal=normalize(mat3(modelMatrix)*normal);
    worldPosition=(modelMatrix*vec4(position,1.)).xyz;
    gl_Position=projectionMatrix*viewMatrix*vec4(worldPosition,1.);}`,
  fragmentShader:`varying vec3 localNormal,worldNormal,worldPosition;
   void main(){float facing=max(dot(normalize(worldNormal),normalize(cameraPosition-worldPosition)),0.);
    float pole=pow(abs(dot(normalize(localNormal),normalize(vec3(.48,.88,0.)))),24.);
    float relief=.7+.3*max(dot(normalize(worldNormal),normalize(vec3(-.45,.6,1.))),0.);
    vec3 surface=mix(vec3(.008,.024,.06),vec3(.10,.22,.34),pow(facing,.75))*relief;
    surface+=vec3(.07,.075,.06)*pole;
    gl_FragColor=vec4(surface,1.);}`
 });
 const glow=w.addGlow(body,'#81caff',r*3.2);glow.material.uniforms.tint.value.multiplyScalar(.3);
 const poles=new T.Group();poles.rotation.z=-.5;body.add(poles);
 const length=r*2.5;
 for(const sign of [-1,1]){
  const beam=new T.Mesh(new T.CylinderGeometry(r*.65,r*.12,length,32,12,true),new T.ShaderMaterial({
   transparent:true,depthWrite:false,side:T.FrontSide,blending:T.AdditiveBlending,
   vertexShader:`varying vec2 vUv;varying vec3 n,p;
    void main(){vUv=uv;n=normalize(mat3(modelMatrix)*normal);p=(modelMatrix*vec4(position,1.)).xyz;
     gl_Position=projectionMatrix*viewMatrix*vec4(p,1.);}`,
   fragmentShader:`varying vec2 vUv;varying vec3 n,p;
    void main(){float q=vUv.y;
     float endFade=1.-smoothstep(.05,1.,q);
     float edge=pow(abs(dot(normalize(n),normalize(cameraPosition-p))),1.6);
     float a=smoothstep(0.,.09,q)*endFade*edge*.36;
     gl_FragColor=vec4(mix(vec3(.48,.79,1.),vec3(.1,.38,.72),q),a);}`
  }));
  beam.position.y=sign*(r*.9+length*.5);if(sign<0)beam.rotation.z=Math.PI;
  poles.add(beam);
 }
}
