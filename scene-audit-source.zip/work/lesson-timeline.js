// Short prompts: one visible action at a time.
const stages = {
  "galaxy": [
    "看星系的中心",
    "看星系的形状",
    "比较不同星系"
  ],
  "birth": [
    "一大团气体和尘埃",
    "引力把气体拉在一起",
    "中心越来越紧",
    "中心越来越热"
  ],
  "fusion": [
    "核聚变发生在核心",
    "氢转变成氦，释放能量",
    "能量逐渐传向表面",
    "表面向外辐射光和热"
  ],
  "giant": [
    "像太阳这样的恒星",
    "中心的氢快用完",
    "外层变大、变冷",
    "成为红巨星"
  ],
  "supernova": [
    "质量很大的恒星",
    "中心向内塌下",
    "发生大爆炸",
    "物质散到太空"
  ],
  "remnants": [
    "1. Nebula 星云: gas berkumpul.",
    "2. Bintang biasa 普通恒星 terbentuk.",
    "3. Bintang membesar 变大.",
    "4. Tinggal kerdil putih 白矮星.",
    "5. Sekarang: bintang besar 大质量恒星.",
    "6. Menjadi super raksasa 红超巨星.",
    "7. Supernova: bintang meletup 爆炸.",
    "8. Bintang neutron ATAU lohong hitam."
  ],
  "spectrum": [
    "红色恒星比较冷",
    "黄色和白色恒星",
    "蓝色恒星比较热"
  ],
  "brightness": [
    "两颗一样的恒星",
    "右边的恒星变远",
    "越远，看起来越暗"
  ],
  "spaceflight": [
    "火箭从地面升起",
    "火箭越飞越高",
    "进入太空"
  ],
  "sunlife": [
    "太阳带来光和热",
    "想一想：阳光变少了",
    "地球收到的能量变少"
  ],
  "starsize": [
    "先看矮星",
    "再看巨星",
    "比较超巨星的大小"
  ],
  "sizes": [
    "里面四颗岩石行星",
    "木星和土星",
    "天王星和海王星"
  ],
  "au": [
    "光从太阳出发",
    "光向地球前进",
    "1 AU 约是 1.5 亿千米"
  ],
  "lightyear": [
    "光向前走",
    "走过的距离越来越长",
    "光年表示距离"
  ],
  "orbit": [
    "行星绕太阳走",
    "里面的行星走得更快",
    "比较谁先绕完一圈"
  ],
  "rotation": [
    "地球绕自己的轴转",
    "金星朝相反方向转",
    "天王星像侧躺着转"
  ],
  "greenhouse": [
    "阳光照到地面",
    "地面变热，再向外散热",
    "大气让部分热量留下"
  ],
  "gravity": [
    "从同样高度放开",
    "比较各行星的引力",
    "看看哪个先落地"
  ],
  "moons": [
    "找到地球和月球",
    "月球绕着地球走",
    "月球绕完一圈"
  ],
  "daynight": [
    "朝向太阳是白天",
    "地球转动，太阳落下",
    "背向太阳是夜晚"
  ],
  "habitat": [
    "地球上有液态水",
    "空气中有氧气，肉眼看不见",
    "适宜温度让液态水存在"
  ],
  "climate": [
    "地球转得较快",
    "想一想：地球转慢了",
    "白天和夜晚都变长"
  ],
  "footprint": [
    "用了很多自然资源",
    "试着减少浪费",
    "一起保护地球"
  ],
  "composition": [
    "流星体：岩石或金属",
    "小行星：岩石或金属",
    "彗星：冰、尘埃和岩石"
  ],
  "speeds": [
    "一起出发",
    "在相同时间内，谁走得远",
    "这些速度是比较用的例子"
  ],
  "belt": [
    "先找到火星",
    "小行星带在火星和木星之间",
    "小行星绕太阳运行"
  ],
  "meteor": [
    "太空里：流星体",
    "发光轨迹：流星",
    "掉到地面的固体：陨石"
  ],
  "shower": [
    "抬头看夜空",
    "看流星划过",
    "更多碎片进入大气"
  ],
  "near": [
    "比较地球和小行星轨道",
    "天体沿路线前进",
    "路线交叉，不一定相撞"
  ],
  "deflect": [
    "先看原来的路线",
    "早点改变一点方向",
    "最后避开地球"
  ],
  "comet": [
    "远离太阳时",
    "靠近太阳，冰变成气体",
    "离子尾背向太阳，尘埃尾较弯"
  ],
  "planet": [
    "看看这颗行星",
    "看表面怎样移动",
    "行星绕自己的轴转"
  ],
  "comparison": [
    "选一个项目",
    "看看柱子有多高",
    "柱子越高，数值越大"
  ],
  "conversion": [
    "输入数字和单位",
    "换成另一种单位",
    "比较千米、AU 和光年"
  ],
  "locked": [
    "记住月球上的标记",
    "月球一边转，一边绕地球",
    "同一面一直朝向地球"
  ],
  "impact": [
    "天体接近地面",
    "撞到水面",
    "波纹向外散开"
  ],
  "sextant": [
    "先找到地平线",
    "把仪器对准恒星",
    "读出角度"
  ]
}
;
export function lessonSequence(d){
 if(!stages[d.kind])throw new Error('Missing animation sequence: '+d.kind);
 return {stages:stages[d.kind],stops:d.kind==='remnants'?[0,.16,.28,.4,.52,.64,.76,.88]:null,duration:d.kind==='remnants'?44:['birth','fusion','giant','supernova'].includes(d.kind)?24:18};
}
export function createLessonTimeline(hud,{onPlaying,onSeek,onSpeed,onInspect}){
 const el=document.createElement('section');el.id='lessonTimeline';el.hidden=true;el.setAttribute('aria-label','课题动态演示');
 el.innerHTML='<span class="motionStage"></span><div class="motionControls"><button type="button" class="motionPlay" aria-label="暂停演示">Ⅱ</button><input class="motionSeek" type="range" min="0" max="1000" value="0" step="1" aria-label="课题演示进度"><button type="button" class="motionReplay" aria-label="重新播放演示">↻</button></div>';
 const speed=document.createElement('select');speed.className='motionSpeed';speed.setAttribute('aria-label','播放速度');speed.innerHTML='<option value="0.5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option>';el.querySelector('.motionControls').insertBefore(speed,el.querySelector('.motionReplay'));speed.onchange=()=>onSpeed(Number(speed.value));
 const inspect=document.createElement('button');inspect.type='button';inspect.className='motionInspect';inspect.textContent='近看天体';inspect.onclick=()=>onInspect();el.append(inspect);
 hud.append(el);const play=el.querySelector('.motionPlay'),seek=el.querySelector('input'),label=el.querySelector('.motionStage');let current=null,playing=false;
 const setPlaying=value=>{playing=value;play.textContent=value?'Ⅱ':'▶';play.setAttribute('aria-label',value?'暂停演示':'播放演示');play.setAttribute('aria-pressed',String(value));};
 play.onclick=()=>onPlaying(!playing);el.querySelector('.motionReplay').onclick=()=>{onSeek(0);onPlaying(true)};
 seek.oninput=()=>{const p=Number(seek.value)/1000;onPlaying(false);onSeek(p)};
 return {open(d,value){current=lessonSequence(d);el.hidden=false;el.dataset.kind=d.kind;inspect.hidden=d.kind!=='remnants';this.sync(0,value)},close(){el.hidden=true;current=null},sync(p,value){if(!current)return;setPlaying(value);if(document.activeElement!==seek)seek.value=String(Math.round(p*1000));const i=current.stops?Math.max(0,current.stops.filter(stop=>p>=stop).length-1):Math.min(current.stages.length-1,Math.floor(p*current.stages.length));label.textContent=current.stages[i];el.dataset.stage=String(i);seek.setAttribute('aria-valuetext',Math.round(p*100)+'% · '+current.stages[i]);}};
}

