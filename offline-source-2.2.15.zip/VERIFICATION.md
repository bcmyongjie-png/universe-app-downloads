# Universe Offline 2.0.0

The teacher and student editions load from a locally intercepted HTTPS origin inside Electron. The handler only reads the packaged `resources/course` directory. External renderer HTTP(S) and WebSocket requests are blocked; there is no remote course fallback or service-worker dependency.

Teacher content: 1,747 assets, 219,665,832 bytes, including four topic videos and the original slide material. Student content: 25 assets, 68,215,638 bytes, including the four topic videos; original teacher slides remain excluded by edition design. App code and the Electron runtime are additional.

Local validation passed:

- SHA-256 and byte lengths for every bundled asset.
- Video range responses: explicit ranges, suffix ranges, open-ended ranges, invalid ranges, and HEAD requests.
- Foreign origin and missing file handling.
- Both editions' 46 scenes in Chromium with every request served from local files; zero external requests and zero page errors.
- Independent teacher audience window displays local slide files; private overview leaves the audience unchanged, selecting another slide synchronizes it.
- Download site Chromium and WebKit layout checks at 320, 390, 768 and 1440 pixels.

CI workflow: https://github.com/bcmyongjie-png/universe-app-downloads/actions/runs/34667258875

Final CI result: Windows and macOS build/test jobs and the release job all succeeded. All four production download buttons were clicked and returned the expected installer filenames. Production Chromium and WebKit layout/guide checks passed. Download site deployment: `dpl_BoCRZ6xWHHwr4cay3JtVGHYW7XF6`.

Published installers: Windows Teacher 253,298,270 bytes; Windows Student 167,273,377 bytes; universal Mac Teacher 445,803,377 bytes; universal Mac Student 293,829,027 bytes. Release: https://github.com/bcmyongjie-png/universe-app-downloads/releases/tag/offline-v2.0.0

CI tests launch the actual packaged applications with fresh user-data directories, external DNS disabled and external renderer traffic blocked. They check both editions' scene navigation, all video playback and seeking, and native bridge availability. Mac artifacts are also checked for arm64/x86_64 universal binaries, valid ad-hoc signatures, and DMG integrity.

Physical projector hardware is not available in CI. Mac binaries are ad-hoc signed, not Developer ID signed or notarized. Optional external reference websites and future installer downloads require internet; the bundled classroom content does not.
