import {prepareTextures} from './scene-textures.js';
// Keep the last canvas frame while the GPU compiles a newly selected scene.
// compileAsync uses parallel shader compilation when supported by the driver.
export function prepareScene(world){
 const ticket={start:performance.now()};world.scenePreparing=ticket;
 const labels=world.host?.ownerDocument.querySelector('#labels');
 if(labels)labels.style.visibility='hidden';
 return world.scenePreparation=prepareTextures(world).then(()=>{
  if(world.scenePreparing!==ticket)return;
  // Match RenderPass's offscreen target, otherwise the first actual frame
  // compiles a different colour-space variant and blocks again.
  const previous=world.renderer.getRenderTarget();
  world.renderer.setRenderTarget(world.composer.readBuffer);
  try{return world.renderer.compileAsync(world.scene,world.camera);}
  finally{world.renderer.setRenderTarget(previous);}
 })
  .catch(error=>console.warn('Scene preparation failed; retrying during render.',error))
  .finally(()=>{if(world.scenePreparing===ticket){
   if(world.fly)world.fly.start+=performance.now()-Math.max(ticket.start,world.fly.start);
   world.scenePreparing=null;
   // Positions are calculated on the next render frame before labels reappear.
   world.revealLabels=labels;
  }});
}

export function releaseSceneObjects(root,preparation){
 const resources=new Set();
 root.traverse(o=>{if(o.geometry)resources.add(o.geometry);if(o.material)for(const m of [].concat(o.material))resources.add(m);});
 const dispose=()=>resources.forEach(r=>r.dispose());
 // An older async compile may still be reading these materials after a quick
 // second navigation. Dispose only once its compilation has completed.
 if(preparation)Promise.resolve(preparation).then(dispose,dispose);else dispose();
}
