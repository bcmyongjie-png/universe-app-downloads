import * as T from 'three';

// Soyuz-inspired teaching model. Dimensions and ascent time are compressed.
// Four tapered strap-on boosters surround the core; no spacecraft windows
// are visible through the protective payload fairing.
export function launchVehicle(w){
 const rocket=new T.Group();rocket.name='launch-vehicle';w.root.add(rocket);
 const paint=new T.MeshStandardMaterial({color:'#d9dedb',roughness:.66,metalness:.18});
 const green=new T.MeshStandardMaterial({color:'#67776c',roughness:.65,metalness:.25});
 const steel=new T.MeshStandardMaterial({color:'#67727a',roughness:.43,metalness:.7});
 const dark=new T.MeshStandardMaterial({color:'#202b30',roughness:.55,metalness:.5});
 const orange=new T.MeshStandardMaterial({color:'#a34827',roughness:.7,metalness:.15});
 function mesh(parent,geometry,material,y=0){const m=new T.Mesh(geometry,material);m.position.y=y;parent.add(m);return m;}
 function lathe(parent,profile,material){return mesh(parent,new T.LatheGeometry(profile.map(([r,y])=>new T.Vector2(r,y)),32),material);}
 function ring(parent,r,y,material=steel){const m=mesh(parent,new T.TorusGeometry(r,.012,5,32),material,y);m.rotation.x=Math.PI/2;return m;}
 function cylinder(parent,r,h,y,material){return mesh(parent,new T.CylinderGeometry(r,r,h,24),material,y);}
 function strut(parent,a,b,r=.015){const start=new T.Vector3(...a),end=new T.Vector3(...b),delta=end.clone().sub(start);const m=mesh(parent,new T.CylinderGeometry(r,r,delta.length(),8),steel);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return m;}
 // Core and upper stage, with exposed lattice interstage and rounded fairing.
 lathe(rocket,[[.25,0],[.28,.2],[.25,1.55],[.18,2.55],[.18,2.8]],green);
 cylinder(rocket,.182,.24,2.75,dark);
 for(let i=0;i<8;i++){const a=i*Math.PI/4,b=a+Math.PI/4;strut(rocket,[Math.cos(a)*.19,2.64,Math.sin(a)*.19],[Math.cos(b)*.19,2.88,Math.sin(b)*.19],.013);}
 cylinder(rocket,.205,.65,3.17,paint);
 lathe(rocket,[[.205,3.49],[.29,3.68],[.29,4.15],[.27,4.31],[.19,4.47],[.075,4.62],[0,4.66]],paint);
 cylinder(rocket,.045,.43,4.84,paint);lathe(rocket,[[.045,5.05],[0,5.21]],steel);
 for(const [r,y] of [[.273,.22],[.245,1.6],[.182,2.54],[.209,2.9],[.209,3.45],[.293,3.72],[.293,4.12]])ring(rocket,r,y);
 cylinder(rocket,.253,.095,1.58,orange);cylinder(rocket,.208,.075,3.44,orange);
 strut(rocket,[.253,.25,0],[.253,1.5,0],.019);
 const plumeGeometry=new T.CylinderGeometry(.1,.48,1,24,14,true);plumeGeometry.translate(0,-.5,0);
 const plumes=[];
 function exhaust(parent,x,z,y,scale=1){
  const material=new T.ShaderMaterial({uniforms:{time:{value:0},power:{value:1}},transparent:true,depthWrite:false,blending:T.AdditiveBlending,side:T.DoubleSide,
   vertexShader:`varying vec2 vUv;uniform float time;void main(){vUv=uv;vec3 p=position;float d=1.-uv.y;p.xz*=1.+.07*sin(d*23.-time*19.)*d;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
   fragmentShader:`varying vec2 vUv;uniform float time;uniform float power;void main(){float d=1.-vUv.y;float across=pow(abs(sin(vUv.x*3.14159265)),1.5);float flicker=.82+.18*sin(d*34.-time*27.+sin(vUv.x*25.));float fade=pow(1.-d,1.6);vec3 c=mix(vec3(1.,.92,.65),vec3(1.,.22,.025),smoothstep(.08,.7,d));gl_FragColor=vec4(c,across*fade*flicker*.82*power);}`});
  const m=new T.Mesh(plumeGeometry,material);m.position.set(x,y,z);m.scale.set(scale,scale*2.9,scale);parent.add(m);plumes.push({mesh:m,material,scale,parent});
 }
 function engineCluster(parent){
  for(let i=0;i<4;i++){const a=Math.PI/4+i*Math.PI/2,x=Math.cos(a)*.105,z=Math.sin(a)*.105;
   const bell=lathe(parent,[[.055,.03],[.045,-.025],[.052,-.08],[.088,-.19]],dark);bell.position.set(x,0,z);ring(bell,.086,-.18,steel);
  }
  exhaust(parent,0,0,-.19,.75);
 }
 engineCluster(rocket);
 const boosters=[];
 for(let i=0;i<4;i++){
  const a=Math.PI/4+i*Math.PI/2,booster=new T.Group();booster.name='strap-on-booster';rocket.add(booster);
  lathe(booster,[[.23,0],[.255,.2],[.23,1.15],[.16,1.85],[.045,2.35],[0,2.42]],green);
  cylinder(booster,.241,.09,.32,orange);ring(booster,.255,.2);ring(booster,.23,1.15);
  const fin=mesh(booster,new T.BoxGeometry(.29,.26,.035),steel,.12);fin.position.x=.3;fin.rotation.z=-.35;
  strut(booster,[.235,.4,0],[.18,1.7,0],.014);engineCluster(booster);
  boosters.push({group:booster,a});
 }
 // Cool fill reveals metal on the shaded side without making the body glow.
 const fill=new T.DirectionalLight('#b7d7f0',1.3);fill.position.set(-6,3,8);w.root.add(fill);
 const smooth=T.MathUtils.smoothstep;
 return (p,t)=>{
  rocket.position.set(-1.3+p*p*4,-.7+p*4.8,0);rocket.rotation.set(0,.35,-smooth(p,.18,1)*.6);
  const separation=smooth(p,.55,.8);
  for(const {group,a} of boosters){const radial=.49+separation*2;group.position.set(Math.cos(a)*radial,-separation*3.4,Math.sin(a)*radial);group.quaternion.setFromAxisAngle(new T.Vector3(Math.sin(a),0,-Math.cos(a)),separation*.65);group.rotateY(-a);group.visible=p<.94;}
  for(const flame of plumes){const side=flame.parent!==rocket,power=side?1-smooth(p,.53,.59):1;flame.material.uniforms.time.value=t;flame.material.uniforms.power.value=power;flame.mesh.visible=power>.01;flame.mesh.scale.y=flame.scale*(2.8+.13*Math.sin(t*23))*(1+p*.45);}
 };
}
