// Short vocabulary help beside Malay terms, not sentence translations.
export const malayGlosses={
 'ketinggian':'高度','berjisim besar':'质量很大','mengembang':'变大','berputar':'自转','mengelilingi':'绕着运行','pembelahan nuklear':'核裂变',
 'galaksi berpilin berpalang':'棒旋星系','galaksi berpilin':'旋涡星系','galaksi elips':'椭圆星系','galaksi tidak seragam':'不规则星系','Bima Sakti':'银河系','Sistem Suria':'太阳系','lengan berpilin':'旋臂','galaksi':'星系','bintang':'恒星','gas':'气体','debu':'尘埃','graviti':'引力','nebula':'星云','hidrogen':'氢','helium':'氦','teras':'中心','mampatan':'压缩','pelakuran nuklear':'核聚变','pelakuran':'核聚变','haba':'热','cahaya':'光','Matahari':'太阳','planet':'行星',
 'superraksasa merah':'红超巨星','raksasa merah':'红巨星','supernova':'超新星','kerdil putih':'白矮星','bintang neutron':'中子星','lohong hitam':'黑洞','ufuk peristiwa':'事件视界','suhu permukaan':'表面温度','kecerahan ketara':'看起来的亮度','kecerahan':'亮度','jejari':'半径','jisim':'质量','jarak':'距离','suhu':'温度','saiz':'大小','fotosintesis':'光合作用','rantaian makanan':'食物链','hiperraksasa':'特超巨星','superraksasa':'超巨星','raksasa':'巨星','kerdil':'矮星',
 'Utarid':'水星','Zuhrah':'金星','Bumi':'地球','Marikh':'火星','Musytari':'木星','Zuhal':'土星','Uranus':'天王星','Neptun':'海王星','gergasi gas':'气态巨行星','gergasi ais':'冰巨行星','gelang':'行星环','unit astronomi':'天文单位','tahun cahaya':'光年','laju':'速度','peredaran':'公转','putaran segerak':'同步自转','putaran':'自转','paksi':'轴','orbit':'轨道','tempoh':'所需时间','barat':'西','timur':'东','utara':'北','atmosfera':'大气层','karbon dioksida':'二氧化碳','kesan rumah hijau':'温室效应','rintangan udara':'空气阻力','berat':'重量',
 'satelit semula jadi':'天然卫星','Bulan':'月球','siang':'白天','malam':'夜晚','air cecair':'液态水','oksigen':'氧气','nitrogen':'氮气','respirasi':'呼吸作用','pasang surut':'潮汐','jejak ekologi':'生态足迹','karbon':'碳','kawasan binaan':'建筑用地','hutan':'森林','tanaman':'农作物','ragut':'放牧','perikanan':'渔业','biokapasiti':'自然承受能力','habitat':'生物的家园',
 'meteoroid':'流星体','meteorit':'陨石','meteor':'流星','asteroid':'小行星','komet':'彗星','ais':'冰','batu':'岩石','logam':'金属','koma':'彗发','ekor':'尾巴','nukleus':'彗核','jalur utama':'主小行星带','planet kerdil':'矮行星','ablasi':'烧蚀','hujan meteor':'流星雨','kawah':'撞击坑','impak':'撞击','serpihan':'碎片','halaju':'速度与方向','teleskop':'望远镜','pemejalwapan':'升华','pepejal':'固体','angin suria':'太阳风','ekor ion':'离子尾','ekor debu':'尘埃尾','tsunami':'海啸','kepupusan':'灭绝','sekstan':'六分仪','sudut':'角度','altitud':'高度角','ufuk':'地平线','ketumpatan':'密度','diameter':'直径','oksida besi':'氧化铁','gunung berapi':'火山','ngarai':'峡谷','kutub':'两极','metana':'甲烷','Phobos':'火卫一','Deimos':'火卫二','Titan':'土卫六','Ribut Bintik Merah Besar':'大红斑风暴'
};
const safe=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function createGlossary(dictionary){
 const lookup=new Map(Object.entries(dictionary).map(([k,v])=>[k.toLowerCase(),v]));
 const pattern=new RegExp('(?<![A-Za-z])('+Object.keys(dictionary).sort((a,b)=>b.length-a.length).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')(?![A-Za-z])','gi');
 return function(source){
 // Match the source text before producing HTML, so labels cannot match themselves.
 return String(source).split('**').map((part,i)=>{
  let out='',last=0;for(const match of part.matchAll(pattern)){const meaning=match[0]==='moon'&&dictionary.Moon?'天然卫星':lookup.get(match[0].toLowerCase());out+=safe(part.slice(last,match.index))+safe(match[0])+'<span class="termZH" lang="zh-Hans">（'+meaning+'）</span>';last=match.index+match[0].length;}
  out+=safe(part.slice(last));return i%2?'<mark>'+out+'</mark>':out;
 }).join('');
 }; 
}
export const glossMalay=createGlossary(malayGlosses);
