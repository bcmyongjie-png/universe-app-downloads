const {test}=require('node:test'),assert=require('node:assert/strict');
const {classify}=require('./display-mode.cjs');
test('classifies actual desktop surfaces, including cross-adapter clones',()=>{
 const panel={Target:'gpu1:panel',Internal:true,X:0,Y:0,Width:1366,Height:768};
 const projector={Target:'gpu2:HDMI',Internal:false,SingleMode:'external',X:0,Y:0,Width:1366,Height:768};
 assert.equal(classify([panel]).mode,'internal');assert.equal(classify([projector]).mode,'external');
 assert.equal(classify([panel,projector]).mode,'clone');
 assert.equal(classify([panel,{...projector,X:-1920,Width:1920,Height:1080}]).mode,'extend');
 assert.equal(classify([panel,projector,{...projector,Target:'gpu2:DP',X:1366}]).mode,'mixed');
 assert.equal(classify([panel,projector]).signature,classify([projector,panel]).signature);
 assert.notEqual(classify([panel,projector]).signature,classify([panel,{...projector,Width:1920}]).signature);
});
test('a desktop PC main monitor can use HDMI; connector type alone cannot mean Second screen only',()=>{
 const monitor={Target:'gpu:HDMI',Internal:false,SingleMode:'internal',X:0,Y:0,Width:1920,Height:1080};
 assert.equal(classify([monitor]).mode,'internal');
 assert.throws(()=>classify([{...monitor,SingleMode:null}]));
});
test('missing or corrupt monitor data is never interpreted as Duplicate',()=>{
 for(const rows of [[],null,[{}],[{Target:'x',Internal:true,X:0,Y:0,Width:0,Height:1080}]])assert.throws(()=>classify(rows));
});
