import {axialTilts,progradePosition,lockMoon} from './celestial-motion.js';
import {stellarEvolution} from './stellar-evolution.js';
import {habitatScene,cometScene,nearEarthScene} from './natural-scenes.js';
import {launchVehicle} from './rocket-art.js';
import {pointsFor} from './teaching-content.js';
import {completeTopicMotion} from './topic-motion.js';
import {loadSceneTexture} from './scene-textures.js';
import {meteorScene} from './meteor-scene.js';
import {extendJourneys,drawNotesScene} from './notes-scenes.js';
import {nebula,atmosphere,accretion,saturnRings,flowTail} from './body-art.js';
import * as T from 'three';
import {planets} from './data.js';
import earthURL from './earth.jpg';
const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z);
const lesson=(kind,zh,bm,en,note,source,extra={})=>({kind,zh,bm,en,note,source,...extra});
export const journeys={
 galaxy:[
 lesson('galaxy','螺旋星系','Galaksi berpilin','Spiral galaxy','转动视角，观察明亮中心与展开的旋臂。银河系和仙女座星系属于这一类。','C11 · 4–7',{shape:'spiral'}),
 lesson('galaxy','椭圆星系','Galaksi elips','Elliptical galaxy','恒星构成平滑椭球，没有螺旋臂。课件例子：Messier 87。','C11 · 4–7',{shape:'elliptical'}),
 lesson('galaxy','不规则星系','Galaksi tidak seragam','Irregular galaxy','恒星分布没有规则轮廓。比较大、小麦哲伦云的类型。','C11 · 4–7',{shape:'irregular'}),
 lesson('birth','引力与星云','Tarikan graviti · Nebula','Gravity · Nebula','播放演示，让氢、氦与尘埃逐渐聚集；核心温度与压力升高。','C11 · 8–19'),
 lesson('fusion','核聚变','Pelakuran nuklear','Nuclear fusion','观察太阳内部剖面：核心中的氢转变成氦，释放能量。内部颜色与运动速度为教学示意。','C11 · 8、13、16'),
 lesson('giant','红巨星','Raksasa merah','Red giant','氢逐渐耗尽，外层膨胀。播放演示观察恒星体积的改变。','C11 · 8、14–19'),
 lesson('supernova','超新星','Supernova','Supernova','大质量恒星发生剧烈爆炸；播放演示，看外层物质向四周扩散。','C11 · 10、13–19'),
 lesson('remnants','恒星的一生','Kitar hidup bintang','Life cycle of a star','沿箭头观察完整演化：星云聚成原恒星，再按质量分成两条路线；普通恒星最终留下白矮星，大质量恒星爆发后可能留下中子星或黑洞。图中大小、位置与时间为教学示意。','C11 · 8–19'),
 lesson('spectrum','颜色与温度','Warna dan suhu','Colour and temperature','从红色到蓝色，表面温度总体升高。数值采用课件色温示意。','C11 · 20、28'),
 lesson('brightness','距离与亮度','Jarak dan kecerahan','Distance and brightness','两颗相同的恒星；播放演示，把右边的恒星推远，观察它看起来变小、变暗。','C11 · 20–28'),
 lesson('spaceflight','马来西亚的太空旅程','Perjalanan angkasa Malaysia','Malaysia’s space journey','随演示离开地球：Sheikh Muszaphar Shukor 于 2007 年 10 月 10 日进入太空。进入轨道与到达另一个星系，是截然不同的距离。','C11 · 4、6、26'),
 lesson('sunlife','如果太阳不再发光','Jika Matahari tidak bersinar','If the Sun stopped shining','播放演示让太阳的光逐渐减弱，观察地球变暗。失去太阳能量会影响温度、植物和食物链。此处是影响示意，不是太阳死亡过程的精确模拟。','C11 · 28'),
 lesson('starsize','恒星的大小','Saiz bintang','Sizes of stars','比较矮星、巨星和超巨星。体积差异采用教学比例；温度和大小都会影响恒星发光。','C11 · 23–28'),
 ],
 solar:[
 lesson('sizes','行星大小','Saiz planet','Planet sizes','八颗行星在同一尺度下排列。木、土、天、海、地、金、火、水是直径由大到小的顺序。','C12 · 7–8'),
 lesson('au','天文单位','Unit astronomi','Astronomical unit','太阳到地球的平均距离 = 1 AU ≈ 1.5 × 10⁸ km。播放演示，让光点走过这一段距离。','C12 · 4–6'),
 lesson('lightyear','光年','Tahun cahaya','Light year','光点走过一年对应的距离约 9.5 × 10¹² km。光年是距离，不是时间。','C12 · 4–6'),
 lesson('orbit','公转','Peredaran','Revolution','内圈行星更快完成一周，外圈行星需要更长时间。自转与公转是两种运动。','C12 · 10–23'),
 lesson('rotation','自转方向','Arah putaran','Direction of rotation','观察球体标线：地球由西向东，金星逆向，天王星的自转轴接近侧躺。','C12 · 7–8、22'),
 lesson('greenhouse','温室效应','Kesan rumah hijau','Greenhouse effect','比较水星与金星：金星浓厚大气阻碍热量散失，所以更热；距太阳近并不是唯一条件。','C12 · 7、13'),
 lesson('gravity','引力','Tarikan graviti','Gravitational pull','同一高度释放相同小球，比较水星、地球、木星的落下过程。轨迹与时间为教学示意。','C12 · 20'),
 lesson('moons','天然卫星','Satelit semula jadi','Natural satellites','月球绕地球运行；卫星绕行星，行星再绕太阳。环系统则由许多小颗粒组成。','C12 · 8、24'),
 ],
 earth:[
 lesson('daynight','昼与夜','Siang dan malam','Day and night','拖动看昼夜分界；播放演示，观察地球自转带来的昼夜交替。','C12 · 25'),
 lesson('habitat','宜居条件','Syarat untuk hidupan','Conditions for life','观察地球的海洋、云层与大气。液态水和适宜温度支持生命，空气中的氧气肉眼看不见。','C12 · 24、26–28'),
 lesson('climate','自转减慢','Putaran semakin perlahan','Slower rotation','播放演示，比较长时间受光与背光的一面：受光区更热，背光区更冷，潮汐时序也会改变。','C12 · 25'),
 lesson('footprint','生态足迹','Jejak ekologi','Ecological footprint','观察地球的陆地与海洋。减少浪费、节水和节能，是保护地球的行动。','C12 · 3、28'),
 ],
 visitors:[
 lesson('composition','其他天体','Jasad lain','Other bodies','左：岩石和金属的流星体；中：更大的小行星；右：含冰、气体和尘埃的彗星。','C13 · 3–6'),
 lesson('speeds','速度与尺度','Kelajuan dan saiz','Speed and scale','三条运动轨迹对照课件速度：流星体约 42、小行星约 25、彗星约 10–70 km/s。这是教学比较，真实天体速度各不相同。','C13 · 4'),
 lesson('belt','小行星带','Jalur asteroid','Asteroid belt','在火星与木星的轨道之间发现主带。课件列举 Ceres、Pallas、Juno、Vesta。','C13 · 4、12'),
 lesson('meteor','流星体 → 流星 → 陨石','Meteoroid → Meteor → Meteorit','Meteoroid → Meteor → Meteorite','播放演示：太空碎片进入大气，产生发光轨迹，残留物到达地表。','C13 · 7–18'),
 lesson('shower','流星雨','Pancuran meteor','Meteor shower','地球穿过碎屑流，细小碎片在大气中发光并烧蚀。较大天体造成的撞击坑在相关演示中单独比较。','C13 · 7、15–18'),
 lesson('near','近地轨道','Orbit berhampiran Bumi','Near-Earth orbits','观察靠近、交叉和重叠的轨道示意。轨道接近并不意味着必然撞击，还取决于相遇时间。','C13 · 19–23'),
 lesson('deflect','改变轨道','Mengubah orbit','Deflecting an orbit','提前发现并轻微改变天体速度，经过足够时间后可让它错过地球。播放演示比较原轨迹与偏转轨迹。','C13 · 23 · 防御概念拓展'),
 lesson('comet','升华与彗尾','Pemejalwapan · Ekor komet','Sublimation · Comet tail','播放演示带彗星靠近太阳：彗尾变明显，并总体背离太阳；绕行时方向也随之改变。','C13 · 24–26'),
 ]
};
extendJourneys(journeys);
// Use the same short explanations in scenes, teaching panels and revision notes.
for(const [track,lessons] of Object.entries(journeys))lessons.forEach((d,index)=>{
 d.points=pointsFor(d,track,index);
 d.note=d.points.map(p=>p[2]).join(' ').replace(/\*\*/g,'');
});
function sphere(w,id,r,color,pos=V(),emissive=false){const m=w.sphere(id,r,color,emissive?5:0);m.position.copy(pos);return m;}
function earth(w,r=3,pos=V()){let m=sphere(w,'viz-earth',r,'#4a9fdb',pos);m.material.dispose();const tex=loadSceneTexture(earthURL,{colorSpace:T.SRGBColorSpace});tex.colorSpace=T.SRGBColorSpace;m.material=new T.MeshPhongMaterial({map:tex,shininess:12});return m;}
function label(w,obj,text,offset=V(0,1,0)){if(!obj.userData.lessonLabel)obj.userData.lessonLabel=text;w.label(obj.userData.id||'viz-label',text.split(' / ')[0],obj,offset);}
function line(w,points,color='#78cfff',opacity=.65){const m=new T.Line(new T.BufferGeometry().setFromPoints(points),new T.LineBasicMaterial({color,transparent:true,opacity}));w.root.add(m);return m;}
function cloud(w,n=3000,r=8){return nebula(w,n,r);}
function halo(w,body,r,color='#7dbdff'){const mesh=atmosphere(r,color,.22);body.add(mesh);return mesh;}
function axis(w,body,r){let a=new T.ArrowHelper(V(0,1,0),V(0,-r*1.5,0),r*3,'#bbdfff',.3,.14);body.add(a);const stripe=new T.Mesh(new T.TorusGeometry(r*1.02,.025,6,80),new T.MeshBasicMaterial({color:'#e5f3ff'}));stripe.rotation.y=Math.PI/2;body.add(stripe);}
export function drawLesson(w,d){
 w.clear();w.mode='lesson';w.controls.target.set(0,0,0);w.camera.position.set(0,6,25);w.controls.update();let update=()=>{};
 if(['habitat','daynight','climate','footprint'].includes(d.kind))return completeTopicMotion(w,d,habitatScene(w,d.kind));
 if(d.kind==='near')return completeTopicMotion(w,d,nearEarthScene(w));
 if(d.kind==='comet')return completeTopicMotion(w,d,cometScene(w));
 const evolution=stellarEvolution(w,d);if(evolution)return completeTopicMotion(w,d,evolution);
 if(d.kind==='galaxy'){w.galaxyKind=d.shape;w.makeGalaxy({showSolarSystem:false});w.hotspots=w.hotspots.filter(h=>{if(['star','life'].includes(h.id))return true;h.el.remove();return false;});w.camera.position.set(0,28,43);w.controls.update();update=(p,t)=>{w.root.rotation.y=p*.7;};}
 if(d.kind==='spectrum'){const colors=['#f64a32','#ff9a43','#ffe35f','#fff0b1','#fff','#b6deff','#68a4ff'],words=['红 / Merah / Red','橙 / Jingga / Orange','黄 / Kuning / Yellow','黄白 / Kuning-putih / Yellowish-white','白 / Putih / White','蓝白 / Biru-putih / Bluish-white','蓝 / Biru / Blue'],temps=['<3500 K','3500–5000 K','5000–6000 K','6000–7500 K','7500–11000 K','11000–25000 K','>25000 K'];colors.forEach((c,i)=>{let x=(i-3)*3,m=sphere(w,'viz-color-'+i,.8,c,V(x,0,0),true);label(w,m,words[i],V(0,2,0));label(w,m,temps[i],V(0,-1.8,0));w.hotspots[w.hotspots.length-1].el.classList.add('spectrumTemperature');});w.camera.position.set(0,6,31);w.controls.update();update=p=>{const active=Math.min(6,Math.floor(p*7));w.hotspots.filter(h=>h.el.classList.contains('spectrumTemperature')).forEach((h,i)=>h.el.style.visibility=i===active?'':'hidden');};}
 if(d.kind==='brightness'){let left=sphere(w,'viz-near',1.5,'#ffe3a0',V(-5,0,0),true),right=sphere(w,'viz-far',1.5,'#ffe3a0',V(5,0,0),true);w.addGlow(left,'#ffc363',6);w.addGlow(right,'#ffc363',6);label(w,left,'相同恒星 / Bintang sama / Same star',V(0,2.5,0));update=p=>{right.position.z=-p*45;};line(w,[V(5,0,0),V(5,0,-45)]);}
 if(d.kind==='starsize'){[.4,2,4.4].forEach((r,i)=>{const m=sphere(w,'viz-size'+i,r,['#fff','#ffbe78','#e96442'][i],V([-8,-3,6][i],0,0),true);label(w,m,['矮星 / Kerdil / Dwarf','巨星 / Raksasa / Giant','超巨星 / Super raksasa / Supergiant'][i],V(0,r+1,0));});}
 if(d.kind==='sizes'){const radii=[.383,.949,1,.532,11.21,9.45,4.01,3.88],gaps=[3.5,3.5,3.5,1.2,1.2,1.2,1.2,0],total=radii.reduce((a,b,i)=>a+b*(i===5?2.27:1),0)*.6+gaps.reduce((a,b)=>a+b,0);let x=-total/2;planets.forEach((p,i)=>{const r=radii[i]*.3,extent=r*(i===5?2.27:1);x+=extent;let m=sphere(w,'viz-'+p.id,r,p.color,V(x,0,0));m.material.uniforms.kind.value=p.kind;if(p.id==='earth'){m.material.dispose();const tx=loadSceneTexture(earthURL,{colorSpace:T.SRGBColorSpace});tx.colorSpace=T.SRGBColorSpace;m.material=new T.MeshPhongMaterial({map:tx});}if(p.id==='saturn')saturnRings(m,r);label(w,m,p.name+' / '+p.bm+' / '+p.en,V(0,i<4?2+(i%2)*1.2:r+1,0));x+=extent+gaps[i];});w.camera.position.set(0,10,39);w.controls.update();}
 if(d.kind==='au'||d.kind==='lightyear'){let sun=sphere(w,'viz-sun',2,'#ffb853',V(-8,0,0),true),e=d.kind==='au'?earth(w,1,V(8,0,0)):sphere(w,'viz-distance-end',.12,'#9ddfff',V(8,0,0),true),photon=sphere(w,'viz-light',.12,'#fff',V(),true);line(w,[V(-6,0,0),V(7,0,0)]);for(let i=0;i<=10;i++)line(w,[V(-6+i*1.3,-.2,0),V(-6+i*1.3,.2,0)],'#99c1ef');label(w,sun,'太阳 / Matahari / Sun',V(0,3,0));label(w,e,d.kind==='au'?'地球 / Bumi / Earth':'光走过一年的距离 / One light-year',V(0,2.5,0));update=p=>{photon.position.set(-6+p*13,0,0);document.querySelector('#visualMeasure').textContent=d.kind==='au'?(p.toFixed(2)+' AU · '+(p*1.5e8).toExponential(2)+' km · '+Math.round(p*500)+' s'):(Math.round(p*365)+' 天 / hari / days · '+(p*9.5e12).toExponential(2)+' km');};}
 if(d.kind==='orbit'||d.kind==='belt'){sphere(w,'viz-sun',1.1,'#ffb656',V(),true);const inner=d.kind==='belt'?sphere(w,'viz-mars',.45,'#b65c3e',V(5,0,0)):earth(w,.45,V(5,0,0)),outer=sphere(w,'viz-jupiter',.8,'#c8aa81',V(9,0,0));w.orbit(5);w.orbit(9);if(d.kind==='belt'){w.asteroids(7,1.5,320);label(w,inner,'火星 / Marikh / Mars',V(0,1.3,0));label(w,outer,'木星 / Musytari / Jupiter',V(0,1.8,0));}w.camera.position.set(0,18,21);w.controls.update();update=(p,t)=>{let a=p*Math.PI*2;inner.position.set(...progradePosition(5,a));outer.position.set(...progradePosition(9,a*(d.kind==='belt'?1.881:1)/11.862));};}
 if(d.kind==='rotation'){let bodies=[earth(w,1.7,V(-6,0,0)),sphere(w,'viz-venus',1.7,'#dfbf82',V()),sphere(w,'viz-uranus',1.7,'#92d3de',V(6,0,0))];bodies.forEach((m,i)=>{const tilt=new T.Group();tilt.position.copy(m.position);m.position.set(0,0,0);w.root.add(tilt);tilt.add(m);tilt.rotation.z=axialTilts[['earth','venus','uranus'][i]]*Math.PI/180;if(m.material.uniforms?.spin)m.material.uniforms.spin.value=0;axis(w,m,1.7);label(w,m,['地球 / Bumi / Earth','金星 / Zuhrah / Venus','天王星 / Uranus'][i],V(0,3.4,0));});update=(p,t)=>{bodies[0].rotation.y=p*Math.PI*2; bodies[1].rotation.y=-p*Math.PI*2;bodies[2].rotation.y=p*Math.PI*2;};}
 if(d.kind==='greenhouse'){
  const m=sphere(w,'viz-mercury',1.5,'#8c837c',V(-5,0,0)),v=sphere(w,'viz-venus',1.5,'#caa568',V(5,0,0));halo(w,v,1.8,'#ffb953');
  label(w,m,'水星 / Utarid / Mercury',V(0,-2.5,0));label(w,v,'金星 · CO₂ / Zuhrah / Venus',V(0,-2.5,0));
  const rays=Array.from({length:12},(_,i)=>{const r=new T.Mesh(new T.SphereGeometry(.09,8,6),new T.MeshBasicMaterial({color:'#ffe4a0'}));w.root.add(r);return r});
  update=p=>rays.forEach((r,i)=>{const x=i<6?-5:5,offset=(i%6-2.5)*.24;r.material.color.set(p<.34?'#ffe4a0':'#ff754a');let y;if(p<.34)y=T.MathUtils.lerp(6,1.55,p/.34);else if(p<.62)y=T.MathUtils.lerp(1.55,3,(p-.34)/.28);else y=T.MathUtils.lerp(3,i>=6&&i%2===0?1.55:7,(p-.62)/.38);r.position.set(x+offset,y,.3);});
 }
 if(d.kind==='gravity'){const gs=[3.7,9.8,24.79],balls=[];gs.forEach((g,i)=>{const x=(i-1)*6,planet=i===1?earth(w,1.4,V(x,-3,0)):sphere(w,'viz-g'+i,1.4,['#999','#589dcb','#c6a981'][i],V(x,-3,0)),ball=sphere(w,'viz-drop'+i,.18,'#e8f3ff',V(x,4,0),true);balls.push(ball);label(w,planet,['水星 / Utarid','地球 / Bumi','木星 / Musytari'][i]+' · '+g+' m/s²',V(0,-2,0));line(w,[V(x,4,0),V(x,-1.5,0)],'#557695');});update=p=>{balls.forEach((b,i)=>b.position.y=Math.max(-1.4,4-.5*gs[i]*(p*1.7)**2));document.querySelector('#visualMeasure').textContent=(p*1.7).toFixed(2)+' s';};}
 if(d.kind==='moons'){let e=earth(w),moon=sphere(w,'viz-moon',.8,'#b9b6ae');w.orbit(6);label(w,e,'地球 / Bumi / Earth',V(0,4,0));label(w,moon,'月球 / Bulan / Moon',V(0,1.5,0));moon.material.uniforms.spin.value=0;update=(p,t)=>{lockMoon(moon,p*Math.PI*2,6);e.rotation.y=p*Math.PI*2*27.3;};}
 if(d.kind==='spaceflight'){earth(w,3.4,V(0,-4.6,0));const fly=launchVehicle(w);update=(p,t)=>{fly(p,t);document.querySelector('#visualMeasure').textContent='10 · 10 · 2007';};}
 if(d.kind==='sunlife'){let e=earth(w,3,V(4,0,0)),sun=sphere(w,'viz-sun',1.7,'#ffbd5a',V(-6,0,0),true);w.addGlow(sun,'#ffb75b',8);sun.material.uniforms.lessonDim={value:1};sun.material.fragmentShader='uniform float lessonDim;'+sun.material.fragmentShader.replace('c*limb*.75','c*limb*.75*lessonDim');sun.material.needsUpdate=true;update=p=>{sun.material.uniforms.lessonDim.value=1-p*.98;sun.children.forEach(c=>c.visible=p<.8);e.material.color.setScalar(1-p*.92);};}
 if(d.kind==='speeds'){const velocities=[42,25,55],rocks=[];velocities.forEach((v,i)=>{line(w,[V(-9,3-i*3,0),V(9,3-i*3,0)],'#6686a7');const m=sphere(w,'viz-speed'+i,[.2,.5,.3][i],['#d4c5b1','#a7937c','#91d5ed'][i],V(-9,3-i*3,0));rocks.push(m);label(w,m,['流星体 / Meteoroid · 42 km/s','小行星 / Asteroid · 25 km/s','彗星 / Komet / Comet · 10–70 km/s'][i],V(0,1.2,0));});update=p=>rocks.forEach((m,i)=>m.position.x=-9+p*18*velocities[i]/55);}
 if(d.kind==='composition'){
const a=sphere(w,'viz-rock',.45,'#958477',V(-6,0,0)),b=sphere(w,'viz-asteroid',1.7,'#8c8275',V()),c=sphere(w,'viz-ice',1.1,'#91c9df',V(6,0,0));label(w,a,'流星体 / Meteoroid',V(0,2,0));label(w,b,'小行星 / Asteroid',V(0,3,0));label(w,c,'彗星 / Komet / Comet',V(0,2.5,0));w.addGlow(c,'#a9adb2',3);}
 if(d.kind==='meteor'||d.kind==='shower')update=meteorScene(w,earth,halo,d.kind==='shower');
 if(d.kind==='deflect'){earth(w,2,V(7,0,0));let rock=sphere(w,'viz-rock',.3,'#a9a099',V(-9,0,0));line(w,[V(-9,0,0),V(7,0,0)],'#e77a75',.4);const pts=[];for(let i=0;i<=60;i++){let q=i/60;pts.push(V(-9+q*18,q*q*6,0));}line(w,pts,'#7fe4c4');update=p=>rock.position.set(-9+p*18,p*p*6,0);}
 const notesUpdate=drawNotesScene(w,d);
 if(['spectrum','sizes','comparison'].includes(d.kind))w.hotspots.forEach(h=>{if(!h.el.classList.contains('spectrumTemperature'))h.el.classList.add('comparisonLabel');});
 return completeTopicMotion(w,d,notesUpdate||update);
}


