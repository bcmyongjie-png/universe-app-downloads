import {isStudent} from './edition.js';
import {nativeDownloads} from './native-downloads.js';
export function setupAppInstall(){
 const host=document.querySelector('#teacherPanel');if(!host)return;
 let pending=null;
 const button=document.createElement('button');button.type='button';button.className='appInstall';button.textContent=isStudent?'安装学生 App':'安装教师 App';host.append(button);
 const standalone=()=>matchMedia('(display-mode: standalone)').matches||navigator.standalone===true||/Universe(?:Desktop|Android)\//.test(navigator.userAgent);
 const sync=()=>{button.hidden=standalone();};sync();
 window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();pending=e;sync();});
 window.addEventListener('appinstalled',()=>{pending=null;button.hidden=true;});
 matchMedia('(display-mode: standalone)').addEventListener('change',sync);
 const installWebApp=async()=>{
  if(pending){const prompt=pending;pending=null;try{await prompt.prompt();await prompt.userChoice;return;}catch{}}
  const appleMobile=/iPhone|iPad|iPod/.test(navigator.userAgent)||(/Mac/.test(navigator.platform)&&navigator.maxTouchPoints>1);
  const mac=/Mac/.test(navigator.platform);
  const help=appleMobile?'在浏览器的「分享」菜单中选择「添加到主屏幕」，然后点「添加」。':mac?'Safari：打开「文件」菜单，选择「添加到程序坞」。Chrome：打开浏览器菜单，选择安装此网页为应用。':'打开浏览器菜单，选择「安装应用」或「添加到主屏幕」。若没有此选项，可在支持网页安装的 Chrome 或 Edge 中打开本网站。';
  const dialog=document.createElement('dialog');dialog.className='projectorSetup';dialog.setAttribute('aria-label','安装 App');
  const heading=document.createElement('h2');heading.textContent=button.textContent;const text=document.createElement('p');text.textContent=help;const note=document.createElement('p');note.textContent='安装后可从桌面或主屏幕打开，课程随网站更新。视频、课件和投影仍需联网；安装不会解除浏览器的投影限制。';const close=document.createElement('button');close.type='button';close.textContent='知道了';close.onclick=()=>dialog.close();dialog.append(heading,text,note,close);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});dialog.showModal();
 };
 const downloads=nativeDownloads[isStudent?'student':'teacher'];
 const platform=/Android/i.test(navigator.userAgent)?'android':/Win/i.test(navigator.userAgentData?.platform||navigator.platform)?'windows':null;
 button.onclick=()=>{const file=downloads?.[platform];if(!file){void installWebApp();return;}const a=document.createElement('a');a.href=file.url;a.download=file.url.split('/').pop();document.body.append(a);a.click();a.remove();};
 if(downloads&&!standalone()){
  const options=document.createElement('details');options.className='appDownloadOptions';const summary=document.createElement('summary');summary.textContent='其他安装方式';options.append(summary);
  for(const [type,label]of [['windows','Windows 电脑安装包 · 64 位'],['android','Android 手机 APK · Android 8+']]){const link=document.createElement('a');link.href=downloads[type].url;link.download=downloads[type].url.split('/').pop();link.textContent=label;options.append(link);}
  const web=document.createElement('button');web.type='button';web.textContent='安装网页 App';web.onclick=installWebApp;options.append(web);button.after(options);
 }
 if('serviceWorker' in navigator)window.addEventListener('load',()=>{navigator.serviceWorker.register('/app-sw.js',{scope:'/',updateViaCache:'none'}).catch(()=>{});},{once:true});
}
