const esbuild=require('esbuild'),fs=require('fs'),path=require('path');
async function build(student){
 const out=path.join(__dirname,student?'student-release':'vercel-release');
 const plugins=student?[{name:'student-content',setup(build){
  build.onLoad({filter:/slide-builds\.js$/},()=>({contents:'export const slideBuilds={};',loader:'js'}));
  build.onLoad({filter:/slide-videos\.js$/},()=>({contents:'export const slideVideos={};',loader:'js'}));
  build.onLoad({filter:/course-reader\.js$/},()=>({contents:'export function createReader(){return {visible:false,open(){},close(){}}}',loader:'js'}));
  build.onLoad({filter:/new-source-pages\.js$/},()=>({contents:'export const newSources=[];',loader:'js'}));
  build.onLoad({filter:/course-pages\.js$/},()=>({contents:'export const pages={};',loader:'js'}));
  build.onLoad({filter:/topic-page-map\.json$/},()=>({contents:'[]',loader:'json'}));
 }}]:[];
 const result=await esbuild.build({metafile:true,entryNames:'app-[hash]',entryPoints:[path.join(__dirname,'app.js')],bundle:true,minify:true,format:'iife',outdir:path.join(out,'assets'),assetNames:'[name]-[hash]',loader:{'.html':'file','.mp4':'file','.jpg':'file','.png':'file','.webp':'file'},publicPath:'/assets',legalComments:'none',define:{__STUDENT__:String(student)},plugins});
 const entry=Object.keys(result.metafile.outputs).find(p=>result.metafile.outputs[p].entryPoint&&p.endsWith('.js'));
 const title='宇宙漫游 · '+(student?'Student 学生版':'Teacher 教师版');
 const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8').replace(/<title>.*?<\/title>/,'<title>'+title+'</title>').replace('__CSS__',fs.readFileSync(path.join(__dirname,'style.css'),'utf8')).replace('<script>__JS__</script>','<script src="/assets/'+path.basename(entry)+'"></script>');
 fs.writeFileSync(path.join(out,'index.html'),html);
 require('./build-pwa.cjs')(out,student);
 fs.writeFileSync(path.join(out,'vercel.json'),JSON.stringify({version:2,framework:null,buildCommand:null,outputDirectory:'.',cleanUrls:true,headers:[{source:'/downloads/:path*',headers:[{key:'Content-Disposition',value:'attachment'},{key:'X-Content-Type-Options',value:'nosniff'}]}]}));
 const downloadRoot=path.join(__dirname,'native/downloads'),catalogPath=path.join(downloadRoot,'catalog.json');
 if(fs.existsSync(catalogPath)){const catalog=JSON.parse(fs.readFileSync(catalogPath,'utf8')),edition=student?'student':'teacher';fs.mkdirSync(path.join(out,'downloads'),{recursive:true});for(const file of Object.values(catalog.editions[edition])){const name=path.basename(file.url);fs.copyFileSync(path.join(downloadRoot,name),path.join(out,'downloads',name));}fs.writeFileSync(path.join(out,'downloads/catalog.json'),JSON.stringify({version:catalog.version,files:catalog.editions[edition]},null,2));}
 fs.copyFileSync(path.join(__dirname,'node_modules/three/LICENSE'),path.join(out,'THREE-LICENSE.txt'));
 fs.copyFileSync(path.join(__dirname,'Universe-Projector.zip'),path.join(out,'Universe-Projector.zip'));
 fs.writeFileSync(path.join(__dirname,student?'student-build-meta.json':'teacher-build-meta.json'),JSON.stringify(result.metafile));
 console.log(title+': '+Object.keys(result.metafile.outputs).length+' assets');
}
(async()=>{await build(false);await build(true)})().catch(e=>{console.error(e);process.exit(1)});
