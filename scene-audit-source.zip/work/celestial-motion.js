// +Y is ecliptic north. Positive axial rotation and prograde orbits therefore
// both run from +X towards -Z; presentation time is accelerated.
export const axialTilts={mercury:.03,venus:2.64,earth:23.44,mars:25.19,jupiter:3.13,saturn:26.73,uranus:97.77,neptune:28.32};
export const spinSign=id=>id==='venus'?-1:1; // Venus uses its north-pointing axis; Uranus uses 97.77° obliquity.
export const orbitAngle=(time,au=1)=>time/Math.pow(au,1.5);
export const progradePosition=(radius,angle)=>[radius*Math.cos(angle),0,-radius*Math.sin(angle)];
export function lockMoon(moon,angle,radius){moon.position.set(...progradePosition(radius,angle));moon.rotation.y=angle;}
// Representative near-Earth orbit classes, in AU (not predictions of encounters).
export const nearEarthOrbits=[{name:'Amor',a:1.45,e:.23},{name:'Apollo',a:1.3,e:.4},{name:'Aten',a:.85,e:.25}];
