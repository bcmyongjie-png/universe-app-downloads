import {loadSceneTexture} from './scene-textures.js';
import ringUrl from './body-saturn-ring.png';
import {solarSurface} from './solar-surface.js';
import * as T from 'three';
import mercury from './body-mercury.jpg';
import venus from './body-venus_atmosphere.jpg';
import mars from './body-mars.jpg';
import jupiter from './body-jupiter.jpg';
import saturn from './body-saturn.jpg';
import uranus from './body-uranus.jpg';
import neptune from './body-neptune.jpg';
import sun from './body-sun.jpg';
import moon from './moon_1024.jpg';
// Maps: Solar System Scope / INOVE, CC BY 4.0. Rendering and terrain geometry adapted here.
const urls={mercury,venus,mars,jupiter,saturn,uranus,neptune,sun,moon},cache={};
function texture(key){if(!cache[key]){cache[key]=loadSceneTexture(urls[key],{anisotropy:8,wrapS:T.RepeatWrapping});cache[key].anisotropy=8;cache[key].wrapS=T.RepeatWrapping;}return cache[key];}
export function bodyKind(id){let key=id.replace(/^viz-/,'');const alias={outer:'jupiter',g0:'mercury',g2:'jupiter',ice:'comet',speed0:'rock',speed1:'asteroid',speed2:'comet'};return alias[key]||key;}
export function isRock(id){return /^(rock|asteroid|meteor|comet|ice)$/.test(bodyKind(id));}
export function rockGeometry(r){const g=new T.SphereGeometry(r,80,56),a=g.attributes.position;
 for(let i=0;i<a.count;i++){const n=new T.Vector3().fromBufferAttribute(a,i).normalize(),f=1+.14*Math.sin(n.x*8+n.z*3)*Math.cos(n.y*9)+.07*Math.sin(n.z*19-n.y*6);n.multiplyScalar(r*f);n.x*=1.18;n.y*=.79;a.setXYZ(i,n.x,n.y,n.z);}g.computeVertexNormals();return g;}
export function bodyMaterial(id,color,kind=0){const key=bodyKind(id),rock=isRock(id),mapped=key in urls,keyMap=mapped?key:rock?'mercury':'sun',emissive=kind===5;
 if(key==='sun')return solarSurface();
 const m=new T.ShaderMaterial({uniforms:{base:{value:new T.Color(key==='sun'?'#fff1dc':color)},kind:{value:kind},time:{value:0},spin:{value:id.startsWith('viz-')&&mapped?(key==='venus'?-.009:.009):0},sunlit:{value:0},tex:{value:texture(keyMap)},mapped:{value:mapped||rock?1:0},rock:{value:rock?1:0}},vertexShader:`varying vec2 vUv;varying vec3 vN;varying vec3 vP;varying vec3 vW;void main(){vUv=uv;vN=normalize(mat3(modelMatrix)*normal);vP=position;vW=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vW,1.);}`,fragmentShader:`
 uniform sampler2D tex;uniform vec3 base;uniform float kind,time,spin,sunlit,mapped,rock;
 varying vec2 vUv;varying vec3 vN,vP,vW;
 void main(){vec3 N=normalize(vN),L=normalize(mix(vec3(-.6,.8,1.),-vW,sunlit));float light=max(dot(N,L),0.);
 vec3 sampleColor=texture2D(tex,vec2(vUv.x+time*spin,vUv.y)).rgb;vec3 albedo=mix(base,pow(sampleColor,vec3(2.2)),mapped);
 if(rock>.5)albedo*=vec3(.58,.52,.45);
 vec3 col=albedo*(.065+light*.98);
 if(kind>4.5){vec3 cells=texture2D(tex,vec2(vUv.x+time*.007+sin(vUv.y*24.+time*.7)*.0015,vUv.y+sin(vUv.x*30.+time*.5)*.001)).rgb;float detail=dot(cells,vec3(.35,.5,.15));float limb=.38+.62*pow(max(dot(N,normalize(cameraPosition-vW)),0.),.35);col=base*(.52+detail*.75)*limb;}
 gl_FragColor=vec4(col,1.);}`});return m;}
export function atmosphere(r,color='#7fa3ce',opacity=.12){const m=new T.ShaderMaterial({uniforms:{tint:{value:new T.Color(color)},opacity:{value:opacity}},transparent:true,side:T.BackSide,depthWrite:false,blending:T.AdditiveBlending,vertexShader:`varying vec3 n,w;void main(){n=normalize(mat3(modelMatrix)*normal);w=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(w,1.);}`,fragmentShader:`uniform vec3 tint;uniform float opacity;varying vec3 n,w;void main(){float rim=pow(1.-abs(dot(normalize(n),normalize(cameraPosition-w))),3.5);gl_FragColor=vec4(tint,rim*opacity);}`});Object.defineProperty(m,'opacity',{get(){return this.uniforms.opacity.value},set(v){if(this.uniforms)this.uniforms.opacity.value=v},configurable:true});return new T.Mesh(new T.SphereGeometry(r,64,40),m);}
export function nebula(w,n=5000,r=8){let p=[],c=[],sz=[],state=721;const rand=()=>{state=(state*1664525+1013904223)>>>0;return state/4294967296;};for(let i=0;i<n;i++){const t=rand()*Math.PI*2,branch=i%3,spread=rand()**.5;let x=Math.cos(t)*r*.62+Math.sin(t*3+branch)*r*.22,y=Math.sin(t*2+branch)*r*.23,z=Math.sin(t)*r*.56;const fuzz=r*.3*spread;x+=(rand()-.5)*fuzz;y+=(rand()-.5)*fuzz;z+=(rand()-.5)*fuzz;p.push(x,y,z);const b=.005+rand()*.012;c.push(b*(branch===0?1:.4),b*.5,b*(branch===0?.5:1));sz.push(.9+rand()*2.2);}const cloud=w.addParticles(p,c,sz);cloud.material.uniforms.time={value:0};cloud.material.vertexShader='uniform float time;'+cloud.material.vertexShader.replace('vec4 mv=modelViewMatrix*vec4(position,1.);','vec3 flow=position;flow.x+=sin(position.z*.6+time*.22)*.32;flow.y+=sin(position.x*.5+time*.3)*.22;flow.z+=cos(position.y*.7+time*.18)*.3;vec4 mv=modelViewMatrix*vec4(flow,1.);');return cloud;}
export function accretion(w,body,r=1.15){const disk=new T.Mesh(new T.RingGeometry(r*1.12,r*3.1,192,12),new T.ShaderMaterial({transparent:true,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending,uniforms:{time:{value:0},inner:{value:r*1.12},outer:{value:r*3.1}},vertexShader:`varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform float inner,outer,time;varying vec3 p;void main(){float r=length(p.xy),q=(r-inner)/(outer-inner);float stripe=.7+.3*sin(r*83.+sin(atan(p.y,p.x)*9.-time*1.8)*.8);vec3 c=mix(vec3(1.,.8,.49),vec3(.55,.16,.04),q);float a=(1.-q)*smoothstep(0.,.08,q)*stripe*.75;gl_FragColor=vec4(c,a);}`}));disk.rotation.x=1.18;body.add(disk);const photon=new T.Mesh(new T.TorusGeometry(r*1.04,r*.018,8,160),new T.MeshBasicMaterial({color:'#ffe4b5'}));body.add(photon);}

export function saturnRings(parent,r){const geo=new T.RingGeometry(r*1.24,r*2.27,192,8),pos=geo.attributes.position,uv=geo.attributes.uv;for(let i=0;i<pos.count;i++){const rad=Math.hypot(pos.getX(i),pos.getY(i));uv.setXY(i,(rad-r*1.24)/(r*1.03),.5);}const map=loadSceneTexture(ringUrl,{colorSpace:T.SRGBColorSpace});map.colorSpace=T.SRGBColorSpace;const m=new T.Mesh(geo,new T.MeshStandardMaterial({map,transparent:true,opacity:.85,side:T.DoubleSide,roughness:1,depthWrite:false}));m.rotation.x=-Math.PI/2;parent.add(m);return m;}

export function flowTail(tail,length=8){tail.material.uniforms.time={value:0};tail.material.vertexShader='uniform float time;'+tail.material.vertexShader.replace('vec4 mv=modelViewMatrix*vec4(position,1.);','vec3 flow=position;flow.y+=sin(position.x*.8-time*1.2)*position.x*.025;flow.z+=cos(position.x*.7-time*.9)*position.x*.02;vec4 mv=modelViewMatrix*vec4(flow,1.);');}


