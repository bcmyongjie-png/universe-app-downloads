const {app,BrowserWindow,session,shell,screen,ipcMain,protocol}=require('electron');
const path=require('path');const edition=require('./edition.json');
const {createDisplaySession}=require('./display-mode.cjs');
const origin=edition.student?'https://universe-student.local':'https://universe-teacher.local';
const {createContentHandler}=require('./local-content.cjs');
app.setName(edition.student?'Universe Student':'Universe Teacher');
app.setPath('userData',process.env.UNIVERSE_TEST_DATA||path.join(app.getPath('appData'),edition.student?'UniverseStudentOffline':'UniverseTeacherOffline'));
let main,audience,projectorTask,restoreTask,quitting=false,quitReady=false,stoppingProjection=false;
const displaySession=process.platform==='darwin'
 ?require('./mac-display-mode.cjs').createMacDisplaySession({helperPath:path.join(app.isPackaged?process.resourcesPath:__dirname,'mac-display-helper')})
 :createDisplaySession();
function restoreDisplays(){
 if(!restoreTask)restoreTask=displaySession.restore().catch(error=>{console.error('Could not restore display mode:',error.message);}).finally(()=>{restoreTask=null;if(process.platform==='darwin')keepTeacherVisible();});
 return restoreTask;
}
async function stopProjection(){
 stoppingProjection=true;
 try{if(audience&&!audience.isDestroyed())audience.close();if(projectorTask)await projectorTask;await restoreDisplays();}
 finally{stoppingProjection=false;}
}
const localUrl=url=>{try{return new URL(url).origin===origin;}catch{return false;}};
const audienceUrl=url=>{try{const u=new URL(url);return u.origin===origin&&/^\/assets\/audience-window-[a-z0-9-]+(?:\.html)?$/i.test(u.pathname)&&/^#universe-presenter-[a-z0-9-]+$/i.test(u.hash);}catch{return false;}};
function secure(win){
 win.webContents.setUserAgent(win.webContents.getUserAgent()+' UniverseDesktop/1.0');
 win.webContents.on('will-navigate',(e,url)=>{if(!localUrl(url)){e.preventDefault();if(/^https:\/\//.test(url))void shell.openExternal(url);}});
 win.webContents.setWindowOpenHandler(({url})=>{if(audienceUrl(url)){if(process.platform==='darwin'){if(win===main)void openProjector(url);return {action:'deny'};}return {action:'allow',overrideBrowserWindowOptions:{width:960,height:640,autoHideMenuBar:true,backgroundColor:'#000',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}}};}if(/^https:\/\//.test(url))void shell.openExternal(url);return {action:'deny'};});
 win.webContents.on('did-create-window',child=>{secure(child);const {target}=displayPair();if(target){child.setBounds(target.bounds);setPresentationFullscreen(child,true);}});
 win.webContents.on('before-input-event',(e,input)=>{if(input.key==='F11'&&input.type==='keyDown'){e.preventDefault();setPresentationFullscreen(win,process.platform==='darwin'?!win.isSimpleFullScreen():!win.isFullScreen());}});
}
// Native macOS fullscreen creates a Space and can black out the other display
// when "Displays have separate Spaces" is off. Legacy fullscreen stays put.
function setPresentationFullscreen(win,value){if(process.platform==='darwin')win.setSimpleFullScreen(value);else win.setFullScreen(value);}
function keepTeacherVisible(){
 if(!main||main.isDestroyed()||quitting)return;
 const {home}=displayPair();if(!home)return;
 const area=home.workArea||home.bounds,b=main.getBounds(),width=Math.min(b.width,area.width),height=Math.min(b.height,area.height);
 if(main.isMinimized())main.restore();
 main.setBounds({x:Math.max(area.x,Math.min(b.x,area.x+area.width-width)),y:Math.max(area.y,Math.min(b.y,area.y+area.height-height)),width,height});
 main.show();main.focus();
}
async function leaveTeacherSpace(){
 if(process.platform!=='darwin'||!main||main.isDestroyed())return;
 if(main.isSimpleFullScreen())main.setSimpleFullScreen(false);
 if(!main.isFullScreen())return;
 const win=main;
 await new Promise((resolve,reject)=>{
  let timer;const done=()=>{clearTimeout(timer);win.removeListener('leave-full-screen',done);resolve();};
  win.once('leave-full-screen',done);win.setFullScreen(false);
  timer=setTimeout(()=>{win.removeListener('leave-full-screen',done);reject(new Error('Teacher fullscreen transition timed out'));},12000);
 });
}
function separate(a,b){return a.x>=b.x+b.width||b.x>=a.x+a.width||a.y>=b.y+b.height||b.y>=a.y+a.height;}
function displayPair(){
 const displays=screen.getAllDisplays(),current=main&&!main.isDestroyed()?screen.getDisplayMatching(main.getBounds()):displays[0];
 const home=displays.find(d=>d.internal)||displays.find(d=>d.id===current.id)||displays[0];
 return {home,target:displays.find(d=>d.id!==home.id&&separate(d.bounds,home.bounds))};
}
async function prepareProjector(url){
 if(restoreTask)await restoreTask;
 if(quitting||stoppingProjection||!main||main.isDestroyed())return {ok:false};
 await leaveTeacherSpace();
 if(quitting||stoppingProjection||!main||main.isDestroyed())return {ok:false};
 let pair=displayPair();
 if(!pair.target&&['win32','darwin'].includes(process.platform)){
  // Capture the actual mode before requesting a temporary display change.
  // Never guess "Duplicate" from Electron reporting only one desktop.
  try{await displaySession.extend();}catch(error){console.warn('Cannot switch display mode:',error.message);await restoreDisplays();return {ok:false,message:process.platform==='darwin'?'未能自动开启扩展显示。教学画面仍留在电脑上；请确认 MacBook 屏幕打开、投影仪已连接，或在系统设置的显示器中选择扩展显示后重试。':'无法读取 Windows 显示模式。请按 Win + P 选择扩展后重试。'};}
  // The OS updates Electron's displays asynchronously. A command exit code
  // alone proves neither success nor failure; wait for separate screen bounds.
  for(let attempt=0;attempt<=40;attempt++){
   // Even if the teacher closes, let the OS finish before restoring its mode.
   pair=displayPair();if(pair.target||attempt===40)break;
   await new Promise(resolve=>setTimeout(resolve,250));
  }
  try{await displaySession.capture();}catch(error){console.warn('Cannot confirm display state:',error.message);}
 }
 if(quitting||stoppingProjection||!main||main.isDestroyed()){await restoreDisplays();return {ok:false};}
 const {home,target}=pair;
 if(!target){await restoreDisplays();return {ok:false,message:'尚未识别到独立投影屏幕。请确认投影仪已连接并开机。'};}
 if(process.platform==='darwin'&&!home.internal){await restoreDisplays();return {ok:false,message:'请打开 MacBook 屏幕，再连接投影。电脑需要保留教学控制画面。'};}
 if(process.platform==='darwin')keepTeacherVisible();
 if(screen.getDisplayMatching(main.getBounds()).id!==home.id){const area=home.workArea||home.bounds,b=main.getBounds(),width=Math.min(b.width,area.width),height=Math.min(b.height,area.height);main.setBounds({x:area.x+Math.round((area.width-width)/2),y:area.y+Math.round((area.height-height)/2),width,height});}
 if(audience&&!audience.isDestroyed()){audience.setBounds(target.bounds);setPresentationFullscreen(audience,true);if(audience.webContents.getURL()!==url)void audience.loadURL(url);audience.showInactive();return {ok:true};}
 const view=new BrowserWindow({...target.bounds,show:false,frame:false,simpleFullscreen:process.platform==='darwin',backgroundColor:'#000',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});audience=view;secure(view);
 const lostDisplay=(_event,display)=>{if(display.id===target.id&&!view.isDestroyed())view.close();};
 const layoutChanged=()=>{const pair=displayPair(),actual=screen.getAllDisplays().find(d=>d.id===target.id);if(!actual||!pair.home||(process.platform==='darwin'&&!pair.home.internal)||actual.id===pair.home.id||!separate(actual.bounds,pair.home.bounds)){if(!view.isDestroyed())view.close();}};
 screen.on('display-removed',lostDisplay);screen.on('display-metrics-changed',layoutChanged);
 view.on('close',()=>{if(process.platform==='darwin'&&view.isSimpleFullScreen())view.setSimpleFullScreen(false);});
 view.once('ready-to-show',()=>{if(view.isDestroyed())return;layoutChanged();if(view.isDestroyed())return;const actual=screen.getAllDisplays().find(d=>d.id===target.id);view.setBounds(actual.bounds);setPresentationFullscreen(view,true);view.showInactive();if(process.platform==='darwin')keepTeacherVisible();});
 view.on('closed',()=>{screen.removeListener('display-removed',lostDisplay);screen.removeListener('display-metrics-changed',layoutChanged);if(audience===view){audience=null;void restoreDisplays();}});
 view.webContents.on('before-input-event',(event,input)=>{if(input.key==='Escape'&&input.type==='keyDown'){event.preventDefault();view.close();}});
 try{await view.loadURL(url);if(view.isDestroyed())return {ok:false};return {ok:true};}
 catch(error){if(!view.isDestroyed())view.close();await restoreDisplays();return {ok:false,message:'投影画面未能打开，请重试。'};}
}
function openProjector(url){
 if(!audienceUrl(url))return {ok:false,message:'无效的投影地址。'};
 if(quitting||stoppingProjection)return {ok:false};
 if(!projectorTask)projectorTask=prepareProjector(url).catch(async error=>{console.error('Projection failed:',error.message);await restoreDisplays();return {ok:false,message:'投影未能启动，请重试。'};}).finally(()=>{projectorTask=null;});
 return projectorTask;
}
if(!app.requestSingleInstanceLock())app.quit();else{
 app.on('second-instance',()=>{if(main){if(main.isMinimized())main.restore();main.show();main.focus();}});
 app.whenReady().then(()=>{
  const course=app.isPackaged?path.join(process.resourcesPath,'course'):path.join(__dirname,'web',edition.student?'student':'teacher');
  protocol.handle('https',createContentHandler(course,origin));
  session.defaultSession.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*','ws://*/*','wss://*/*']},(details,done)=>done({cancel:!localUrl(details.url)}));
  session.defaultSession.setPermissionRequestHandler((contents,permission,callback)=>callback(localUrl(contents.getURL())&&['fullscreen','window-management'].includes(permission)));
  session.defaultSession.setPermissionCheckHandler((contents,permission,requestingOrigin)=>localUrl(requestingOrigin)&&['fullscreen','window-management'].includes(permission));
  ipcMain.handle('universe:projector',(e,url)=>e.sender===main?.webContents&&e.senderFrame===main.webContents.mainFrame&&localUrl(e.senderFrame.url)?openProjector(url):{ok:false,message:'无法打开投影。'});
  main=new BrowserWindow({width:1280,height:800,minWidth:640,minHeight:480,show:false,simpleFullscreen:process.platform==='darwin',autoHideMenuBar:true,title:app.getName(),icon:path.join(__dirname,'icon.png'),backgroundColor:'#030711',webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true}});secure(main);main.once('ready-to-show',()=>main.show());main.on('closed',()=>{if(audience&&!audience.isDestroyed())audience.close();main=null;});
  main.webContents.on('did-fail-load',(_e,code,_text,_url,isMain)=>{if(!isMain||code===-3)return;console.error('Bundled course failed to load',code);});
  require('./updates.cjs').setupUpdates({app,ipcMain,main,edition,beforeInstall:stopProjection});
  void main.loadURL(origin+'/?source=desktop');
 });
 app.on('window-all-closed',()=>app.quit());
 app.on('before-quit',event=>{
  if(quitReady)return;
  event.preventDefault();if(quitting)return;quitting=true;
  void stopProjection().finally(()=>{quitReady=true;app.quit();});
 });
}
