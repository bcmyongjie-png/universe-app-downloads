const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const out=path.join(os.tmpdir(),'universe-chapter-access');fs.mkdirSync(out,{recursive:true});
const chapter=t=>t==='galaxy'?11:t==='visitors'?13:12;
// Keep this regression runnable from the standalone Windows/macOS source bundle.
const topics=Object.entries({galaxy:14,solar:18,earth:5,visitors:9}).flatMap(([track,count])=>Array.from({length:count},(_,index)=>({id:track+':'+index,ch:chapter(track)})));
(async()=>{for(const edition of process.env.EDITION?[process.env.EDITION]:['Teacher','Student']){
 const lower=edition.toLowerCase(),exe=process.env.QA_EXECUTABLE||(process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`);
 const app=await _electron.launch({executablePath:exe,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-complete-topics-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  page.on('console',msg=>{if(msg.type()==='error'&&/THREE|shader|WebGL/i.test(msg.text()))errors.push(msg.text());});
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  const ready=()=>page.waitForFunction(()=>document.querySelector('#space canvas')&&document.querySelector('#labels')?.style.visibility!=='hidden'&&!document.body.classList.contains('diving'));
  const closeTopics=async()=>{if(await page.locator('#chapterTopics').isVisible())await page.locator('.chapterTopicsHeader button').click();};
  const openTopics=async()=>{if(!(await page.locator('#chapterTopics').isVisible()))await page.locator('#chapterTopicsToggle').click();};
  async function select(chapters){await page.locator('#teacherToggle').click();for(const ch of chapters)await page.locator(`.chapterCheck input[value="${ch}"]`).check();for(const ch of [11,12,13].filter(c=>!chapters.includes(c)))await page.locator(`.chapterCheck input[value="${ch}"]`).uncheck();await page.locator('#teacherPanel header button').click();await ready();}
  async function restricted(chapters){for(const selector of ['#chapterTopics [data-chapter-topic]','#sceneTopics a','#microDetail [data-related]','#lessonSelect option']){const ids=await page.locator(selector).evaluateAll(els=>els.map(el=>el.dataset.chapterTopic||el.dataset.topic||el.dataset.related||el.value));assert(ids.every(id=>chapters.includes(chapter(id.split(':')[0]))),selector+' exposes another chapter');}}
  await ready();
  for(const ch of [11,12,13]){
   await select([ch]);assert(await page.locator('#chapterTopics').isVisible(),'Changing chapters automatically shows every selected topic');
   const expected=topics.filter(t=>t.ch===ch);assert.deepEqual(await page.locator('#chapterTopics [data-chapter-topic]').evaluateAll(els=>els.map(el=>el.dataset.chapterTopic)),expected.map(t=>t.id));
   await page.screenshot({path:path.join(out,lower+'-c'+ch+'-topics.png')});
   for(const topic of expected){
    const title=(await page.locator(`#lessonSelect option[value="${topic.id}"]`).textContent()).replace(/^C\d+ · /,'');
    await openTopics();await page.locator(`[data-chapter-topic="${topic.id}"]`).click();
    await page.waitForFunction(({ch,title})=>document.querySelector('#location').textContent.startsWith('C'+ch+' · '+title+' · ')&&!document.querySelector('#lessonTimeline').hidden,{ch,title});await ready();await restricted([ch]);
   }
   console.log(edition+' C'+ch+' PASS: all '+expected.length+' topics opened directly without another chapter');
   await page.reload();await ready();await restricted([ch]);assert(await page.locator('#chapterTopics').isVisible());await closeTopics();
   if(ch===11){
    await page.locator('[data-object-id="cosmos-milky"]').press('Enter');await page.waitForFunction(()=>document.body.dataset.level==='0');await ready();
    await page.getByRole('button',{name:'探索太阳系',exact:true}).press('Enter');await page.waitForFunction(()=>document.body.dataset.level==='1');await ready();
    for(const name of ['探索水星','探索彗星','探索小行星带'])assert.equal(await page.getByRole('button',{name,exact:true}).count(),0);
    await page.getByRole('button',{name:'探索太阳',exact:true}).press('Enter');await page.waitForFunction(()=>document.querySelector('#lessonTimeline').dataset.kind==='fusion');await ready();
    await page.locator('#sceneTopics [data-topic="galaxy:11"]').click();await page.waitForFunction(()=>document.querySelector('#lessonTimeline').dataset.kind==='sunlife');await ready();await restricted([11]);
    await page.reload();await ready();await closeTopics();await page.locator('[data-object-id="cosmos-milky"]').press('Enter');await ready();await page.getByRole('button',{name:'探索太阳系',exact:true}).press('Enter');await ready();
   }
   if(ch===11||ch===13){
    await page.getByRole('button',{name:'探索地球 · 进入 →',exact:true}).press('Enter');await page.waitForFunction(()=>document.body.dataset.level==='2');await ready();
    assert.equal(await page.getByRole('button',{name:'探索地球为什么适合生命',exact:true}).count(),0);
    const name=ch===11?'探索空间站':'探索流星雨';assert.equal(await page.getByRole('button',{name,exact:true}).count(),1);
    await page.getByRole('button',{name,exact:true}).press('Enter');await page.waitForFunction(ch=>document.querySelector('#location').textContent.startsWith('C'+ch+' · '),ch);await ready();await restricted([ch]);
   }
  }
  for(const chapters of [[11,12],[11,13],[12,13],[11,12,13]]){await select(chapters);await restricted(chapters);assert.equal(await page.locator('#chapterTopics [data-chapter-topic]').count(),topics.filter(t=>chapters.includes(t.ch)).length);}
  await app.evaluate(({BrowserWindow})=>{const w=BrowserWindow.getAllWindows()[0];w.setMinimumSize(320,400);w.setContentSize(390,844);});
  await select([11]);await page.locator('[data-chapter-topic="galaxy:13"]').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,lower+'-mobile-c11.png')});
  const bounds=await page.locator('#chapterTopics').boundingBox();assert(bounds.x>=0&&bounds.x+bounds.width<=390);await page.locator('[data-chapter-topic="galaxy:13"]').click();await page.waitForFunction(()=>document.querySelector('#lessonTimeline').dataset.kind==='sextant');await ready();
  assert.deepEqual(errors,[]);console.log(edition+' PASS: shared solar/Earth scenes, filtered teaching links, all seven combinations, reload and narrow-screen topic access');
 }finally{await app.close();}
}})().catch(e=>{console.error(e);process.exit(1);});
