const clamp=n=>Math.max(28,Math.min(64,Number(n)||36));
let fontSize=36;
try{fontSize=clamp(JSON.parse(localStorage.getItem('universe.fontSize'))??36);}catch{}
function paint(){
 document.documentElement.style.setProperty('--teaching-size',fontSize+'px');
 document.querySelectorAll('[data-font-range]').forEach(el=>el.value=fontSize);
 document.querySelectorAll('[data-font-value]').forEach(el=>el.textContent=fontSize+' px');
 document.querySelectorAll('[data-font-step]').forEach(el=>el.disabled=Number(el.dataset.fontStep)<0?fontSize<=28:fontSize>=64);
}
export function fontControls(){return '<div class="fontControls" role="group" aria-label="讲解字号"><button type="button" data-font-step="-2" aria-label="缩小讲解文字">A−</button><label>字号 <output data-font-value>'+fontSize+' px</output><input data-font-range type="range" min="28" max="64" step="1" value="'+fontSize+'" aria-label="讲解文字大小"></label><button type="button" data-font-step="2" aria-label="放大讲解文字">A＋</button></div>';}
export function bindFontControls(host){
 const set=n=>{fontSize=clamp(n);try{localStorage.setItem('universe.fontSize',JSON.stringify(fontSize));}catch{}paint();};
 host.querySelectorAll('[data-font-step]').forEach(el=>el.onclick=e=>{e.stopPropagation();set(fontSize+Number(el.dataset.fontStep));});
 host.querySelectorAll('[data-font-range]').forEach(el=>el.oninput=()=>set(el.value));paint();
}
export function createDisplayControls(hud){
 let brightness=135;try{brightness=Math.max(90,Math.min(180,Number(localStorage.getItem('universe.brightness'))||135));}catch{}
 const brightnessLabel=document.createElement('label');brightnessLabel.className='brightnessControl';brightnessLabel.innerHTML='画面亮度 <output>'+brightness+'%</output><input aria-label="画面亮度" type="range" min="90" max="180" step="5" value="'+brightness+'">';
 document.querySelector('#teacherPanel .volumeLabel').before(brightnessLabel);
 const paintBrightness=()=>{document.documentElement.style.setProperty('--scene-brightness',brightness/100);brightnessLabel.querySelector('output').textContent=brightness+'%';};paintBrightness();brightnessLabel.querySelector('input').oninput=e=>{brightness=Number(e.target.value);paintBrightness();try{localStorage.setItem('universe.brightness',String(brightness));}catch{}};

 paint();const button=document.createElement('button');button.id='fullscreenToggle';button.type='button';
 const status=document.createElement('div');status.id='displayStatus';status.setAttribute('role','status');hud.append(button,status);
 const fullscreen=()=>document.fullscreenElement||document.webkitFullscreenElement;
 const sync=()=>{const active=!!fullscreen()||document.body.classList.contains('immersive-view');button.textContent=active?'⤢ 退出':'⛶ 全屏';button.setAttribute('aria-label',active?'退出全屏或沉浸显示':'全屏显示');button.setAttribute('aria-pressed',String(active));};
 let timer;const notify=s=>{status.textContent=s;clearTimeout(timer);timer=setTimeout(()=>status.textContent='',5500);};
 const fallback=()=>{document.body.classList.add('immersive-view');notify('已开启沉浸显示；此浏览器不支持隐藏系统栏。');sync();};
 button.onclick=async()=>{try{
  if(fullscreen()){const exit=document.exitFullscreen||document.webkitExitFullscreen;await exit.call(document);}
  else if(document.body.classList.contains('immersive-view'))document.body.classList.remove('immersive-view');
  else {const enter=document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen;if(enter)await enter.call(document.documentElement);else fallback();}
 }catch{if(!fullscreen())fallback();else notify('请按 Esc 退出全屏。');}sync();};
 document.addEventListener('fullscreenchange',sync);document.addEventListener('webkitfullscreenchange',sync);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('immersive-view')){document.body.classList.remove('immersive-view');sync();}},true);sync();
}
