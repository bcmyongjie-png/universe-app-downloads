const {_electron}=require('playwright'),assert=require('assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
(async()=>{fs.mkdirSync('smoke-results',{recursive:true});for(const edition of ['Teacher','Student']){
 const lower=edition.toLowerCase(),origin='https://universe-'+lower+'.local';
 const executablePath=process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`;
 const app=await _electron.launch({executablePath,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-offline-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.waitForURL(origin+'/**');await page.locator('#space canvas').waitFor();
  assert.equal(await page.evaluate(()=>typeof window.universeDesktop?.openProjector),'function');
  assert.equal(await page.evaluate(async()=>{try{await fetch('https://example.com/');return false}catch{return true}}),true);
  await page.locator('#teacherToggle').click();
  const options=await page.locator('#lessonSelect option').evaluateAll(ns=>ns.map(n=>({value:n.value,label:n.textContent})));
  assert(options.length>=46);
  for(let i=0;i<options.length;i++){
   if(i)await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption(options[i].value);await page.locator('#startLesson').click();
   await page.waitForFunction(()=>document.querySelector('#labels')?.style.visibility!=='hidden');
   assert((await page.locator('#location').textContent()).includes(options[i].label.replace(/^C\d+ · /,'')));
  }
  for(const asset of require('./'+lower+'-assets.json').filter(a=>a.path.endsWith('.mp4'))){
   await page.evaluate(async src=>{const v=document.createElement('video');v.muted=true;v.src=src;document.body.append(v);try{await new Promise((resolve,reject)=>{v.onloadedmetadata=resolve;v.onerror=()=>reject(Error('Video metadata failed'));setTimeout(()=>reject(Error('Video timeout')),15000)});await new Promise((resolve,reject)=>{v.onseeked=resolve;v.currentTime=v.duration*.5;setTimeout(()=>reject(Error('Seek timeout')),15000)});await v.play();await new Promise(r=>setTimeout(r,300));if(v.paused||v.error)throw Error('Video did not play')}finally{v.pause();v.removeAttribute('src');v.load();v.remove()}},origin+'/'+asset.path);
  }
  await page.screenshot({path:'smoke-results/'+lower+'.png'});assert.deepEqual(errors,[]);
  console.log(edition+': fresh packaged app, external network blocked, all '+options.length+' scenes, all videos seek/play, bridge available; PASS');
 }finally{await app.close()}
}})().catch(e=>{console.error(e);process.exit(1)});
