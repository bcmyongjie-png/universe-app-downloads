import {modelNote} from './model-notes.js';
import {createLessonTimeline,lessonSequence} from './lesson-timeline.js';
import {objectLesson,createSceneNavigation} from './scene-navigation.js';
import {stageSolarScene} from './solar-staging.js';
import {prepareScene} from './scene-preparation.js';
import {isStudent,markEdition} from './edition.js';
import {setupAppInstall} from './app-install.js';
import {createVideoLibrary} from './topic-resources.js';
import {hideBoard,showBoard} from './board-layout.js';
import {createTeacherUI} from './teacher-ui.js';
import {teaching,planetNotes,chapterOf} from './teaching-content.js';
import {createSpaceAudio} from './cosmic-music.js';
import {drawCosmos,neighbors} from './cosmos.js';
import * as T from 'three';
import {Universe} from './scene.js';
import {planets,entries} from './data.js';
import {regions} from './hierarchy.js';
import {createReader} from './course-reader.js';
import {journeys,drawLesson} from './visual-lessons.js';
const $=s=>document.querySelector(s),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
let world,level=0,progress=0,busy=false,focused=null,region='malaysia',startPos,startTarget,endPos,endTarget,cooldown=0,detailTimer;
let beforeMediaPause=false,beforeMediaControls=true;document.addEventListener('teaching-media',e=>{if(!world)return;if(e.detail.open){beforeMediaPause=world.paused;beforeMediaControls=world.controls.enabled;world.paused=true;world.controls.enabled=false;}else{world.paused=beforeMediaPause;world.controls.enabled=beforeMediaControls;cooldown=performance.now()+450;}});
const modes=['galaxy','solar','orbit','orbit'];
const names=['MILKY WAY','SOLAR SYSTEM','EARTH','MALAYSIA'];
const hud=document.createElement('div');hud.id='minimalHud';hud.innerHTML='<div class="wordmark">UNIVERSE</div><div id="openingTitle"><h1>宇宙漫游</h1><p>银河系 · 太阳系 · 地球</p></div><div id="location">MILKY WAY</div><div id="depth"><i></i><i></i><i></i><i></i><i></i></div><div id="microDetail" aria-live="polite"></div><div id="gestureHint">点击天体或名称进入 · 拖动环顾</div><div class="scaleNote">教学尺度示意</div>';
document.querySelector('#app').append(hud);markEdition(hud);const sound=createSpaceAudio(hud);createVideoLibrary(hud);
const reader=createReader(()=>{world.controls.enabled=true;cooldown=performance.now()+600;});
let activeChapter=11;let visual=null;let playbackSpeed=1;
const teacher=createTeacherUI(hud,journeys,{onLesson:enterObjectLesson,onSelection:()=>{const first=teacher.list()[0];if(reader.visible)reader.close();runLesson(first.track,first.index);},onPlayback:setLessonPlaying,onProgress:seekLesson});
const timeline=createLessonTimeline(hud,{onPlaying:setLessonPlaying,onSeek:seekLesson,onSpeed:value=>{playbackSpeed=value;},onInspect:()=>inspectStar()});
function inspectStar(id){if(!world.stellarDiagram)return;setLessonPlaying(false);world.stellarDiagram.inspect(id);visual.dirty=true;}
function setLessonPlaying(playing){if(!visual)return;visual.playing=playing;world.lessonPlaybackPaused=!playing;visual.lastTime=world.t;if(playing&&reduced)world.paused=false;teacher.syncPlayback(playing);timeline.sync(visual.p,playing);}
function seekLesson(p){if(!visual)return;visual.p=Math.max(0,Math.min(1,p));visual.hold=0;visual.dirty=true;teacher.syncProgress(visual.p);timeline.sync(visual.p,visual.playing);sound.motion(p);}
const explorationHistory=[];
const sceneNavigation=createSceneNavigation(hud,journeys,{enter:enterObjectLesson,allows:chapter=>teacher.allows(chapter)});
async function enterObjectLesson(track,index,sourceId=null){
 if(busy||!teacher.allows(chapterOf(track)))return;
 if(visual?.track===track&&visual.index===index)return;
 const travel=!visual&&level===-1&&sourceId?.startsWith('cosmos-');
 if(travel){busy=true;clearTimeout(detailTimer);sound.cue('enter');document.body.classList.add('diving');world.controls.enabled=false;}
 try{
  if(travel&&!reduced){world.approach(sourceId);await new Promise(resolve=>setTimeout(resolve,900));}
  explorationHistory.push({level,focused,visual:visual?{track:visual.track,index:visual.index}:null});
  runLesson(track,index);
  if(travel){if(!reduced)world.arrive();await world.scenePreparation;}
 }finally{
  if(travel){document.body.classList.remove('diving');world.controls.enabled=true;busy=false;cooldown=performance.now()+400;}
 }
}
setupAppInstall();
// A single click enters an object's lesson. Related lessons stay in the scene.
function fitBoard(){if(world)world.camera.clearViewOffset();}
function pickCelestial(id){
 if(busy)return;
 if(visual&&id.startsWith('life-stage-')&&world.stellarDiagram){if(world.stellarDiagram.inspecting)return;const p=world.stellarDiagram.stageProgress(id.slice(11));if(p!==undefined){seekLesson(p);setLessonPlaying(true);}return;}
 if(!visual||(journeys[visual.track][visual.index].kind==='galaxy'&&['star','life'].includes(id))){const target=objectLesson(id,level,journeys);if(target){enterObjectLesson(...target,id);return;}}
 else if(id.startsWith('viz-')){
  const planet=id.slice(4),index=journeys.solar.findIndex(d=>d.planet===planet);
  if(index>=0&&(visual.track!=='solar'||visual.index!==index)){enterObjectLesson('solar',index);return;}
 }
 if(!visual&&focused===id&&$('#microDetail').classList.contains('shown')){showBoard();return;}
 choose(id);if(visual&&id.startsWith('viz-'))showBoard();
}
window.addEventListener('board-layout-change',()=>requestAnimationFrame(fitBoard));
let viewScale=1,solarViewScale=1,cosmosViewScale=innerWidth<650?2.2:1;
const fitSolarScale=()=>Math.max(1,(level===2?1.25:1.5)/(innerWidth/innerHeight));
const sceneScale=()=>{const kind=visual&&journeys[visual.track][visual.index].kind;return Math.max(1,(kind==='planet'?.6:kind==='sizes'?1.45:.9)/(innerWidth/innerHeight));};
window.addEventListener('resize',()=>{if(!visual&&level===-1){const next=innerWidth<650?2.2:1;world.fly=null;world.camera.position.sub(world.controls.target).multiplyScalar(next/cosmosViewScale).add(world.controls.target);cosmosViewScale=next;world.controls.update();}if(visual){const next=sceneScale();world.camera.position.sub(world.controls.target).multiplyScalar(next/viewScale).add(world.controls.target);viewScale=next;}if(!visual&&(level===1||level===2)&&!focused){const next=fitSolarScale();world.fly=null;world.camera.position.sub(world.controls.target).multiplyScalar(next/solarViewScale).add(world.controls.target);solarViewScale=next;world.controls.update();}world.stellarDiagram?.resize();world.zoomReturn=null;fitBoard();});
const meter=document.createElement('div');meter.id='visualMeasure';hud.append(meter);const sourceLink=document.createElement('a');sourceLink.id='sourceLink';sourceLink.textContent='课件原页';sourceLink.href='#';sourceLink.onclick=e=>{e.preventDefault();readCourse();};hud.append(sourceLink);const credit=document.createElement('a');credit.id='assetCredit';credit.href='https://www.solarsystemscope.com/textures/';credit.target='_blank';credit.rel='noopener';credit.textContent='太阳观测参考 NASA/SDO · 行星 Solar System Scope';credit.title='太阳：参考用户提供的橙红色太阳图与 NASA/SDO 极紫外着色影像的三维教学模型；非肉眼原色、非实时观测。行星：Solar System Scope / INOVE，CC BY 4.0。';hud.append(credit);
const sceneInfo=document.createElement('details');sceneInfo.id='sceneInfo';sceneInfo.innerHTML='<summary>关于与资料</summary><div class="sceneInfoBody"></div>';$('#teacherPanel').append(sceneInfo);sceneInfo.querySelector('div').append($('.scaleNote'),credit,sourceLink);

function runLesson(track,index=0){hideBoard();if(!teacher.allows(chapterOf(track))){const first=teacher.list()[0];track=first.track;index=first.index;}sound.cue('lesson');clearTimeout(detailTimer);focused=null;world.stars.visible=true;const d=journeys[track][index];visual={track,index,p:0,update:null,playing:!reduced,lastTime:world.t,animationTime:0,dirty:true,hold:1.2};activeChapter=chapterOf(track);visual.duration=lessonSequence(d).duration;visual.update=drawLesson(world,d);if(world.stellarDiagram)world.stellarDiagram.onInspect=inspectStar;world.lessonPlaybackPaused=!visual.playing;visual.update(0,0);timeline.open(d,visual.playing);sceneNavigation.show(track,index);sound.setLesson(d.kind);viewScale=sceneScale();world.camera.position.sub(world.controls.target).multiplyScalar(viewScale).add(world.controls.target);world.controls.update();world.stellarDiagram?.resize();document.body.classList.add('visual-lesson');teacher.show(d,track,index);fitBoard();const all=teacher.list(),at=all.findIndex(x=>x.track===track&&x.index===index);$('#location').textContent='C'+activeChapter+' · '+d.zh+' · '+(at+1)+' / '+all.length;$('#gestureHint').textContent=d.kind==='shower'?'仰望夜空 · 流星持续划过': '点击天体查看 · 拖动环顾 · 点击板内进度演示';world.controls.enableZoom=d.kind!=='shower';world.controls.enableRotate=d.kind!=='shower';backButton.hidden=false;$('#visualMeasure').textContent='';$('#depth').innerHTML='';sourceLink.textContent='笔记与练习 · C'+activeChapter;$('.scaleNote').textContent=modelNote(d);world.lessonUpdate=()=>{if(!visual)return;const dt=Math.min(.05,Math.max(0,world.t-visual.lastTime));visual.lastTime=world.t;if(visual.playing&&!world.paused){if(visual.hold>0)visual.hold=Math.max(0,visual.hold-dt*playbackSpeed);else if(visual.p>=1){visual.p=0;visual.hold=1.2;}else{visual.p=Math.min(1,visual.p+dt*playbackSpeed/visual.duration);if(visual.p>=1)visual.hold=3;}teacher.syncProgress(visual.p);timeline.sync(visual.p,visual.playing);}if((visual.playing&&!world.paused)||visual.dirty){visual.animationTime=visual.p*visual.duration;visual.update(visual.p,visual.animationTime);visual.dirty=false;}};prepareScene(world);cooldown=performance.now()+400;}
function leaveLesson(){timeline.close();visual=null;world.lessonUpdate=null;document.body.classList.remove('visual-lesson');$('#visualMeasure').textContent='';sourceLink.textContent='课件原页';$('#depth').innerHTML='<i></i><i></i><i></i><i></i><i></i>';setup(level,true);}
function openVisualContext(){if(visual){leaveLesson();return;}runLesson(level<=0?'galaxy':level>=2?'earth':'solar');}

function readCourse(chapter=activeChapter){if(isStudent)return;world.controls.enabled=false;reader.open(chapter,teacher.chapters,runLesson);}
$('#location').tabIndex=0;$('#location').setAttribute('role','link');$('#location').setAttribute('aria-label','进入可视化探索');$('#location').onclick=openVisualContext;$('#location').onkeydown=e=>{if(e.key==='Enter')openVisualContext();};
function detailTopic(key,d){if(level===-1)return 'galaxy:'+d.kind;const planetIndex=journeys.solar.findIndex(x=>x.planet===key);if(key&&planetIndex>=0)return 'solar:'+planetIndex;return ({sun:'galaxy:4',moon:'solar:7',nebula:'galaxy:3',star:'galaxy:12',giant:'galaxy:5',remnant:'galaxy:7',asteroid:'visitors:2',meteor:'visitors:3',comet:'visitors:7'})[key]||'earth:1';}
function detail(d){hideBoard();clearTimeout(detailTimer);$('#microDetail').classList.remove('shown');fitBoard();if(!d||!teacher.allows(activeChapter))return;detailTimer=setTimeout(()=>{const key=d.id||focused;const points=(level===-1?teaching['galaxy-'+d.kind]:null)||planetNotes[key]||teaching[({sun:'fusion',moon:'moons',nebula:'birth',star:'starsize',giant:'giant',remnant:'remnants',asteroid:'belt',meteor:'meteor',comet:'comet'}[key])]||teaching.habitat;teacher.show({zh:d.name||d.zh,bm:d.bm||({malaysia:'Malaysia',china:'China Timur',europe:'Eropah',africa:'Sahara',amazon:'Amazon',australia:'Australia'}[region]),en:d.en,relatedKey:detailTopic(key,d)},null,0,points);fitBoard();},reduced?0:850);}
function updateHud(){document.body.dataset.level=level;document.body.classList.toggle('object-focused',!!focused);$('#location').textContent=level===-1?'本星系群 / Kumpulan Tempatan / Local Group':level===3?regions.find(r=>r.id===region).name:level===0?'银河系 / Bima Sakti / Milky Way':level===1?'太阳系 / Sistem suria / Solar system':'地球 / Bumi / Earth';$('#depth').querySelectorAll('i').forEach((x,i)=>x.classList.toggle('on',i===level+1));$('#gestureHint').textContent='点击天体或名称进入 · 拖动环顾 · 滚轮缩放';backButton.hidden=level===-1&&!focused;}
function setup(n,arrival=false){timeline.close();sceneNavigation.close();hideBoard();$('#visualMeasure').textContent='';sourceLink.textContent='课件原页';world.lessonUpdate=null;world.camera.clearViewOffset();clearTimeout(detailTimer);focused=null;activeChapter=n<=0?11:12;level=n;progress=0;sound.setScene(n);world.stars.visible=true;$('.scaleNote').textContent=n===-1?'星系大小、位置为构图示意 · 非 1:1 星图':'教学尺度示意';if(n===-1){drawCosmos(world);cosmosViewScale=innerWidth<650?2.2:1;world.controls.enableZoom=true;world.controls.enableRotate=true;detail(null);updateHud();if(arrival)world.arrive();prepareScene(world).then(()=>stageSolarScene(world)).catch(console.warn);return;}if(n===0)world.galaxyKind='spiral';world.setMode(modes[n]);world.controls.enableZoom=true;world.controls.enableRotate=true;world.controls.target.set(n===2?4:0,0,0);world.camera.position.set(...(n===0?[0,29,43]:n===1?[0,44,60]:[1,3,30]));if(n===1||n===2){solarViewScale=fitSolarScale();world.camera.position.multiplyScalar(solarViewScale);}else if(innerWidth<650&&n<2)world.camera.position.multiplyScalar(1.3);world.controls.update();if(n===3){world.focusRegion(regions.find(r=>r.id===region));detail(regions.find(r=>r.id===region));}else{detail(n===2?planets.find(p=>p.id==='earth'):null);if(arrival)world.arrive();}if(n===1||n===2){const anchor=new T.Object3D();anchor.position.set(n===1?-10:6,n===1?5:5,3);world.root.add(anchor);world.label(n===1?'lesson-solar':'lesson-earth',n===1?'行星运动与距离':'地球为什么适合生命',anchor);}startPos=world.camera.position.clone();startTarget=world.controls.target.clone();updateHud();world.hotspots.forEach(h=>{h.el.textContent=h.el.textContent.replace(/ · (进入 →|进入|选择地区)/,'').replace(' ↗','');if(n>=2&&h.id==='earth')h.el.classList.add('omit');});prepareScene(world);}
async function enter(n){if(busy)return;sound.cue(n>level?'enter':'back');busy=true;clearTimeout(detailTimer);document.body.classList.add('diving');world.controls.enabled=false;if(!reduced&&n>level&&level<2){world.approach(level===-1?'cosmos-milky':level===0?'enter-solar':'earth');await new Promise(r=>setTimeout(r,900));}if(n===3&&level===2){level=3;world.focusRegion(regions.find(r=>r.id===region));detail(regions.find(r=>r.id===region));updateHud();}else setup(n,true);document.body.classList.remove('diving');world.controls.enabled=true;busy=false;cooldown=performance.now()+900;}
function choose(id){if(busy)return;sound.cue('pick');if(visual){if(id.startsWith('viz-')){const obj=world.meshes.find(m=>m.userData.id===id);if(obj?.userData.lessonLabel){const key=id.replace('viz-','');const p=planets.find(p=>p.id===key);if(p&&planetNotes[key])teacher.show({zh:p.name,bm:p.bm,en:p.en,points:planetNotes[key]},visual.track,visual.index); }world.focus(id);}return;}if(level===-1){if(id==='cosmos-milky'){enter(0);return;}const g=neighbors.find(d=>d.id===id);if(g){focused=id;world.focus(id);detail(g);updateHud();cooldown=performance.now()+900;}return;}if(id==='lesson-solar'){runLesson('solar');return;}if(id==='lesson-earth'){runLesson('earth');return;}if(id==='enter-solar'){enter(1);return;}if(id==='milky'||id==='life'){runLesson('galaxy',id==='life'?3:0);return;}if(id==='course13'){runLesson('visitors');return;}if(id==='earth'&&level===1){enter(2);return;}if(id.startsWith('region-')){region=id.slice(7);enter(3);return;}if(id==='earth'&&level===2){enter(3);return;}const d=planets.find(p=>p.id===id)||entries[id];if(!d)return;activeChapter=['comet','asteroid','meteor'].includes(id)?13:['star','nebula','giant','remnant'].includes(id)?11:12;focused=id;world.focus(id);detail(d);updateHud();cooldown=performance.now()+900;}
function goBack(){if(busy)return;if(explorationHistory.length){const previous=explorationHistory.pop();if(previous.visual){runLesson(previous.visual.track,previous.visual.index);}else{visual=null;document.body.classList.remove('visual-lesson');setup(previous.level,true);if(previous.focused)choose(previous.focused);}return;}if(visual){leaveLesson();return;}if(focused){setup(level,true);return;}if(level>-1)enter(level-1);}
const backButton=document.createElement('button');backButton.id='sceneBack';backButton.textContent='← 返回上层';backButton.setAttribute('aria-label','返回上一层场景');backButton.onclick=goBack;hud.append(backButton);
// Saved chapter filters choose available lessons, never the startup scene.
try{world=new Universe($('#space'),pickCelestial);setup(-1);$('#loading').style.pointerEvents='none';setTimeout(()=>$('#loading').remove(),500);
 window.addEventListener('keydown',e=>{if(document.body.classList.contains('topic-resource-open'))return;if(e.target.closest('input,select,#teacherPanel,#microDetail'))return;if(reader.visible){if(e.key==='Escape'){e.preventDefault();reader.close();}return;}if(e.key==='Escape'){e.preventDefault();goBack();}});
}catch(e){$('#loading').innerHTML='<p>请启用浏览器图形加速后重新打开。</p>';console.error(e);}


