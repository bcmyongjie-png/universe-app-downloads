import * as T from 'three';
import {rockGeometry} from './body-art.js';
const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z);
const smooth=(a,b,x)=>T.MathUtils.smoothstep(x,a,b);
export function meteorScene(w,earth,halo,shower=false){
 if(shower)return meteorShower(w,earth,halo);
 const planet=earth(w,11,V(0,-12,0));planet.rotation.z=.32;halo(w,planet,11.18,'#76bfff');
 w.camera.position.set(0,3,24);w.controls.target.set(0,1,0);w.controls.update();
 const rock=w.sphere('viz-meteor',.64,'#827469',0);rock.userData.r=.64;delete rock.userData.tumble;rock.material.dispose();rock.material=new T.MeshStandardMaterial({color:'#827469',roughness:.95,emissive:'#ff5b0a',emissiveIntensity:0});
 const rim=new T.DirectionalLight('#a8caff',2.2);rim.position.set(-8,8,9);w.root.add(rim);
 const front=new T.PointLight('#ffc58e',0,18,1.4);w.root.add(front);
 const start=V(-8,6,1),hit=V(2.7,-1.22,1.4),direction=hit.clone().sub(start).normalize(),back=direction.clone().negate();
 const effect=new T.Group();w.root.add(effect);
 // A tapered luminous wake, aligned opposite the incoming body, not a static halo.
 const wakeMaterial=new T.ShaderMaterial({transparent:true,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending,uniforms:{heat:{value:0},phase:{value:0}},vertexShader:'varying vec2 uv0;void main(){uv0=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 uv0;uniform float heat;uniform float phase;void main(){float y=uv0.y;float width=mix(.035,.48,pow(y,.8));float core=exp(-pow((uv0.x-.5)/width,2.)*5.);float fall=pow(1.-y,1.8);float fil=.78+.22*sin(y*49.-phase*17.);vec3 c=mix(vec3(1.,.12,.015),vec3(1.,.9,.65),pow(1.-y,3.));gl_FragColor=vec4(c*2.,core*fall*heat*fil);}' });
 const wake=new T.Mesh(new T.PlaneGeometry(2.5,7),wakeMaterial);wake.geometry.translate(0,3.5,0);wake.quaternion.setFromUnitVectors(V(0,1,0),back);effect.add(wake);
 const glowMat=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,uniforms:{strength:{value:0}},vertexShader:'varying vec2 uv0;void main(){uv0=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 uv0;uniform float strength;void main(){float r=length(uv0-.5)*2.;float a=exp(-r*r*8.)*smoothstep(1.,.1,r);gl_FragColor=vec4(mix(vec3(1.,.2,.015),vec3(1.,.94,.8),exp(-r*r*40.))*2.,a*strength);}' });
 const head=new T.Mesh(new T.PlaneGeometry(3.8,3.8),glowMat);effect.add(head);w.billboards.push(head);
 const count=shower?1100:700,positions=new Float32Array(count*3),colors=new Float32Array(count*3),seeds=[];
 for(let i=0;i<count;i++){const q=((i*73)%count)/count;seeds.push({q,a:i*2.399,spread:.2+(i%13)/13});colors.set([1,.2+q*.55,.025+q*.16],i*3);}
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(positions,3));geometry.setAttribute('color',new T.BufferAttribute(colors,3));
 const sparks=new T.Points(geometry,new T.PointsMaterial({size:.065,vertexColors:true,transparent:true,opacity:0,depthWrite:false,blending:T.AdditiveBlending}));w.root.add(sparks);
 let stage=-1;
 return (p,t)=>{
  const impact=.88,q=Math.min(1,p/impact),heat=smooth(.13,.28,p)*(1-smooth(.62,.75,p));
  const contact=hit.clone().sub(planet.position).normalize().multiplyScalar(11+.64*.3).add(planet.position);rock.position.lerpVectors(start,contact,q);rock.rotation.set(Math.min(p,impact)*24*.8,Math.min(p,impact)*24*.6,Math.min(p,impact)*24*.23);rock.scale.setScalar(1-.7*smooth(.2,.75,p));rock.visible=true;
  rock.material.emissiveIntensity=heat*2.4;effect.position.copy(rock.position);wakeMaterial.uniforms.heat.value=heat;wakeMaterial.uniforms.phase.value=t;glowMat.uniforms.strength.value=heat;front.position.copy(rock.position);front.intensity=heat*14;
  sparks.material.opacity=heat*.9;for(let i=0;i<count;i++){const s=seeds[i],u=(s.q+t*.55)%1;const pos=rock.position.clone().addScaledVector(back,u*6.5);pos.x+=Math.sin(s.a)*u*s.spread*.8;pos.y+=Math.cos(s.a)*u*s.spread*.65;pos.z+=Math.sin(s.a*1.7)*u*.7;positions.set([pos.x,pos.y,pos.z],i*3);}geometry.attributes.position.needsUpdate=true;sparks.frustumCulled=false;
  const next=p<.17?0:p<impact?1:2;if(next!==stage){stage=next;document.querySelector('#visualMeasure').textContent=['流星体 · Meteoroid · Meteoroid','流星 · Meteor · Meteor','陨石 · Meteorit · Meteorite'][stage];}
 };
}
function meteorShower(w){
 // Ground observer view: parallel meteoroid paths appear to radiate in perspective.
 w.stars.visible=false;const damping=w.controls.enableDamping;w.controls.enableDamping=false;w.controls.update();w.controls.enableDamping=damping;w.camera.position.set(0,1,24);w.controls.target.set(0,1,0);w.controls.update();
 const sky=new T.Mesh(new T.PlaneGeometry(130,90),new T.ShaderMaterial({depthWrite:false,uniforms:{},vertexShader:'varying vec2 v;void main(){v=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 v;void main(){vec3 c=mix(vec3(.023,.035,.065),vec3(.001,.003,.013),smoothstep(.25,.8,v.y));gl_FragColor=vec4(c,1.);}'}));sky.position.set(0,8,-18);w.root.add(sky);
 const positions=[],colors=[];let seed=813;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<1100;i++){positions.push((random()-.5)*70,random()*42-8,-10-random()*4);const b=.25+random()*.65;colors.push(b*.85,b*.9,b);}
 const starsGeo=new T.BufferGeometry();starsGeo.setAttribute('position',new T.Float32BufferAttribute(positions,3));starsGeo.setAttribute('color',new T.Float32BufferAttribute(colors,3));const stars=new T.Points(starsGeo,new T.PointsMaterial({size:.035,vertexColors:true,sizeAttenuation:true,transparent:true,opacity:.9,depthWrite:false}));w.root.add(stars);
 const silhouette=new T.Shape();silhouette.moveTo(-55,-35);silhouette.lineTo(-55,-8.3);for(let x=-55;x<=55;x+=1.2)silhouette.lineTo(x,-8.5+Math.sin(x*.22)*.45+Math.sin(x*.8)*.18);silhouette.lineTo(55,-35);silhouette.closePath();const ridge=new T.Mesh(new T.ShapeGeometry(silhouette),new T.MeshBasicMaterial({color:'#03060c'}));ridge.position.z=-1;w.root.add(ridge);
 const tracks=[];const radiant=V(-2.5,7,0);
 for(let i=0;i<7;i++){const angle=-2.8+i*.36,start=radiant.clone().add(V(Math.cos(angle)*(2+i*.3),Math.sin(angle)*(2+i*.3),0)),direction=V(Math.cos(angle),Math.sin(angle),0);const material=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,uniforms:{strength:{value:0}},vertexShader:'varying vec2 v;void main(){v=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 v;uniform float strength;void main(){float width=exp(-pow((v.x-.5)*6.,2.));float along=pow(v.y,1.2);vec3 color=mix(vec3(.32,.55,.8),vec3(1.,.96,.83),v.y);gl_FragColor=vec4(color*2.4,width*along*strength);}'});const streak=new T.Mesh(new T.PlaneGeometry(.12,3.3),material);streak.geometry.translate(0,-1.65,0);streak.quaternion.setFromUnitVectors(V(0,1,0),direction);w.root.add(streak);const head=new T.Mesh(new T.SphereGeometry(.025,10,8),new T.MeshBasicMaterial({color:'#fff5d9',transparent:true,opacity:0}));w.root.add(head);tracks.push({start,direction,streak,head,period:4.2+i*.37,offset:i*.68+.2});}
 return(p,t)=>{document.querySelector('#visualMeasure').textContent='夜空观测 · 时间加速示意';tracks.forEach(({start,direction,streak,head,period,offset},i)=>{const age=(t+offset)%period,duration=.85+(i%3)*.12,q=age/duration,visible=q<1;streak.visible=head.visible=visible;if(!visible)return;const heat=Math.sin(Math.PI*Math.min(1,q))**.55;head.position.copy(start).addScaledVector(direction,q*(6+i*.4));streak.position.copy(head.position);streak.scale.y=.35+.8*Math.sin(q*Math.PI);streak.material.uniforms.strength.value=heat;head.material.opacity=heat;});};
}
