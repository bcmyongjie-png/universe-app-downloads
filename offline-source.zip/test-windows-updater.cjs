const {NsisUpdater}=require('electron-updater'),{NodeHttpExecutor}=require('builder-util/out/nodeHttpExecutor');
const fs=require('fs/promises'),path=require('path'),os=require('os'),http=require('http'),crypto=require('crypto'),assert=require('assert/strict');
(async()=>{
 const bytes=Buffer.from('MZ test fixture - download only, never execute'),hash=crypto.createHash('sha512').update(bytes).digest('base64'),requests=[];
 const server=http.createServer((req,res)=>{requests.push(req.url);if(req.url.startsWith('/teacher.yml'))res.end('version: 2.2.0\nfiles:\n  - url: fixture.exe\n    sha512: '+hash+'\n    size: '+bytes.length+'\npath: fixture.exe\nsha512: '+hash+'\nreleaseDate: 2026-09-12T00:00:00Z\n');else if(req.url.startsWith('/fixture.exe'))res.end(bytes);else{res.statusCode=404;res.end()}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 try{const dir=await fs.mkdtemp(path.join(os.tmpdir(),'universe-nsis-test-')),config=path.join(dir,'app-update.yml');await fs.writeFile(config,'updaterCacheDirName: updater-test\n');
 const app={version:'2.1.0',name:'Universe updater test',isPackaged:true,userDataPath:dir,baseCachePath:dir,appUpdateConfigPath:config,whenReady:async()=>{},onQuit:()=>{},quit:()=>{throw Error('Test must never install or quit')}};
 const updater=new NsisUpdater(undefined,app);updater.httpExecutor=new NodeHttpExecutor();updater.httpExecutor.download=require("electron-updater/out/electronHttpExecutor").ElectronHttpExecutor.prototype.download;updater.setFeedURL({provider:'generic',url:'http://127.0.0.1:'+server.address().port+'/',channel:'teacher'});updater.logger=null;updater.autoDownload=true;updater.autoInstallOnAppQuit=false;updater.disableDifferentialDownload=true;
 let downloaded=false;updater.on('update-downloaded',()=>{downloaded=true});const result=await updater.checkForUpdates();const files=await result.downloadPromise;
 assert(downloaded);assert.equal(result.updateInfo.version,'2.2.0');assert.deepEqual(await fs.readFile(files[0]),bytes);assert(requests.some(x=>x.startsWith('/teacher.yml')));assert(requests.some(x=>x.startsWith('/fixture.exe')));
 console.log('Windows electron-updater integration PASS: correct edition feed, newer-version detection, automatic download, SHA-512 verification, ready event. Installer execution intentionally excluded.');
 }finally{await new Promise(r=>server.close(r))}
})().catch(e=>{console.error(e);process.exit(1)});


