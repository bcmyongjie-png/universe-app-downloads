const {build,Platform,Arch}=require('electron-builder');
const fs=require('fs'),path=require('path');
(async()=>{
 const mac=process.platform==='darwin';
 const hasSigningIdentity=Boolean(process.env.CSC_LINK||process.env.WIN_CSC_LINK||process.env.WIN_CERT_SHA1);
 const unsigned=!mac&&!hasSigningIdentity&&process.env.UNIVERSE_UNSIGNED_RELEASE==='1';
 if(!mac&&!hasSigningIdentity&&!unsigned){
  throw new Error('Windows release requires a trusted code-signing certificate, or explicit UNIVERSE_UNSIGNED_RELEASE=1 for a clearly disclosed unsigned distribution. Unsigned apps may be blocked by Smart App Control.');
 }
 if(unsigned)console.warn('UNSIGNED Windows distribution: no verified publisher signature. Smart App Control may block this installer or app. No Windows security settings are changed.');
 if(mac)require('./build-mac-helper.cjs').buildMacHelper();
 for(const student of [false,true]){
  const edition=student?'Student':'Teacher',lower=edition.toLowerCase();
  fs.writeFileSync('edition.json',JSON.stringify({student}));fs.copyFileSync(lower+'-512.png','icon.png');
  await build({publish:'never',targets:mac?Platform.MAC.createTarget(['dmg'],Arch.universal):Platform.WINDOWS.createTarget(['nsis'],Arch.x64),config:{
   appId:'net.yurenedu.universe.'+lower,productName:'Universe '+edition,
   electronDist:process.env.UNIVERSE_ELECTRON_DIST||undefined,
   forceCodeSigning:!mac&&!unsigned,
   extraMetadata:{name:'universe-'+lower+'-offline'},
   artifactName:'Universe-'+edition+'-Offline-'+require('./package.json').version+'-'+(mac?'Mac.dmg':'Setup.exe'),directories:{output:'dist/'+lower},
   files:['main.cjs','display-mode.cjs','mac-display-mode.cjs','preload.cjs','updates.cjs','local-content.cjs','edition.json','icon.png','package.json'],asar:true,
   extraResources:[{from:'web/'+lower,to:'course'},...(mac?[{from:'mac-display-helper',to:'mac-display-helper'}]:[])],
   mac:{category:'public.app-category.education',icon:'icon.png',identity:'-',hardenedRuntime:false,notarize:false},
   dmg:{format:'ULFO',writeUpdateInfo:false,title:'Universe '+edition,contents:[{x:130,y:150,type:'file'},{x:410,y:150,type:'link',path:'/Applications'}]},
   win:{signAndEditExecutable:true,signtoolOptions:process.env.WIN_CERT_SHA1?{certificateSha1:process.env.WIN_CERT_SHA1}:undefined},nsis:{differentialPackage:false,oneClick:true,perMachine:false,createDesktopShortcut:true,runAfterFinish:false,deleteAppDataOnUninstall:false},publish:{provider:'generic',url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/latest/download/',channel:lower}
  }});
 }
})().catch(e=>{console.error(e);process.exit(1)});
