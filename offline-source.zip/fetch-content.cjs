const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
(async()=>{for(const edition of ['teacher','student']){
 const files=require(`./${edition}-assets.json`),root=path.join('web',edition);await fs.mkdir(path.join(root,'assets'),{recursive:true});
 await fs.copyFile(`${edition}-index.html`,path.join(root,'index.html'));await fs.copyFile(`${edition}-app.js`,path.join(root,'assets/offline-app.js'));
 let cursor=0;await Promise.all(Array.from({length:8},async()=>{while(cursor<files.length){const f=files[cursor++];let success=false;for(let attempt=0;attempt<4;attempt++){try{const response=await fetch(f.url);if(!response.ok)throw Error(`HTTP ${response.status}`);const data=Buffer.from(await response.arrayBuffer());if(data.length!==f.bytes||crypto.createHash('sha256').update(data).digest('hex')!==f.sha256)throw Error('Hash mismatch');await fs.writeFile(path.join(root,f.path),data);success=true;break;}catch(error){if(attempt===3)throw Error(`${f.url}: ${error.message}`);await new Promise(r=>setTimeout(r,1000*(attempt+1)));}}if(!success)throw Error(f.path);}}));
 console.log(`${edition}: ${files.length} bundled assets verified byte-for-byte`);
}})().catch(e=>{console.error(e);process.exit(1)});
