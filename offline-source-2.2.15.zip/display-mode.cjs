// Read the actual active Windows paths, not the last saved display profile.
// Only the signed DisplaySwitch utility changes the mode. No policy overrides.
const {execFile}=require('child_process');
const path=require('path');
const query=String.raw`$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class UniverseDisplayQuery {
 [StructLayout(LayoutKind.Sequential)] public struct Luid { public uint Low; public int High; }
 [StructLayout(LayoutKind.Sequential)] public struct Source { public Luid Adapter; public uint Id, Mode, Flags; }
 [StructLayout(LayoutKind.Sequential)] public struct Target {
  public Luid Adapter; public uint Id, Mode, Technology, Rotation, Scaling, Numerator, Denominator, Scan;
  public int Available; public uint Flags;
 }
 [StructLayout(LayoutKind.Sequential)] public struct DisplayPath { public Source Source; public Target Target; public uint Flags; }
 [StructLayout(LayoutKind.Explicit, Size=64)] public struct Mode {
  [FieldOffset(0)] public uint Type;
  [FieldOffset(4)] public uint Id;
  [FieldOffset(8)] public Luid Adapter;
  [FieldOffset(16)] public uint Width;
  [FieldOffset(20)] public uint Height;
  [FieldOffset(28)] public int X;
  [FieldOffset(32)] public int Y;
 }
 public class Row { public string Target,SingleMode; public bool Internal; public int X,Y; public uint Width,Height; }
 [DllImport("user32.dll")] static extern int GetDisplayConfigBufferSizes(uint flags,out uint paths,out uint modes);
 [DllImport("user32.dll")] static extern int QueryDisplayConfig(uint flags,ref uint paths,[Out] DisplayPath[] pathArray,ref uint modes,[Out] Mode[] modeArray,IntPtr topology);
 [DllImport("user32.dll",EntryPoint="QueryDisplayConfig")] static extern int QuerySavedConfig(uint flags,ref uint paths,[Out] DisplayPath[] pathArray,ref uint modes,[Out] Mode[] modeArray,out uint topology);
 static string TargetKey(Target t){return t.Adapter.High+":"+t.Adapter.Low+":"+t.Id;}
 static string SingleMode(Row row){
  // On a desktop, "PC screen only" can itself be an HDMI monitor. Only use
  // the saved topology enum when it matches the actual active target.
  for(int attempt=0;attempt<5;attempt++){
   uint pc,mc,topology;int error=GetDisplayConfigBufferSizes(4,out pc,out mc);
   if(error!=0)throw new Win32Exception(error);
   var paths=new DisplayPath[pc];var modes=new Mode[mc];
   error=QuerySavedConfig(4,ref pc,paths,ref mc,modes,out topology);
   if(error==122)continue;
   if(error!=0)throw new Win32Exception(error);
   if(pc==1 && TargetKey(paths[0].Target)==row.Target && (topology==1 || topology==8))return topology==1?"internal":"external";
   throw new Exception("Cannot identify the original single-screen mode");
  }
  throw new Exception("Displays are still changing");
 }
 public static Row[] Read() {
  if(Marshal.SizeOf(typeof(DisplayPath))!=72 || Marshal.SizeOf(typeof(Mode))!=64)throw new Exception("Unexpected display structure layout");
  for(int attempt=0;attempt<5;attempt++) {
   uint pc,mc;int error=GetDisplayConfigBufferSizes(2,out pc,out mc);
   if(error!=0)throw new Win32Exception(error);
   var paths=new DisplayPath[pc];var modes=new Mode[mc];
   error=QueryDisplayConfig(2,ref pc,paths,ref mc,modes,IntPtr.Zero);
   if(error==122)continue;
   if(error!=0)throw new Win32Exception(error);
   var rows=new List<Row>();
   for(int i=0;i<pc;i++) {
    var p=paths[i];uint index=p.Source.Mode;
    if(index>=mc || modes[index].Type!=1)throw new Exception("Active source mode unavailable");
    var m=modes[index];uint tech=p.Target.Technology;
    rows.Add(new Row{Target=TargetKey(p.Target),
     Internal=tech==0x80000000 || tech==6 || tech==11 || tech==13,X=m.X,Y=m.Y,Width=m.Width,Height=m.Height});
   }
   if(rows.Count==1)rows[0].SingleMode=rows[0].Internal?"internal":SingleMode(rows[0]);
   return rows.ToArray();
  }
  throw new Exception("Displays are still changing");
 }
}
'@
ConvertTo-Json -InputObject @([UniverseDisplayQuery]::Read()) -Compress`;

function classify(rows){
 if(!Array.isArray(rows)||!rows.length||rows.some(r=>typeof r.Target!=='string'||typeof r.Internal!=='boolean'||
  !Number.isInteger(r.X)||!Number.isInteger(r.Y)||!(r.Width>0)||!(r.Height>0)))throw new Error('Invalid display state');
 const rectangles=new Set(rows.map(r=>[r.X,r.Y,r.Width,r.Height].join(',')));
 const singleMode=rows[0].Internal?'internal':rows[0].SingleMode;
 if(rows.length===1&&!['internal','external'].includes(singleMode))throw new Error('Unknown single-screen mode');
 const mode=rows.length===1?singleMode:rectangles.size===1?'clone':rectangles.size===rows.length?'extend':'mixed';
 const targets=rows.map(r=>r.Target).sort();
 const signature=JSON.stringify(rows.map(r=>[r.Target,r.X,r.Y,r.Width,r.Height]).sort((a,b)=>a[0].localeCompare(b[0])));
 return {mode,targets,signature};
}
function readDisplayState(){
 return new Promise((resolve,reject)=>execFile(path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe'),
  ['-NoLogo','-NoProfile','-NonInteractive','-Command',query],{windowsHide:true,timeout:8000,maxBuffer:256*1024},(error,stdout)=>{
   if(error)return reject(error);
   try{resolve(classify(JSON.parse(stdout.trim())));}catch(e){reject(e);}
  }));
}
function switchDisplayMode(mode){
 if(!['internal','external','clone','extend'].includes(mode))return Promise.reject(new Error('Invalid display mode'));
 return new Promise((resolve,reject)=>execFile(path.join(process.env.SystemRoot||'C:\\Windows','System32','DisplaySwitch.exe'),
  ['/'+mode],{windowsHide:true,timeout:5000},error=>error?reject(error):resolve()));
}

// Own only the change this projection made. A user's later display change
// (including unplugging a monitor) invalidates our claim to restore it.
function createDisplaySession(){
 let original=null,applied=null;
 return {
  async extend(){
   const before=await readDisplayState();
   if(before.mode==='extend')return;
   if(!['internal','external','clone'].includes(before.mode))throw new Error('Unsupported display arrangement');
   original=before;applied=null;
   try{await switchDisplayMode('extend');}catch(e){console.warn('DisplaySwitch completion:',e.code||e.message);}
  },
  async capture(){
   if(!original)return;
   const state=await readDisplayState();
   if(state.mode==='extend'&&original.targets.every(t=>state.targets.includes(t)))applied=state;
  },
  async restore(){
   if(!original)return;
   const before=original;
   try{
    const current=await readDisplayState();
    if(current.mode===before.mode){original=null;applied=null;return;}
    if(current.mode!=='extend'||(applied&&current.signature!==applied.signature)||!before.targets.every(t=>current.targets.includes(t))){
     original=null;applied=null;return;
    }
    try{await switchDisplayMode(before.mode);}catch(e){console.warn('Display restoration command:',e.code||e.message);}
    for(let i=0;i<4;i++){
     const state=await readDisplayState();
     if(state.mode===before.mode){original=null;applied=null;return;}
     if(i<3)await new Promise(resolve=>setTimeout(resolve,250));
    }
    throw new Error('Windows did not restore the original display mode');
   }catch(error){console.warn('Display restoration failed:',error.message);throw error;}
  }
 };
}
module.exports={readDisplayState,switchDisplayMode,createDisplaySession,classify};
