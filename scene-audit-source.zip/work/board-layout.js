import {isStudent} from './edition.js';
let expanded=false,toggle;
export function boardLayoutControls(){return '';}
function paint(){
 const board=document.querySelector('#microDetail');const available=!!board?.classList.contains('shown');
 document.body.classList.toggle('board-projecting',expanded&&available);
 document.body.classList.toggle('board-hidden',!expanded||!available);
 if(toggle){toggle.hidden=!available;toggle.textContent=expanded?'隐藏讲解 · 返回天体':isStudent?'展开知识讲解':'展开讲解 · 幻灯片';toggle.setAttribute('aria-expanded',String(expanded&&available));}
 const close=board?.querySelector('[data-action=collapse]');if(close){close.textContent='隐藏讲解 ×';close.setAttribute('aria-label','隐藏讲解，返回天体');close.setAttribute('aria-expanded',String(expanded));}
 window.dispatchEvent(new Event('board-layout-change'));
}
export function hideBoard(){expanded=false;paint();}
export function showBoard(){expanded=true;paint();document.querySelector('#microDetail')?.scrollTo({top:0});}
export function bindBoardLayout(host){
 if(!toggle){toggle=document.createElement('button');toggle.id='boardToggle';toggle.setAttribute('aria-controls','microDetail');toggle.onclick=()=>{expanded=!expanded;paint();if(expanded)host.scrollTo({top:0});};(document.querySelector('#sceneLearningControls')||document.querySelector('#minimalHud')).append(toggle);new MutationObserver(paint).observe(host,{attributes:true,attributeFilter:['class']});}
 const close=host.querySelector('[data-action=collapse]');if(close)close.onclick=e=>{e.stopPropagation();hideBoard();toggle.focus();};paint();
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&expanded&&!document.querySelector('dialog[open]')&&!document.body.classList.contains('reading-course')){e.preventDefault();e.stopImmediatePropagation();hideBoard();toggle?.focus();}},true);
