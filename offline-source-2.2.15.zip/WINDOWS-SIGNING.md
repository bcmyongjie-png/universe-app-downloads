# Windows release signing

The installed 2.2.14 Teacher executable is unsigned. On 2026-10-08 this computer's Windows Code Integrity log recorded event 3077 blocking it when launched by Explorer. Smart App Control is enforced. The app archive's 261 files pass their stored SHA-256 integrity checks, and the desktop shortcut points to the existing executable. Reinstalling the same unsigned binary is not a demonstrated fix.

Version 2.2.15 defaults to requiring a signing identity before building Windows EXE releases. Both Teacher and Student are covered. On 2026-10-08 the user requested publication while retaining their earlier choice of direct website downloads without paid signing. An explicitly opted-in unsigned distribution is supported with `UNIVERSE_UNSIGNED_RELEASE=1`; its build log and release notes must disclose the missing publisher signature and possible Smart App Control block. This does not bypass or modify Windows security. When a signing identity is configured, signing remains mandatory even with that opt-in.

The previously blocked installed 2.2.14 app was later observed running on 2026-10-08. This does not establish that a new unsigned build will be trusted. Mac packaging remains ad-hoc signed and not notarized.

## Configure an approved signing identity

Use a publicly trusted Windows code-signing certificate, issued after the publisher's identity verification. Do not commit signing keys, certificate passwords, cloud credentials or tokens to this repository.

- Certificate store / hardware token / supported cloud CSP: set `WIN_CERT_SHA1` to the certificate's thumbprint. The certificate and its authorized signing provider must be installed and available to SignTool.
- An existing supported certificate-file or HSM-backed CI arrangement: electron-builder uses `CSC_LINK` or `WIN_CSC_LINK`, with the corresponding secret password. Modern publicly trusted code-signing certificates normally keep private keys on approved hardware or a cloud signing service; do not assume a newly purchased certificate will have an exportable PFX private key.
- The provided GitHub workflow maps `WINDOWS_CSC_LINK` and `WINDOWS_CSC_KEY_PASSWORD` repository secrets to electron-builder. A provider-specific cloud signing integration must be configured once the actual service has been selected. No credentials have been supplied or tested yet.

Do not describe an unsigned release as a signature fix. Inspect and record the signature state, test freshly packaged offline lessons and update handling, and publish both editions' metadata only with their matching installers. CI can verify packaged behavior but does not prove that every user's endpoint policy will allow first launch.

## User's selected distribution

The user requires direct downloads from the existing website and fully offline lessons. They declined a browser fallback and Microsoft Store distribution. Signing affects building/distribution; it does not require changing lessons into online content.

No certificate has been purchased, no identity submission has been made, no security setting has been changed, and the installed app has not been replaced in this repair.

References:
- https://learn.microsoft.com/en-us/windows/apps/develop/smart-app-control/code-signing-for-smart-app-control
- https://www.electron.build/v26/docs/win/
- https://www.ssl.com/products/software-integrity/code-signing/
