// Exercise the actual main-process IPC flow. Only Electron and the OS boundary
// are simulated; no real monitor configuration is changed by this test.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {EventEmitter}=require('node:events');
const origin='https://universe-teacher.local';
const url=origin+'/assets/audience-window-test.html#universe-presenter-test';
const home={id:1,internal:true,bounds:{x:0,y:0,width:1366,height:768}};
const external={id:2,internal:false,bounds:{x:1366,y:0,width:1280,height:720}};
async function harness(options={}){
 let elapsed=0,requested=false,restored=false,manualState=null,quitCompleted=false,windows=[],commands=[],queries=[],logs=[],macCalls=[];
 const handlers=new Map();
 const extended=()=>!restored&&(options.extended||requested&&options.appearsAfter!==undefined&&elapsed>=options.appearsAfter);
 const topology=()=>manualState||((extended()||options.nativeExtended||(requested&&!restored&&options.nativeOnlySwitch))?[
  {Target:'gpu:internal',Internal:true,X:0,Y:0,Width:1366,Height:768},
  {Target:'gpu:projector',Internal:false,X:1366,Y:0,Width:1280,Height:720}
 ]:options.originalMode==='internal'?[
  {Target:'gpu:internal',Internal:true,X:0,Y:0,Width:1366,Height:768}
 ]:options.originalMode==='external'?[
  {Target:'gpu:projector',Internal:false,SingleMode:'external',X:0,Y:0,Width:1280,Height:720}
 ]:[
  {Target:'gpu:internal',Internal:true,X:0,Y:0,Width:1280,Height:720},
  {Target:'gpu:projector',Internal:false,X:0,Y:0,Width:1280,Height:720}
 ]);
 class Window extends EventEmitter{
  constructor(config){super();this.config=config;this.bounds={x:0,y:0,...config};this.destroyed=false;this.webContents=new EventEmitter();
   this.messages=[];Object.assign(this.webContents,{send:(...args)=>this.messages.push(args),getUserAgent:()=>'',setUserAgent:()=>{},setWindowOpenHandler:fn=>{this.windowOpen=fn;},getURL:()=>this.url||'',mainFrame:{url:origin+'/'}});windows.push(this);}
  getBounds(){return this.bounds;}setBounds(b){this.bounds=b;}setFullScreen(value){this.fullscreen=value;if(value&&options.platform==='darwin'&&windows[0]!==this)windows[0].visible=false;queueMicrotask(()=>this.emit(value?'enter-full-screen':'leave-full-screen'));}isFullScreen(){return Boolean(this.fullscreen);}
  setSimpleFullScreen(value){this.simpleFullscreen=value;}isSimpleFullScreen(){return Boolean(this.simpleFullscreen);}
  isDestroyed(){return this.destroyed;}show(){this.visible=true;}showInactive(){this.visible=true;}focus(){this.focused=true;}isMinimized(){return Boolean(this.minimized);}restore(){this.minimized=false;}
  loadURL(value){this.url=value;if(options.loadFailure&&value.includes('audience-window-'))return Promise.reject(new Error('bundled audience load failed'));queueMicrotask(()=>this.emit('ready-to-show'));return Promise.resolve();}
  close(){this.emit('close');this.destroyed=true;this.emit('closed');}
 }
 const app=new EventEmitter();Object.assign(app,{isPackaged:true,setName:()=>{},getName:()=>'',setPath:()=>{},getPath:()=>'/test',requestSingleInstanceLock:()=>true,whenReady:()=>Promise.resolve(),quit:()=>{let prevented=false;app.emit('before-quit',{preventDefault(){prevented=true;}});if(!prevented)quitCompleted=true;}});
 const electron={app,BrowserWindow:Window,protocol:{handle:()=>{}},shell:{openExternal:()=>{}},ipcMain:{handle:(key,fn)=>handlers.set(key,fn)},
  screen:Object.assign(new EventEmitter(),{getAllDisplays:()=>extended()?[home,external]:[home],getDisplayMatching:b=>b.x>=1366?external:home}),
  session:{defaultSession:{webRequest:{onBeforeRequest:()=>{}},setPermissionRequestHandler:()=>{},setPermissionCheckHandler:()=>{}}}};
 const context={process:{platform:options.platform||'win32',arch:'x64',env:{SystemRoot:'C:\\Windows'},resourcesPath:'C:\\Universe\\resources'},__dirname,
  console:{error:(...args)=>logs.push(args),warn:(...args)=>logs.push(args)},URL,Promise,Buffer,
  setTimeout:(fn,ms)=>{elapsed+=ms;queueMicrotask(fn);},clearTimeout:()=>{},
  require:name=>{
   if(name==='electron')return electron;
   if(name==='./edition.json')return {student:false};
   if(name==='./local-content.cjs')return {createContentHandler:()=>{}};
   if(name==='./updates.cjs')return {setupUpdates:()=>{}};
   if(name==='./mac-display-mode.cjs')return {createMacDisplaySession:()=>({
    async extend(){macCalls.push('extend');if(options.macError)throw options.macError;requested=true;restored=false;},
    async capture(){macCalls.push('capture');},
    async restore(){macCalls.push('restore');if(requested){restored=true;requested=false;}}
   })};
   if(name==='./display-mode.cjs'){
    const module={exports:{}};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'display-mode.cjs'),'utf8'),{...context,module,exports:module.exports},{filename:'display-mode.cjs'});return module.exports;
   }
   if(name==='child_process')return {execFile:(file,args,opts,done)=>{
    if(path.win32.basename(file).toLowerCase()==='powershell.exe'){
     queries.push({file,args,opts});queueMicrotask(()=>done(options.queryError,JSON.stringify(topology())));return;
    }
    commands.push({file,args,opts});
    const system=path.win32.basename(file).toLowerCase()==='displayswitch.exe';
    if(system&&args[0]==='/extend'){requested=true;restored=false;}
    else if(system&&!options.restoreFailure){restored=true;requested=false;}
    const error=!system?Object.assign(new Error('Application Control policy blocked the custom helper'),{code:'EACCES'}):options.commandError;
    queueMicrotask(()=>done(error));
   }};
   return require(name);
  }};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'main.cjs'),'utf8'),context,{filename:'main.cjs'});
 await new Promise(resolve=>setImmediate(resolve));
 const main=windows[0],event={sender:main.webContents,senderFrame:main.webContents.mainFrame};
 return {windows,commands,queries,logs,macCalls,main,app,screen:electron.screen,get quitCompleted(){return quitCompleted;},get elapsed(){return elapsed;},setTopology(value){manualState=value;},fullscreen:(action='toggle',e=event)=>handlers.get('universe:fullscreen')(e,action),open:(value=url,e=event)=>handlers.get('universe:projector')(e,value)};
}
test('Mac classroom fullscreen toggles only the native legacy fullscreen and synchronizes the button',async()=>{
 const h=await harness({platform:'darwin'});
 assert.equal(h.fullscreen('get'),false);assert.equal(h.fullscreen(),true);
 assert.equal(h.main.isSimpleFullScreen(),true);assert.equal(h.main.isFullScreen(),false);
 assert.equal(h.main.messages.at(-1)[0],'universe:fullscreen-state');assert.equal(h.main.messages.at(-1)[1],true);
 assert.equal(h.fullscreen(),false);assert.equal(h.main.visible,true);
});
test('fullscreen IPC rejects external pages, child frames and windows, invalid actions and Windows',async()=>{
 const h=await harness({platform:'darwin'});
 assert.equal(h.fullscreen('toggle',{sender:{},senderFrame:h.main.webContents.mainFrame}),null);
 assert.equal(h.fullscreen('toggle',{sender:h.main.webContents,senderFrame:{url:origin+'/'}}),null);
 assert.equal(h.fullscreen('bad'),null);h.main.webContents.mainFrame.url='https://example.com';assert.equal(h.fullscreen(),null);
 assert.equal(h.main.isSimpleFullScreen(),false);assert.equal((await harness()).fullscreen(),null);
});
test('Mac Escape and F11 keep native fullscreen and the classroom button in sync',async()=>{
 const h=await harness({platform:'darwin'});const input=key=>h.main.webContents.emit('before-input-event',{preventDefault(){}},{type:'keyDown',key});
 input('F11');assert.equal(h.fullscreen('get'),true);input('Escape');assert.equal(h.fullscreen('get'),false);
 assert.equal(h.main.messages.at(-1)[1],false);assert.equal(h.main.visible,true);
});
test('Mac exits teacher simple fullscreen before close, quit and projector startup',async()=>{
 for(const action of ['close','quit','projector']){
  const h=await harness({platform:'darwin',extended:true});h.fullscreen();
  if(action==='close')h.main.close();else if(action==='quit')h.app.quit();else await h.open();
  await new Promise(resolve=>setImmediate(resolve));assert.equal(h.main.isSimpleFullScreen(),false,action);
  if(action==='projector'){assert.equal(h.main.visible,true);assert.equal(h.windows[1].simpleFullscreen,true);}
  if(action==='quit')assert.equal(h.quitCompleted,true);
 }
});
test('one projector click uses the Windows system switch when the custom helper is blocked',async()=>{
 const h=await harness({appearsAfter:750});const result=await h.open();
 assert.equal(result.ok,true,'An unsigned helper being blocked must not prevent the built-in Windows switch');
 assert.equal(h.commands.length,1);assert.equal(path.win32.basename(h.commands[0].file),'DisplaySwitch.exe');
 assert.deepEqual(Array.from(h.commands[0].args),['/extend']);assert.equal(h.commands[0].opts.windowsHide,true);
 assert.equal(h.windows.length,2);assert.equal(h.windows[1].fullscreen,true);assert.equal(h.windows[1].bounds.x,1366);
 assert.equal(h.main.bounds.x,0);assert.equal(h.windows[1].config.frame,false);
});
test('already extended displays need no OS command; Escape closes and the next click reopens',async()=>{
 const h=await harness({extended:true});assert.equal((await h.open()).ok,true);assert.equal(h.commands.length,0);
 h.windows[1].webContents.emit('before-input-event',{preventDefault(){}},{type:'keyDown',key:'Escape'});
 assert.equal(h.windows[1].destroyed,true);assert.equal((await h.open()).ok,true);assert.equal(h.windows.length,3);
});
test('wait for the real screen topology, even if the switching process reports an error',async()=>{
 const h=await harness({appearsAfter:2000,commandError:Object.assign(new Error('process timeout'),{code:'ETIMEDOUT'})});
 assert.equal((await h.open()).ok,true);assert.ok(h.elapsed>=2000);assert.equal(h.windows.length,2);
});
test('an exit code of zero without an external display is not a successful projection',async()=>{
 const h=await harness();assert.equal((await h.open()).ok,false);assert.equal(h.windows.length,1);
 assert.ok(h.elapsed>=5000&&h.elapsed<=20000,'Detection must allow Windows to settle, but remain bounded');
});
test('concurrent clicks share a switch request and create only one audience window',async()=>{
 const h=await harness({appearsAfter:750});const results=await Promise.all([h.open(),h.open(),h.open()]);
 assert.ok(results.every(r=>r.ok));assert.equal(h.commands.length,1);assert.equal(h.windows.length,2);
});
test('invalid destinations and IPC callers never trigger an OS display change',async()=>{
 const h=await harness();
 for(const candidate of ['https://example.com/','https://universe-teacher.local/#universe-presenter-test',origin+'/assets/audience-window-test.html'])assert.equal((await h.open(candidate)).ok,false);
 assert.equal((await h.open(url,{sender:{},senderFrame:h.main.webContents.mainFrame})).ok,false);
 assert.equal((await h.open(url,{sender:h.main.webContents,senderFrame:{url:origin+'/'}})).ok,false);
 assert.equal(h.commands.length,0);assert.equal(h.windows.length,1);
});
test('closing the teacher window during switching never opens an orphan projector',async()=>{
 const h=await harness({appearsAfter:750});const pending=h.open();h.main.close();
 assert.equal((await pending).ok,false);assert.equal(h.windows.length,1);
});
test('macOS does not run Windows commands',async()=>{
 const h=await harness({platform:'darwin'});assert.equal((await h.open()).ok,false);assert.equal(h.commands.length,0);
 const extended=await harness({platform:'darwin',extended:true});assert.equal((await extended.open()).ok,true);assert.equal(extended.commands.length,0);
});

test('Mac extended projector exits with Escape, reopens and quits without changing system display settings',async()=>{
 const h=await harness({platform:'darwin',extended:true});
 assert.equal((await h.open()).ok,true);assert.equal(h.windows[1].simpleFullscreen,true);
 assert.equal(h.main.bounds.x,0);assert.equal(h.windows[1].bounds.x,1366);
 h.windows[1].webContents.emit('before-input-event',{preventDefault(){}},{type:'keyDown',key:'Escape'});
 assert.equal(h.windows[1].destroyed,true);assert.equal((await h.open()).ok,true);
 h.app.quit();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(h.quitCompleted,true);assert.equal(h.windows[2].destroyed,true);
 assert.equal(h.commands.length,0);assert.equal(h.queries.length,0);
});

test('Mac mirror mode switches once, keeps the teacher visible and avoids a native fullscreen Space',async()=>{
 const h=await harness({platform:'darwin',appearsAfter:750});
 h.main.setBounds({...external.bounds,width:900,height:600});h.main.minimized=true;
 const results=await Promise.all([h.open(),h.open()]);
 assert.ok(results.every(r=>r.ok));assert.equal(h.windows.length,2);
 assert.equal(h.macCalls.filter(c=>c==='extend').length,1);
 assert.equal(h.windows[1].simpleFullscreen,true);assert.notEqual(h.windows[1].fullscreen,true);
 assert.equal(h.main.visible,true);assert.equal(h.main.minimized,false);assert.equal(h.main.focused,true);
 assert.equal(h.main.bounds.x>=0&&h.main.bounds.x+h.main.bounds.width<=1366,true);
 assert.equal(h.windows[1].bounds.x,1366);assert.equal(h.commands.length,0);
 h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));
 assert.ok(h.macCalls.includes('restore'));assert.equal(h.main.visible,true);
});

test('Mac cannot open a projector onto the laptop when the display switch fails',async()=>{
 const h=await harness({platform:'darwin',macError:new Error('hardware mirror cannot be disabled')});
 assert.equal((await h.open()).ok,false);assert.equal(h.windows.length,1);assert.equal(h.main.visible,true);
 assert.equal(h.macCalls[0],'extend');assert.ok(h.macCalls.includes('restore'));
});

test('Mac exits an existing teacher fullscreen Space before positioning two windows',async()=>{
 const h=await harness({platform:'darwin',extended:true});h.main.fullscreen=true;
 assert.equal((await h.open()).ok,true);assert.equal(h.main.fullscreen,false);
 assert.equal(h.main.visible,true);assert.equal(h.windows[1].simpleFullscreen,true);
});

test('Mac projector is closed if its display is removed, keeping the teaching window usable',async()=>{
 const h=await harness({platform:'darwin',extended:true});await h.open();
 h.screen.emit('display-removed',{},external);
 assert.equal(h.windows[1].destroyed,true);await new Promise(resolve=>setImmediate(resolve));
 assert.equal(h.main.visible,true);
});

test('Mac window.open fallback goes through the same protected projector flow',async()=>{
 const h=await harness({platform:'darwin',appearsAfter:250});
 const result=h.main.windowOpen({url});assert.equal(result.action,'deny','Do not let Chromium create an unmanaged audience window');
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(h.windows.length,2);assert.equal(h.windows[1].simpleFullscreen,true);assert.equal(h.main.visible,true);
 h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));assert.ok(h.macCalls.includes('restore'));
});

test('closing the Mac projector leaves simple fullscreen before destroying its window',async()=>{
 const h=await harness({platform:'darwin',extended:true});await h.open();const audience=h.windows[1];
 audience.close();assert.equal(audience.simpleFullscreen,false);await new Promise(resolve=>setImmediate(resolve));assert.equal(h.main.visible,true);
});
test('ending a projection restores Duplicate when the app temporarily enabled Extend',async()=>{
 const h=await harness({appearsAfter:750});assert.equal((await h.open()).ok,true);
 h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));
 assert.ok(h.commands.some(c=>c.args[0]==='/clone'),'Closing the projector must release the temporary Windows display change');
});
test('a delayed display change is restored even when the teacher closes during startup',async()=>{
 const h=await harness({appearsAfter:750});const opening=h.open();
 // Close after the OS switch has been dispatched, not before setup begins.
 while(!h.commands.length)await Promise.resolve();h.main.close();h.app.quit();
 assert.equal((await opening).ok,false);await new Promise(resolve=>setImmediate(resolve));
 assert.equal(h.windows.length,1);assert.ok(h.commands.some(c=>c.args[0]==='/clone'));assert.equal(h.quitCompleted,true);
});
test('a pre-existing native Extend layout is left alone even when Electron has not detected it',async()=>{
 const h=await harness({nativeExtended:true});assert.equal((await h.open()).ok,false);
 // The native mode was already extended before the click; do not assume ownership.
 assert.equal(h.commands.length,0);
});
test('a failed start restores a temporary mode even when Electron never detects the second screen',async()=>{
 const h=await harness({nativeOnlySwitch:true});assert.equal((await h.open()).ok,false);
 assert.equal(h.windows.length,1);assert.equal(h.commands.at(-1).args[0],'/clone');
});
test('an audience page load failure restores the original mode',async()=>{
 const h=await harness({appearsAfter:750,loadFailure:true});assert.equal((await h.open()).ok,false);
 assert.equal(h.windows[1].destroyed,true);assert.equal(h.commands.at(-1).args[0],'/clone');
});
test('single-screen modes restore to their own original setting, never blindly to Duplicate',async()=>{
 for(const [originalMode,expected] of [['internal','/internal'],['external','/external']]){
  const h=await harness({originalMode,appearsAfter:750});assert.equal((await h.open()).ok,true);
  h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));assert.equal(h.commands.at(-1).args[0],expected);
 }
});
test('unknown initial topology causes no automatic OS mutation',async()=>{
 const h=await harness({queryError:new Error('read blocked')});assert.equal((await h.open()).ok,false);assert.equal(h.commands.length,0);
});
test('a user display change made during projection is preserved',async()=>{
 const h=await harness({appearsAfter:750});await h.open();
 h.setTopology([{Target:'gpu:internal',Internal:true,X:0,Y:0,Width:1366,Height:768}]);
 h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));assert.equal(h.commands.length,1);
});
test('a manual resolution change within Extend is preserved',async()=>{
 const h=await harness({appearsAfter:750});await h.open();
 h.setTopology([{Target:'gpu:internal',Internal:true,X:0,Y:0,Width:1366,Height:768},{Target:'gpu:projector',Internal:false,X:1366,Y:0,Width:1920,Height:1080}]);
 h.windows[1].close();await new Promise(resolve=>setImmediate(resolve));assert.equal(h.commands.length,1);
});
test('closing and immediately reopening waits for restoration before enabling Extend again',async()=>{
 const h=await harness({appearsAfter:750});await h.open();h.windows[1].close();
 assert.equal((await h.open()).ok,true);
 assert.deepEqual(h.commands.map(c=>c.args[0]),['/extend','/clone','/extend']);assert.equal(h.windows.length,3);
});
test('quitting with an audience waits for restoration',async()=>{
 const h=await harness({appearsAfter:750});await h.open();h.app.quit();
 assert.equal(h.quitCompleted,false);await new Promise(resolve=>setImmediate(resolve));
 assert.equal(h.windows[1].destroyed,true);assert.equal(h.commands.at(-1).args[0],'/clone');assert.equal(h.quitCompleted,true);
});
test('failed restoration is detected and cannot trap the app in an endless quit loop',async()=>{
 const h=await harness({appearsAfter:750,restoreFailure:true});await h.open();h.app.quit();
 await new Promise(resolve=>setImmediate(resolve));assert.equal(h.quitCompleted,true);
 assert.ok(h.logs.some(row=>row.join(' ').includes('did not restore')));assert.ok(h.elapsed<15000);
});
