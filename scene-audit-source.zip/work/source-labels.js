export const sourceLabel=id=>({new1:'马来文讲解',new2:'英文讲解',new3:'双语复习',new4:'英文补充',new5:'马来文补充',old11:'恒星与星系练习',old12:'太阳系练习',old13:'其他天体练习',appendix:'跨章复习'}[id]||'学习资料');
