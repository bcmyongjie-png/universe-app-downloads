export const isStudent=typeof __STUDENT__!=='undefined'&&__STUDENT__;
export const editionName=isStudent?'Student · 学生版':'Teacher · 教师版';
export function markEdition(hud){
 document.body.dataset.edition=isStudent?'student':'teacher';
 document.title='宇宙漫游 · '+editionName;
 const badge=document.createElement('span');badge.id='editionBadge';badge.textContent=editionName;hud.append(badge);
}
