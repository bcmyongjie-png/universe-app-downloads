const {contextBridge,ipcRenderer}=require('electron');
const allowed=['https://universe-teacher.local','https://universe-student.local'];
if(allowed.includes(location.origin))contextBridge.exposeInMainWorld('universeDesktop',{openProjector:url=>ipcRenderer.invoke('universe:projector',url)});
if(allowed.includes(location.origin)&&location.pathname==='/')window.addEventListener('DOMContentLoaded',()=>{
 let button,status,latest,toast;const dismissed=new Set();
 const action=()=>ipcRenderer.invoke(latest?.phase==='ready'?'universe:update-install':latest?.phase==='available'?'universe:update-download':'universe:update-check').then(s=>{if(s&&typeof s==='object')render(s)});
 function render(s){if(!s)return;latest=s;const ready=s.phase==='ready',available=s.phase==='available',label=ready?(process.platform==='win32'?'安装并退出':'打开新版安装包'):available?'下载更新':'检查更新';
  const labels={idle:'联网时自动检查，由你选择是否更新',checking:'正在检查更新…',current:'已是最新版本',available:s.downloadFailed?'下载未完成，可重试；当前版本照常使用':'发现 v'+s.next+'，是否更新由你决定',downloading:'正在下载更新'+(s.percent?' · '+s.percent+'%':''),ready:'新版已下载，选择安装或稍后再说',unavailable:'暂时无法检查更新，离线课堂照常使用'};
  if(button){status.textContent='v'+s.version+' · '+labels[s.phase];button.textContent=label;button.disabled=['checking','downloading'].includes(s.phase)}
  if(toast){toast.remove();toast=null}const key=s.phase+':'+s.next;if((available||ready)&&!dismissed.has(key)){
   toast=document.createElement('aside');toast.id='appUpdateNotice';toast.setAttribute('aria-label','App 更新');toast.style.cssText='position:fixed;right:20px;bottom:20px;z-index:100000;max-width:300px;padding:16px;background:#12232f;color:#fff;border:1px solid #536b78;border-radius:14px;box-shadow:0 8px 30px #0006;font:14px/1.5 system-ui';
   const text=document.createElement('p');text.textContent=ready?'新版已下载，是否现在安装？':'发现新版 v'+s.next+'，是否下载更新？';text.style.margin='0 0 12px';const yes=document.createElement('button'),later=document.createElement('button');yes.textContent=label;later.textContent='稍后';for(const b of [yes,later])b.style.cssText='padding:7px 12px;border-radius:8px;border:1px solid #7996a8;margin-right:8px;cursor:pointer';yes.onclick=()=>{dismissed.add(key);void action()};later.onclick=()=>{dismissed.add(key);toast?.remove();toast=null};toast.append(text,yes,later);document.body.append(toast);
  }
 }
 function mount(){const panel=document.querySelector('#teacherPanel');if(!panel||button)return;button=document.createElement('button');button.id='appUpdateButton';button.type='button';status=document.createElement('p');status.id='appUpdateStatus';status.setAttribute('role','status');status.style.cssText='font-size:12px;line-height:1.5;opacity:.8';panel.append(button,status);button.onclick=()=>void action();void ipcRenderer.invoke('universe:update-status').then(render);observer.disconnect()}
 const observer=new MutationObserver(mount);observer.observe(document.body,{childList:true,subtree:true});ipcRenderer.on('universe:update-state',(_event,s)=>render(s));window.addEventListener('online',()=>void ipcRenderer.invoke('universe:update-online'));mount();
});
