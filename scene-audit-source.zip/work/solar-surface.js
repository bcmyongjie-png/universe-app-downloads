import * as T from 'three';
// Visible-light inspired photosphere. Granulation and sunspots are illustrative,
// with exposure and time adjusted for classroom viewing; not live observations.
const noiseGLSL=`
float hash(vec3 p){p=fract(p*.3183099+vec3(.17,.31,.53));p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){return .52*noise(p)+.27*noise(p*2.03)+.14*noise(p*4.11)+.07*noise(p*8.31);}
`;
export function solarSurface(){return new T.ShaderMaterial({uniforms:{time:{value:0},spin:{value:0},sunlit:{value:0}},vertexShader:`varying vec3 surface;varying vec3 nView;void main(){surface=normalize(position);nView=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform float time;varying vec3 surface;varying vec3 nView;${noiseGLSL}
float region(vec3 p,vec3 c,float width){return exp(-pow(length(p-normalize(c))/width,2.));}
void main(){vec3 p=normalize(surface);float a=time*.007;p=mat3(cos(a),0.,sin(a),0.,1.,0.,-sin(a),0.,cos(a))*p;
vec3 warp=vec3(fbm(p*12.),fbm(p*12.+13.),fbm(p*12.+29.))-.5;
vec3 q=p*76.+warp*5.+vec3(0.,time*.027,0.);
float grains=fbm(q);float threads=pow(1.-abs(2.*noise(q*2.4)-1.),5.);
vec3 field=normalize(p+warp*.32);float activity=region(field,vec3(-.72,.10,.72),.22)+region(field,vec3(.5,-.32,.9),.19)+region(field,vec3(.43,.47,.8),.14)+region(field,vec3(-.2,-.6,-.8),.2)+region(field,vec3(.9,.3,-.4),.17);
float energy=clamp(.13+.47*grains+.20*threads+activity*(.25+.7*fbm(p*30.+warp*3.)),0.,1.);
float spots=smoothstep(.5,.9,activity)*.5;
vec3 c=vec3(.95,.91,.84)*(.91+.09*grains)*(1.-spots);
float limb=.62+.38*pow(max(normalize(nView).z,0.),.45);gl_FragColor=vec4(c*limb*.75,1.);}`});}
export function solarCorona(radius){
 const group=new T.Group();
 const shell=new T.Mesh(new T.SphereGeometry(radius*1.025,80,48),new T.ShaderMaterial({uniforms:{time:{value:0}},side:T.BackSide,transparent:true,depthWrite:false,blending:T.AdditiveBlending,vertexShader:`varying vec3 n;varying vec3 p;void main(){p=normalize(position);n=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform float time;varying vec3 n;varying vec3 p;${noiseGLSL}void main(){float rim=pow(1.-abs(normalize(n).z),3.);float strands=.2+.8*fbm(p*44.+vec3(0,time*.065,0));gl_FragColor=vec4(vec3(.75,.78,.82),rim*strands*.09);}`}));group.add(shell);
 return group;
}
