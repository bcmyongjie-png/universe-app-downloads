import * as T from 'three';
const center=new T.Vector3(),scale=new T.Vector3(),offset=new T.Vector3();
// Keep the near clipping plane outside opaque celestial surfaces.
export function keepCameraOutsideBodies(camera,bodies){
 for(let pass=0;pass<2;pass++)for(const body of bodies){
  const material=body.material;
  if(!body.visible||!body.userData.r||!material||Array.isArray(material)||material.transparent||material.opacity<1)continue;
  body.updateWorldMatrix(true,false);body.getWorldPosition(center);body.getWorldScale(scale);
  if(!body.geometry.boundingSphere)body.geometry.computeBoundingSphere();
  const radius=(body.geometry.boundingSphere?.radius||body.userData.r)*Math.max(Math.abs(scale.x),Math.abs(scale.y),Math.abs(scale.z));
  const clearance=Math.max(.15,camera.near*3,radius*.08),limit=radius+clearance;
  offset.copy(camera.position).sub(center);
  if(offset.lengthSq()<limit*limit){
   if(offset.lengthSq()<1e-10)camera.getWorldDirection(offset).negate();
   camera.position.copy(center).add(offset.normalize().multiplyScalar(limit));
  }
 }
}
