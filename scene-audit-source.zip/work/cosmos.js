import {galaxyArt} from './galaxy-art.js';
import * as T from 'three';
// Spatial composition is illustrative, not an astrometric catalogue.
export const neighbors=[
 {id:'cosmos-milky',name:'银河系',bm:'Bima Sakti',en:'Milky Way',desc:'我们所在的棒旋星系',p:[-20,-3,13],r:30,tilt:[.08,0,-.25],kind:0},
 {id:'cosmos-m31',name:'仙女座星系',bm:'Galaksi Andromeda',en:'Andromeda · M31',desc:'本星系群的大型旋涡星系，距地球约 250 万光年',p:[27,18,-19],r:25,tilt:[.5,.2,-.55],kind:0},
 {id:'cosmos-m33',name:'三角座星系',bm:'Galaksi Triangulum',en:'Triangulum · M33',desc:'本星系群第三大星系，距地球约 300 万光年',p:[-32,24,-25],r:11,tilt:[.65,0,.4],kind:0},
 {id:'cosmos-lmc',name:'大麦哲伦云',bm:'Awan Magellan Besar',en:'Large Magellanic Cloud',desc:'银河系附近的不规则星系',p:[11,-16,24],r:3.8,tilt:[.2,0,.3],kind:2},
 {id:'cosmos-smc',name:'小麦哲伦云',bm:'Awan Magellan Kecil',en:'Small Magellanic Cloud',desc:'银河系附近的不规则矮星系',p:[-32,-24,22],r:2.7,tilt:[.4,0,0],kind:2},
 {id:'cosmos-m32',name:'M32',bm:'Galaksi elips kerdil',en:'Dwarf elliptical galaxy',desc:'仙女座星系附近的紧致椭圆星系',p:[39,1,-3],r:2.3,tilt:[.4,0,.4],kind:1},
 {id:'cosmos-m110',name:'M110',bm:'Galaksi elips kerdil',en:'Dwarf elliptical galaxy',desc:'仙女座星系的椭圆矮星系伴星系',p:[13,23,-26],r:3,tilt:[.4,0,.4],kind:1}
];
export function drawCosmos(w){
 w.clear();w.mode='cosmos';w.stars.visible=false;
 let seed=6189;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 function galaxy(d,background=false){
  const group=new T.Group();group.position.set(...d.p);group.rotation.set(...d.tilt);w.root.add(group);
  group.add(galaxyArt(w,d.r,{kind:d.kind,seed:Math.floor(rand()*1000),dim:background?.45:1.4,detail:!background}));
  if(!background){const hit=new T.Mesh(new T.SphereGeometry(Math.max(d.r,4.5),16,12),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hit.userData={id:d.id,r:d.r*.55};group.add(hit);w.meshes.push(hit);w.label(d.id,d.name,group,new T.Vector3(0,d.kind===2?d.r*1.4:-d.r*.6,0));const label=w.hotspots[w.hotspots.length-1].el;label.classList.add('galaxyName');const type=document.createElement('small');type.textContent=['旋涡星系','椭圆星系','不规则星系'][d.kind];label.append(type);label.setAttribute('aria-label','探索'+d.name+'，'+type.textContent);if(d.id==='cosmos-milky')w.cosmosAnchor=hit;}
 }
 neighbors.forEach(d=>galaxy(d));
 // Unnamed distant galaxies are atmosphere, not measured objects or real coordinates.
 for(let i=0;i<46;i++)galaxy({p:[(rand()-.5)*240,(rand()-.5)*140,-45-rand()*170],r:1+rand()*3,tilt:[rand()*2,rand()*3,rand()*3],kind:i%5===0?1:0},true);
 w.controls.target.set(0,0,0);w.camera.position.set(0,43,103);if(innerWidth<650)w.camera.position.set(0,55,225);w.controls.maxDistance=300;w.controls.update();
}
