const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const BASE='https://github.com/bcmyongjie-png/universe-app-downloads/releases/latest/download/';
function newer(next,current){const parse=v=>/^\d+\.\d+\.\d+$/.test(v)?v.split('.').map(Number):null,a=parse(next),b=parse(current);if(!a||!b)return false;for(let i=0;i<3;i++){if(a[i]!==b[i])return a[i]>b[i]}return false}
function validMac(info,edition){if(info?.edition!==edition||!/^\d+\.\d+\.\d+$/.test(info.version)||!Number.isSafeInteger(info.size)||info.size<=0||info.size>2e9||!/^[A-Za-z0-9+/]{86}==$/.test(info.sha512))throw Error('Invalid update manifest');const url=new URL(info.url);if(url.origin!=='https://github.com'||!url.pathname.startsWith('/bcmyongjie-png/universe-app-downloads/releases/download/')||!url.pathname.endsWith('.dmg')||url.username||url.password)throw Error('Invalid update URL');return info}
async function downloadMac(info,directory,fetcher=fetch){await fs.mkdir(directory,{recursive:true});const file=path.join(directory,'Universe-'+info.edition+'-'+info.version+'.dmg'),temporary=file+'.partial';
 try{const response=await fetcher(info.url,{signal:AbortSignal.timeout(30*60*1000)});if(!response.ok||!response.body)throw Error('Download unavailable');const handle=await fs.open(temporary,'w'),hash=crypto.createHash('sha512');let size=0;try{for await(const data of response.body){size+=data.length;if(size>info.size)throw Error('Update too large');hash.update(data);await handle.writeFile(data)}}finally{await handle.close()};if(size!==info.size||hash.digest('base64')!==info.sha512)throw Error('Update checksum mismatch');await fs.rename(temporary,file);return file}catch(e){await fs.rm(temporary,{force:true});throw e}
}
function setupUpdates({app,ipcMain,main,edition}){
 const {dialog,shell}=require('electron'),lower=edition.student?'student':'teacher';let state={phase:'idle',version:app.getVersion()},busy=null,readyFile=null,windowsUpdater=null;
 const send=patch=>{state={...state,...patch};if(!main.isDestroyed())main.webContents.send('universe:update-state',state)};
 if(process.platform==='win32'){
  const {autoUpdater}=require('electron-updater');windowsUpdater=autoUpdater;autoUpdater.autoDownload=true;autoUpdater.autoInstallOnAppQuit=true;autoUpdater.allowDowngrade=false;autoUpdater.disableDifferentialDownload=true;
  autoUpdater.setFeedURL({provider:'generic',url:BASE,channel:lower});
  autoUpdater.on('checking-for-update',()=>send({phase:'checking'}));autoUpdater.on('update-not-available',()=>send({phase:'current'}));autoUpdater.on('update-available',info=>send({phase:'downloading',next:info.version}));autoUpdater.on('download-progress',p=>send({phase:'downloading',percent:Math.round(p.percent)}));autoUpdater.on('update-downloaded',info=>send({phase:'ready',next:info.version}));autoUpdater.on('error',()=>send({phase:'unavailable'}));
 }
 async function check(){if(busy)return busy;if(state.phase==='ready')return state;busy=(async()=>{try{send({phase:'checking'});if(windowsUpdater){const result=await windowsUpdater.checkForUpdates();if(result?.downloadPromise)await result.downloadPromise;}else if(process.platform==='darwin'){const r=await fetch(BASE+lower+'-mac.json',{signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('Update server unavailable');const info=validMac(await r.json(),lower);if(!newer(info.version,app.getVersion())){send({phase:'current'});return state}send({phase:'downloading',next:info.version});readyFile=await downloadMac(info,path.join(app.getPath('userData'),'updates'));send({phase:'ready',next:info.version});}return state}catch{send({phase:'unavailable'});return state}finally{busy=null}})();return busy}
 const trusted=e=>e.sender===main.webContents&&e.senderFrame===main.webContents.mainFrame;
 ipcMain.handle('universe:update-status',e=>trusted(e)?state:null);
 ipcMain.handle('universe:update-check',e=>{if(!trusted(e))return null;void check();return state});
 ipcMain.handle('universe:update-install',async e=>{if(!trusted(e)||state.phase!=='ready')return false;if(process.platform==='win32'){const result=await dialog.showMessageBox(main,{type:'question',message:'安装更新并退出课堂？',detail:'请先结束投影。也可以稍后正常退出 App，届时自动安装。',buttons:['稍后','安装并退出'],defaultId:0,cancelId:0});if(result.response===1)windowsUpdater.quitAndInstall(false,true);return result.response===1;}if(readyFile){const error=await shell.openPath(readyFile);return !error}return false});
 if(app.isPackaged&&!process.env.UNIVERSE_TEST_DATA){const initial=setTimeout(()=>void check(),30000),timer=setInterval(()=>void check(),4*60*60*1000);initial.unref();timer.unref();app.once('before-quit',()=>{clearTimeout(initial);clearInterval(timer)})}
 return {check,getState:()=>state};
}
module.exports={newer,validMac,downloadMac,setupUpdates};
