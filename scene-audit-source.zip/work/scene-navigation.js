import {connections} from './learning-connections.js';
import {chapterOf} from './teaching-content.js';

// IDs belong to rendered objects, not positions in the settings dropdown.
export const objectLessons={
 'life':['galaxy',3], 'nebula':['galaxy',3], 'milky':['galaxy',0],
 'star':['galaxy',7], 'giant':['galaxy',5], 'remnant':['galaxy',7],
 'sun':['galaxy',4], 'moon':['solar',7], 'station':['galaxy',10],
 'lesson-solar':['solar',0], 'lesson-earth':['earth',1],
 'discover-comet':['visitors',7], 'comet':['visitors',7],
 'discover-belt':['visitors',2], 'asteroid':['visitors',2],
 'discover-shower':['visitors',4], 'meteor':['visitors',3]
};

export function objectLesson(id,level,journeys){
 if(id==='earth')return level>=2?['earth',1]:null; // Keep the Earth orbit entrance.
 if(id==='cosmos-milky'||id==='enter-solar')return null;
 if(id.startsWith('cosmos-'))return ['galaxy',/m32|m110/.test(id)?1:/lmc|smc/.test(id)?2:0];
 if(objectLessons[id])return objectLessons[id];
 const index=journeys.solar.findIndex(d=>d.planet===id);
 return index<0?null:['solar',index];
}

// These are knowledge links, not fictitious objects added to a physical scene.
export function createSceneNavigation(hud,journeys,{enter,allows}){
 const nav=document.createElement('nav');nav.id='sceneTopics';nav.hidden=true;
 nav.setAttribute('aria-label','当前天体的相关课题');hud.append(nav);
 return {
  close(){nav.hidden=true;nav.replaceChildren();},
  show(track,index){
   nav.replaceChildren();
   const links=(connections[track+':'+index]||[]).filter(([key])=>allows(chapterOf(key.split(':')[0])));
   nav.hidden=!links.length;
   for(const [key,why] of links){
    const [nextTrack,value]=key.split(':'),nextIndex=Number(value),d=journeys[nextTrack][nextIndex];
    const a=document.createElement('a');a.href='#explore-'+key.replace(':','-');a.dataset.topic=key;
    a.textContent=d.zh+' ↗';a.title=why;a.setAttribute('aria-label',d.zh+'：'+why);
    a.onclick=e=>{e.preventDefault();enter(nextTrack,nextIndex);};nav.append(a);
   }
  }
 };
}
