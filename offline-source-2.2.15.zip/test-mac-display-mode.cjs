const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const panel={id:1,uuid:'panel',builtin:true,active:true,mirror:0,hardwareMirror:false,fixedMirror:false,x:0,y:0,width:1440,height:900,mode:10,rotation:0};
const projector={id:2,uuid:'projector',builtin:false,active:false,mirror:1,hardwareMirror:false,fixedMirror:false,x:0,y:0,width:1440,height:900,mode:20,rotation:0};
const clone=()=>[structuredClone(panel),structuredClone(projector)];
function harness(initial=clone(),options={}){
 let state=structuredClone(initial);const calls=[];const module={exports:{}};
 const file=path.join(__dirname,'mac-display-mode.cjs');
 assert.ok(fs.existsSync(file),'Mac display session implementation is required');
 vm.runInNewContext(fs.readFileSync(file,'utf8'),{module,console,Promise,JSON,__dirname,process:{resourcesPath:'/app/Resources'},require:name=>name==='node:child_process'?{execFile:(exe,args,opts,done)=>{
  calls.push({exe,args,opts});
  if(options.error)return queueMicrotask(()=>done(options.error));
  if(args[0]==='apply'){
   const expected=JSON.parse(args[1]),target=JSON.parse(args[2]);
   if(JSON.stringify(expected)!==JSON.stringify(state))throw Error('Stale apply request');
   state=target;
  }
  queueMicrotask(()=>done(null,JSON.stringify({ok:true,displays:state})));
 }}:require(name)},{filename:file});
 const session=module.exports.createMacDisplaySession({helperPath:'/app/Resources/mac-display-helper'});
 return {session,calls,get state(){return state;},set state(v){state=structuredClone(v);}};
}
test('Mac mirror session enables two active non-overlapping screens, then restores the exact original mirror',async()=>{
 const h=harness();await h.session.extend();await h.session.capture();
 assert.equal(h.state[0].builtin,true);assert.equal(h.state[0].active,true);assert.equal(h.state[0].mirror,0);
 assert.equal(h.state[1].active,true);assert.equal(h.state[1].mirror,0);assert.equal(h.state[1].x,1440);
 await h.session.restore();assert.deepEqual(h.state,clone());
 assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,2);
 assert.ok(h.calls.every(c=>c.exe==='/app/Resources/mac-display-helper'&&!c.opts.shell));
});
test('Mac manually changed resolution or unplugged display invalidates restoration ownership',async()=>{
 for(const changed of [[{...panel,width:1680,mode:11},{...projector,active:true,mirror:0,x:1680}],[panel]]){
  const h=harness();await h.session.extend();await h.session.capture();h.state=changed;
  await h.session.restore();assert.deepEqual(h.state,changed);assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,1);
 }
});
test('Mac pre-existing Extend is never restored to Mirror',async()=>{
 const initial=[panel,{...projector,active:true,mirror:0,x:-1440}];const h=harness(initial);
 await h.session.extend();await h.session.capture();await h.session.restore();
 assert.deepEqual(h.state,initial);assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,0);
});
test('single screen, closed laptop, fixed mirroring and unknown multi-screen layouts are not changed',async()=>{
 for(const state of [[panel],[{...panel,active:false}, {...projector,active:true,mirror:0}],
  [panel,{...projector,fixedMirror:true}],[panel,projector,{...projector,id:3,uuid:'third'}]]){
  const h=harness(state);await assert.rejects(()=>h.session.extend());await h.session.restore();
  assert.deepEqual(h.state,state);assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,0);
 }
});
test('ordinary hardware-accelerated mirroring can extend; only fixed mirroring is unsupported',async()=>{
 const original=clone().map(r=>({...r,hardwareMirror:true}));const h=harness(original);
 await h.session.extend();assert.equal(h.state[0].active,true);assert.equal(h.state[1].active,true);
 assert.equal(h.state[1].hardwareMirror,false);assert.equal(h.state[1].x,1440);
 await h.session.restore();assert.deepEqual(h.state,original);
});
test('missing or blocked Mac helper leaves the system untouched and reports failure',async()=>{
 const h=harness(clone(),{error:Object.assign(Error('helper blocked'),{code:'EACCES'})});
 await assert.rejects(()=>h.session.extend(),/helper blocked/);await h.session.restore();
 assert.deepEqual(h.state,clone());assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,0);
});
test('Mac capture cannot claim a layout the user changed immediately after switching',async()=>{
 const h=harness();await h.session.extend();h.state=[panel,{...projector,active:true,mirror:0,x:-1440}];
 await h.session.capture();await h.session.restore();assert.equal(h.state[1].x,-1440);
 assert.equal(h.calls.filter(c=>c.args[0]==='apply').length,1);
});
