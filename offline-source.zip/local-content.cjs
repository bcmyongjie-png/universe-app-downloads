const fs=require('node:fs/promises'),path=require('node:path');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.json':'application/json','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.mp4':'video/mp4','.svg':'image/svg+xml'};
function createContentHandler(root,origin){
 root=path.resolve(root);
 return async request=>{
  let url,name;try{url=new URL(request.url);if(url.origin!==origin)return new Response('Offline app: external network disabled',{status:403});name=decodeURIComponent(url.pathname);}catch{return new Response('Bad request',{status:400})}
  if(!['GET','HEAD'].includes(request.method))return new Response('',{status:405});
  if(name==='/')name='/index.html';if(name.includes('\0')||name.includes('\\'))return new Response('',{status:400});
  const file=path.resolve(root,'.'+name);if(!file.startsWith(root+path.sep))return new Response('',{status:403});
  let stat;try{stat=await fs.stat(file);if(!stat.isFile())throw Error();}catch{return new Response('Bundled content not found',{status:404})}
  const headers={'Content-Type':types[path.extname(file)]||(/^audience-window-/.test(path.basename(file))?'text/html; charset=utf-8':'application/octet-stream'),'Accept-Ranges':'bytes','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'};
  let start=0,end=stat.size-1,status=200;const range=request.headers.get('range');
  if(range){const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match||(!match[1]&&!match[2]))return new Response('',{status:416,headers:{'Content-Range':`bytes */${stat.size}`}});if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),end);}else start=Math.max(0,stat.size-Number(match[2]));if(start>end||start>=stat.size)return new Response('',{status:416,headers:{'Content-Range':`bytes */${stat.size}`}});status=206;headers['Content-Range']=`bytes ${start}-${end}/${stat.size}`;}
  headers['Content-Length']=String(Math.max(0,end-start+1));
  if(request.method==='HEAD')return new Response(null,{status,headers});
  const handle=await fs.open(file,'r');let cursor=start,closed=false;
  async function close(){if(!closed){closed=true;await handle.close()}}
  const stream=new ReadableStream({async pull(controller){try{if(cursor>end){await close();controller.close();return}const chunk=Buffer.alloc(Math.min(256*1024,end-cursor+1));const {bytesRead}=await handle.read(chunk,0,chunk.length,cursor);if(!bytesRead){await close();controller.close();return}cursor+=bytesRead;controller.enqueue(new Uint8Array(chunk.buffer,chunk.byteOffset,bytesRead));}catch(e){await close();controller.error(e)}},cancel:close});
  return new Response(stream,{status,headers});
 };
}
module.exports={createContentHandler};
