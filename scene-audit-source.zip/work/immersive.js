import {loadSceneTexture} from './scene-textures.js';
import * as T from 'three';
import dayUrl from './earth.jpg';
import normalUrl from './earth_normal_2048.jpg';
import specularUrl from './earth_specular_2048.jpg';
import cloudsUrl from './earth_clouds_1024.png';
import nightUrl from './earth_lights_2048.png';
import moonUrl from './moon_1024.jpg';

const tex=url=>loadSceneTexture(url,{anisotropy:8});
const earthMat=()=>new T.ShaderMaterial({
 uniforms:{day:{value:tex(dayUrl)},night:{value:tex(nightUrl)},relief:{value:tex(normalUrl)},sea:{value:tex(specularUrl)},sun:{value:new T.Vector3(1,.5,.35).normalize()}},
 vertexShader:`varying vec2 vUv;varying vec3 vN;varying vec3 vW;void main(){vUv=uv;vN=normalize(mat3(modelMatrix)*normal);vW=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vW,1.);}`,
 fragmentShader:`uniform sampler2D day;uniform sampler2D night;uniform sampler2D relief;uniform sampler2D sea;uniform vec3 sun;varying vec2 vUv;varying vec3 vN;varying vec3 vW;void main(){vec3 n=normalize(vN);vec3 bump=texture2D(relief,vUv).rgb*2.-1.;n=normalize(n+vec3(bump.xy*.065,0.));float l=dot(n,sun);vec3 viewDir=normalize(cameraPosition-vW);vec3 d=texture2D(day,vUv).rgb;d=pow(d,vec3(2.2));vec3 c=d*(.018+max(l,0.)*1.75);float nightSide=1.-smoothstep(-.2,.12,l);vec3 cities=texture2D(night,vUv).rgb;c+=pow(cities,vec3(1.6))*vec3(1.4,.88,.45)*nightSide*.95;float spec=pow(max(dot(reflect(-sun,n),viewDir),0.),110.)*texture2D(sea,vUv).r;c+=vec3(.8,.88,1.)*spec*.23;float rim=pow(1.-max(dot(n,viewDir),0.),3.);c+=vec3(.025,.22,.7)*rim*smoothstep(-.35,.4,l)*.6;gl_FragColor=vec4(c,1.);}`
});
function atmosphere(radius){return new T.Mesh(new T.SphereGeometry(radius,96,64),new T.ShaderMaterial({
 vertexShader:`varying vec3 vN;varying vec3 vW;void main(){vN=normalize(mat3(modelMatrix)*normal);vW=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vW,1.);}`,
 fragmentShader:`varying vec3 vN;varying vec3 vW;void main(){vec3 viewDir=normalize(cameraPosition-vW);float rim=pow(1.-abs(dot(normalize(vN),viewDir)),4.);float lit=smoothstep(-.55,.55,dot(normalize(vN),normalize(vec3(1.,.5,.35))));gl_FragColor=vec4(vec3(.03,.32,1.)*1.8,rim*(.22+lit*.75));}`,
 transparent:true,blending:T.AdditiveBlending,side:T.BackSide,depthWrite:false}));}

import {addSceneDiscoveries} from './scene-discoveries.js';
export function earthOrbit(w){
 const group=new T.Group();group.position.set(4,0,0);w.root.add(group);w.orbitEarthGroup=group;
 const earth=new T.Mesh(new T.SphereGeometry(6.3,128,96),earthMat());earth.rotation.y=2.0;earth.userData={id:'earth',r:6.3};group.add(earth);w.meshes.push(earth);w.heroEarth=earth;
 const atmo=atmosphere(6.49);group.add(atmo);
 const cloud=new T.Mesh(new T.SphereGeometry(6.35,96,64),new T.MeshPhongMaterial({map:tex(cloudsUrl),transparent:true,opacity:.6,depthWrite:false,shininess:0}));cloud.rotation.copy(earth.rotation);group.add(cloud);w.heroClouds=cloud;
 const mtex=tex(moonUrl);mtex.colorSpace=T.SRGBColorSpace;
 const moon=new T.Mesh(new T.SphereGeometry(1.72,80,64),new T.MeshStandardMaterial({map:mtex,bumpMap:mtex,bumpScale:.045,roughness:1}));moon.position.set(-5.8,-4.6,8.0);moon.lookAt(4,0,0);const moonPhase=Math.atan2(-8,-9.8);moon.position.set(4+Math.cos(moonPhase)*14,Math.sin(moonPhase)*14*.09,-Math.sin(moonPhase)*14);moon.lookAt(4,0,0);moon.userData={id:'moon',r:1.72,orbitPhase:moonPhase-w.t*.015/27.3};w.root.add(moon);w.meshes.push(moon);w.heroMoon=moon;
 const track=new T.Group();track.rotation.set(.45,0,-.4);group.add(track);w.orbitTrack=track;w.orbit(8.3,'#428abc',track).material.opacity=.4;
 const station=new T.Group();station.position.set(8.3,0,0);track.add(station);w.station=station;
 const hull=new T.Mesh(new T.CylinderGeometry(.1,.1,.7,20),new T.MeshStandardMaterial({color:'#d8e0e6',metalness:.6,roughness:.3}));hull.rotation.z=Math.PI/2;station.add(hull);
 for(const side of [-1,1]){const panel=new T.Mesh(new T.BoxGeometry(.5,.018,.82),new T.MeshStandardMaterial({color:'#294d99',metalness:.6,roughness:.35}));panel.position.x=side*.55;station.add(panel);for(let j=0;j<5;j++){let line=new T.Mesh(new T.BoxGeometry(.005,.023,.82),new T.MeshBasicMaterial({color:'#637d9e'}));line.position.x=side*.55-.24+j*.12;station.add(line);}}
 w.label('earth','地球 · 选择地区',group,new T.Vector3(5,1.8,2));w.label('moon','月球',moon,new T.Vector3(0,2.8,0));addSceneDiscoveries(w,'earth');
 const dustP=[],dustC=[],dustS=[];for(let i=0;i<450;i++){let x=Math.sin(i*127.1)*30,y=Math.sin(i*31.7)*21,z=Math.cos(i*81.1)*30;if(new T.Vector3(x-4,y,z).length()<9)continue;dustP.push(x,y,z);dustC.push(.19,.24,.4);dustS.push(.03+(i%4)*.025);}w.addParticles(dustP,dustC,dustS);
}

export class Flight {
 constructor(w){this.w=w;this.active=false;this.keys=new Set();this.cruise=false;this.velocity=new T.Vector3();this.yaw=0;this.pitch=0;this.pointer=null;this.distance=0;
 window.addEventListener('keydown',e=>{if(!this.active||e.target.matches('input,textarea'))return;if(['KeyW','KeyA','KeyS','KeyD','KeyQ','KeyE','ShiftLeft','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)){e.preventDefault();this.keys.add(e.code);}});window.addEventListener('keyup',e=>this.keys.delete(e.code));window.addEventListener('blur',()=>this.keys.clear());
 const canvas=w.renderer.domElement;canvas.addEventListener('pointerdown',e=>{if(this.active){this.pointer={x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId);}});canvas.addEventListener('pointermove',e=>{if(this.active&&this.pointer){this.yaw-=(e.clientX-this.pointer.x)*.004;this.pitch-=(e.clientY-this.pointer.y)*.004;this.pitch=T.MathUtils.clamp(this.pitch,-1.45,1.45);this.pointer={x:e.clientX,y:e.clientY};}});canvas.addEventListener('pointerup',()=>this.pointer=null);canvas.addEventListener('wheel',e=>{if(this.active)this.velocity.add(w.camera.getWorldDirection(new T.Vector3()).multiplyScalar(e.deltaY<0?4:-4));});
 }
 start(){this.active=true;this.w.fly=null;this.w.follow=null;this.w.controls.enabled=false;const e=new T.Euler().setFromQuaternion(this.w.camera.quaternion,'YXZ');this.yaw=e.y;this.pitch=e.x;this.velocity.set(0,0,0);this.distance=0;this.cruise=false;this.keys.clear();}
 stop(){this.active=false;this.cruise=false;this.keys.clear();this.velocity.set(0,0,0);this.w.controls.enabled=true;this.w.controls.target.copy(this.w.camera.position).add(this.w.camera.getWorldDirection(new T.Vector3()).multiplyScalar(12));}
 update(dt){if(!this.active)return;const w=this.w,cam=w.camera;let local=new T.Vector3((this.keys.has('KeyD')?1:0)-(this.keys.has('KeyA')?1:0),(this.keys.has('KeyE')?1:0)-(this.keys.has('KeyQ')?1:0),(this.keys.has('KeyS')?1:0)-(this.keys.has('KeyW')||this.cruise?1:0));if(this.keys.has('ArrowLeft'))this.yaw+=dt*.7;if(this.keys.has('ArrowRight'))this.yaw-=dt*.7;if(this.keys.has('ArrowUp'))this.pitch=Math.min(this.pitch+dt*.6,1.45);if(this.keys.has('ArrowDown'))this.pitch=Math.max(this.pitch-dt*.6,-1.45);cam.quaternion.setFromEuler(new T.Euler(this.pitch,this.yaw,0,'YXZ'));local.normalize().applyQuaternion(cam.quaternion).multiplyScalar(this.keys.has('ShiftLeft')?18:5);this.velocity.lerp(local,1-Math.exp(-dt*2.8));let delta=this.velocity.clone().multiplyScalar(dt);cam.position.add(delta);this.distance+=delta.length();
 for(const body of w.meshes){if(!body.userData.r)continue;const center=body.getWorldPosition(new T.Vector3()),min=body.userData.r*1.35+.3,away=cam.position.clone().sub(center);if(away.length()<min){cam.position.copy(center).add(away.normalize().multiplyScalar(min));this.velocity.multiplyScalar(.3);}}
 if(cam.position.length()>350){cam.position.setLength(350);this.velocity.set(0,0,0);}const info=document.querySelector('#flightReadout');if(info)info.textContent=`飞行速度 ${this.velocity.length().toFixed(1)} · 已行进 ${this.distance.toFixed(1)} 场景单位`;
 }
}
