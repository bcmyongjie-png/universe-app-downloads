import * as T from 'three';
export const regions=[
 {id:'malaysia',name:'马来西亚',en:'Malaysia · Southeast Asia',lat:3.14,lon:101.69,desc:'从东南亚上空观察马来半岛与婆罗洲。马来西亚的两部分隔着南海相望。'},
 {id:'china',name:'中国东部',en:'Eastern China · Asia',lat:32,lon:114,desc:'从亚洲东部观察大陆与太平洋的交界。地表的绿色、山地和海岸，组成了不同于太空视角的尺度。'},
 {id:'europe',name:'欧洲',en:'Europe',lat:48,lon:12,desc:'沿地中海向北观察欧洲大陆。这里显示的是地区尺度的地表纹理，不是实时卫星地图。'},
 {id:'africa',name:'撒哈拉地区',en:'Sahara · Africa',lat:24,lon:13,desc:'从北非上空观察宽广的沙漠地表。沙漠与海洋的颜色差异，在轨道视角下十分鲜明。'},
 {id:'amazon',name:'亚马孙地区',en:'Amazon · South America',lat:-5,lon:-62,desc:'进入南美洲的赤道附近，观察亚马孙地区与周围大陆。地球曲面仍然可见。'},
 {id:'australia',name:'澳大利亚',en:'Australia · Oceania',lat:-25,lon:134,desc:'越过南半球海洋，观察澳大利亚大陆。比较内陆与沿海地表的颜色。'}
];
export function addRegions(w){
 w.regionPins=[];
 for(const r of regions){const lat=T.MathUtils.degToRad(r.lat),lon=T.MathUtils.degToRad(r.lon);const pin=new T.Mesh(new T.SphereGeometry(.025,12,8),new T.MeshBasicMaterial({color:'#99e1ff'}));pin.position.set(Math.cos(lat)*Math.cos(lon),Math.sin(lat),-Math.cos(lat)*Math.sin(lon)).multiplyScalar(6.34);pin.userData={id:'region-'+r.id};w.heroEarth.add(pin);w.meshes.push(pin);w.regionPins.push(pin);w.label(pin.userData.id,r.name+' · 进入',pin);w.hotspots.at(-1).surface=true;}
}
export function focusRegion(w,r){
 const originalYaw=w.heroEarth.rotation.y;w.tour=false;w.follow=null;w.region=r.id;w.heroEarth.rotation.y=-T.MathUtils.degToRad(r.lon)-Math.PI/2;w.heroClouds.rotation.y=w.heroEarth.rotation.y;
 w.heroEarth.updateWorldMatrix(true,true);const pin=w.regionPins.find(p=>p.userData.id==='region-'+r.id),p=pin.getWorldPosition(new T.Vector3()),center=w.heroEarth.getWorldPosition(new T.Vector3()),normal=p.clone().sub(center).normalize();
 w.heroEarth.material.uniforms.sun.value.copy(normal).add(new T.Vector3(.5,.2,0)).normalize();
 w.heroMoon.visible=false;w.orbitTrack.visible=false;w.heroClouds.material.opacity=.18;
 w.selected='region-'+r.id;w.fly={from:w.camera.position.clone(),to:center.clone().addScaledVector(normal,8.9),a:w.controls.target.clone(),b:p.clone(),start:performance.now(),earthFrom:originalYaw,earthTo:originalYaw+Math.atan2(Math.sin(w.heroEarth.rotation.y-originalYaw),Math.cos(w.heroEarth.rotation.y-originalYaw))};w.heroEarth.rotation.y=originalYaw;
}
