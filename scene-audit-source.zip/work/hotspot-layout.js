// Read all label sizes before writing positions: interleaving these operations
// forces a browser layout for every planet during camera movement.
export function layoutHotspots(items,viewportWidth,selected,viewportHeight=800){
 const widths=items.map(({el})=>el.offsetWidth||100);
 const heights=items.map(({el})=>el.offsetHeight||52),placed=[];
 items.forEach(({el,id,x,y,hidden},i)=>{
  const compact=el.classList.contains('comparisonLabel'),inset=compact?8:el.classList.contains('spectrumTemperature')?45:0;
  const left=Math.max(22+inset,Math.min(x,viewportWidth-widths[i]+10+inset));
  // Separate overview/comparison names without moving their celestial objects.
  // The lifecycle diagram retains its deliberately placed annotations.
  if(!hidden&&(el.classList.contains('galaxyName')||compact)){
   const minTop=compact&&viewportWidth<=650?296:145,maxBottom=viewportHeight-(compact?235:165);
   const gap=compact?2:6;
   const overlaps=cy=>placed.some(b=>left-14-inset<b.right+gap&&left-14-inset+widths[i]>b.left-gap&&cy-heights[i]/2<b.bottom+gap&&cy+heights[i]/2>b.top-gap);
   const step=heights[i]+8,original=y;
   for(let n=1;overlaps(y)&&n<=items.length*2;n++){
    const candidate=original+(n%2?1:-1)*Math.ceil(n/2)*step;
    if(candidate-heights[i]/2>=minTop&&candidate+heights[i]/2<=maxBottom)y=candidate;
   }
   placed.push({left:left-14-inset,right:left-14-inset+widths[i],top:y-heights[i]/2,bottom:y+heights[i]/2});
  }
  el.style.left='0px';el.style.top='0px';
  el.style.transform=`translate3d(${left}px,${y}px,0) translate(-14px,-50%)`;
  el.style.display=hidden?'none':'';
  el.classList.toggle('selected',id===selected);
 });
}
