import * as T from 'three';
import {prepareScene,releaseSceneObjects} from './scene-preparation.js';

// Prepare the next major scene without replacing the scene being explored.
// Reuse its actual objects and compiled materials when the user enters it.
export function stageSolarScene(world){
 if(world.solarWarmup)return world.solarWarmup;
 const stage=Object.create(world);
 Object.assign(stage,{root:new T.Group(),scene:new T.Scene(),mode:'solar',host:null,fly:null,scenePreparation:null,meshes:[],billboards:[],hotspots:[],planetMeshes:[],labels:[],lessonUpdate:null});
 stage.keyLight=world.keyLight.clone();
 for(const light of world.scene.children.filter(o=>o.isLight))stage.scene.add(light===world.keyLight?stage.keyLight:light.clone());
 stage.scene.add(stage.root);stage.label=(...args)=>stage.labels.push(args);
 world.solarWarmup=new Promise(resolve=>requestAnimationFrame(resolve)).then(()=>{
  stage.makeSolar();return prepareScene(stage);
 }).then(()=>{stage.ready=true;world.stagedSolar=stage;}).catch(error=>{releaseSceneObjects(stage.root,stage.scenePreparation);console.warn('Solar preparation unavailable',error);});
 return world.solarWarmup;
}

export function adoptSolarScene(world){
 const stage=world.stagedSolar;if(!stage?.ready)return false;
 world.stagedSolar=null;world.root.add(...stage.root.children);
 for(const key of ['meshes','billboards','planetMeshes','belt'])world[key]=stage[key];
 world.keyLight.intensity=0;
 for(const args of stage.labels)world.label(...args);
 world.lessonUpdate=()=>{stage.t=world.t;stage.lessonUpdate?.();};
 return true;
}
