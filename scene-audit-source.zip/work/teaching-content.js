import {glossMalay} from './malay-glosses.js';
import {glossEnglish} from './english-glosses.js';
import {learnerTopics,learnerPlanets} from './learner-content.js';
export const teaching=learnerTopics;
export const planetNotes=learnerPlanets;
export const planetStats=[
 ['mercury','水星','Utarid','Mercury',57.9,4879,.055,5.4,3.7,88,1407.6],
 ['venus','金星','Zuhrah','Venus',108.2,12104,.815,5.2,8.87,224.7,5832.5],
 ['earth','地球','Bumi','Earth',149.6,12756,1,5.5,9.8,365.25,23.93],
 ['mars','火星','Marikh','Mars',227.9,6794,.107,3.9,3.71,687,24.62],
 ['jupiter','木星','Musytari','Jupiter',778.3,142984,317.8,1.3,24.79,4332.6,9.93],
 ['saturn','土星','Zuhal','Saturn',1429,120536,95.159,.7,10.44,10759.2,10.7],
 ['uranus','天王星','Uranus','Uranus',2871,51118,14.536,1.27,8.69,30688.5,17.24],
 ['neptune','海王星','Neptun','Neptune',4504,49528,17.147,1.6,11.15,60182,16.11]
];
export const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const marked=s=>escape(s).replace(/\*\*(.+?)\*\*/g,'<mark>$1</mark>');
export const pairHTML=p=>'<p class="explainBM" lang="ms">'+glossMalay(p[0])+'</p><p class="explainEN" lang="en"><em>'+glossEnglish(p[1])+'</em></p>';
export const chapterOf=track=>track==='galaxy'?11:track==='visitors'?13:12;
export function pointsFor(d,track,index){return (d.kind==='planet'?planetNotes[d.planet]:teaching[track+'-'+index]||teaching[d.kind])||d.points||[];}

