import * as T from 'three';
import {nebula} from './body-art.js';
import {stellarLifeMap} from './stellar-life-map.js';
import {fusionScene} from './natural-scenes.js';
const smooth=(x,a,b)=>T.MathUtils.smoothstep(x,a,b),mix=T.MathUtils.lerp;
const warm=new T.Color('#ffd698'),red=new T.Color('#e75b25'),blue=new T.Color('#c8ddff');
function ejecta(w,r){
 const points=[];for(let i=0;i<1000;i++){const z=1-2*(i+.5)/1000,a=i*2.39996323,s=Math.sqrt(1-z*z),radius=r*(.75+.25*((i*37)%101)/100);points.push(Math.cos(a)*s*radius,z*radius,Math.sin(a)*s*radius)}
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(points,3));const cloud=new T.Points(geometry,new T.PointsMaterial({color:'#eea879',size:.07,transparent:true,opacity:0,depthWrite:false,blending:T.AdditiveBlending}));w.root.add(cloud);return cloud;
}
export function stellarEvolution(w,d){
 if(d.kind==='remnants'){
  return stellarLifeMap(w);
 }
 if(d.kind==='fusion')return fusionScene(w);
 if(!['birth','giant','supernova'].includes(d.kind))return null;
 const gas=nebula(w,3200,8),star=w.sphere('viz-evolving-star',1.7,'#ffd698',5);w.addGlow(star,'#ffaf65',6);
 const dust=ejecta(w,3);const core=w.sphere('viz-core',.18,'#cbdfff',5);w.addGlow(core,'#a9ceff',1.5);
 w.camera.position.set(0,4,28);w.controls.update();
 return(p,t)=>{
  const collapse=smooth(p,.4,.54),expansion=smooth(p,.52,1);
  star.visible=true;gas.visible=d.kind==='birth';dust.visible=d.kind==='supernova'&&p>.5;core.visible=d.kind==='supernova'&&p>.56;
  star.rotation.y=t*.03;gas.rotation.y=t*.025;
  if(d.kind==='birth'){const q=smooth(p,0,.9);gas.scale.setScalar(mix(1,.08,q));star.scale.setScalar(mix(.025,.75,smooth(p,.22,1)));star.material.uniforms.base.value.copy(red).lerp(warm,q)}
  if(d.kind==='giant'){const q=smooth(p,.15,.9);star.scale.setScalar(mix(.8,2.25,q));star.material.uniforms.base.value.copy(warm).lerp(red,q)}
  if(d.kind==='supernova'){star.scale.setScalar(mix(1.8,.03,collapse));star.visible=p<.57;star.material.uniforms.base.value.copy(red);dust.scale.setScalar(.2+expansion*3);dust.material.opacity=Math.sin(expansion*Math.PI)*.9;core.scale.setScalar(smooth(p,.56,.7))}
 };
}
