const {setupUpdates}=require('./updates.cjs'),{EventEmitter}=require('events'),assert=require('assert/strict'),crypto=require('crypto'),fs=require('fs'),os=require('os'),path=require('path');
(async()=>{for(const platform of ['win32','darwin']){
 const handlers={},frame={},contents={mainFrame:frame,send(){}},event={sender:contents,senderFrame:frame};let downloaded=0,installed=0;
 const bytes=Buffer.from('verified Mac test download'),manifest={edition:'teacher',version:'2.1.2',size:bytes.length,sha512:crypto.createHash('sha512').update(bytes).digest('base64'),url:'https://github.com/bcmyongjie-png/universe-app-downloads/releases/download/offline-v2.1.2/teacher.dmg'};
 const updater=new EventEmitter();updater.setFeedURL=()=>{};updater.checkForUpdates=async()=>{updater.emit('update-available',{version:'2.1.2'});return {updateInfo:{version:'2.1.2'}}};updater.downloadUpdate=async()=>{downloaded++;updater.emit('update-downloaded',{version:'2.1.2'})};updater.quitAndInstall=()=>{installed++};
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'universe-consent-'));
 const controller=setupUpdates({platform,updater,app:{getVersion:()=> '2.1.1',isPackaged:false,getPath:()=>root},ipcMain:{handle:(name,fn)=>handlers[name]=fn},main:{webContents:contents,isDestroyed:()=>false},edition:{student:false},runtime:{dialog:{showMessageBox:async()=>({response:0})},shell:{openPath:async()=>{installed++;return ''}}},fetcher:async url=>{if(url.endsWith('-mac.json'))return new Response(JSON.stringify(manifest));downloaded++;return new Response(bytes)}});
 await controller.check();assert.equal(controller.getState().phase,'available');assert.equal(downloaded,0,'Checking must never download');
 if(platform==='win32'){assert.equal(updater.autoDownload,false);assert.equal(updater.autoInstallOnAppQuit,false)}
 await handlers['universe:update-download']({sender:{},senderFrame:{}});assert.equal(downloaded,0,'Untrusted frame cannot approve');
 await handlers['universe:update-download'](event);assert.equal(downloaded,1);assert.equal(controller.getState().phase,'ready');assert.equal(installed,0,'Download completion must not install');
 if(platform==='win32'){await handlers['universe:update-install'](event);assert.equal(installed,0,'Declining installation keeps the current app')}
 console.log(platform+': consent gates PASS; no automatic download/install, explicit trusted download only');
}})().catch(e=>{console.error(e);process.exit(1)});
