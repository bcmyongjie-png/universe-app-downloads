const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
// Browser plugin not available; exercise the real offline Electron editions.
const out=path.join(os.tmpdir(),'universe-galaxy-language');fs.mkdirSync(out,{recursive:true});
const galaxies=[['milky','银河系','Bima Sakti','Milky Way'],['m31','仙女座星系','Galaksi Andromeda','Andromeda'],['m33','三角座星系','Galaksi Triangulum','Triangulum'],['lmc','大麦哲伦云','Awan Magellan Besar','Large Magellanic Cloud'],['smc','小麦哲伦云','Awan Magellan Kecil','Small Magellanic Cloud'],['m32','M32','Galaksi elips kerdil','Dwarf elliptical galaxy'],['m110','M110','Galaksi elips kerdil','Dwarf elliptical galaxy']];
(async()=>{for(const edition of process.env.EDITION?[process.env.EDITION]:['Teacher','Student']){
 const lower=edition.toLowerCase(),exe=process.env.QA_EXECUTABLE||(process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`);
 const app=await _electron.launch({executablePath:exe,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-galaxy-language-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error'&&/THREE|shader|WebGL/i.test(m.text()))errors.push(m.text());});
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  const ready=()=>page.waitForFunction(()=>document.querySelector('#space canvas')&&document.querySelector('#labels').style.visibility!=='hidden'&&!document.body.classList.contains('diving'));
  async function overview(){await page.waitForFunction(()=>document.body.dataset.level==='-1'&&!document.body.classList.contains('visual-lesson'));await ready();assert.equal(await page.locator('.galaxyName [lang=ms],.galaxyName [lang=en]').count(),0,'Overview must use Chinese only');assert.equal(await page.locator('.galaxyOverviewName').count(),7);for(const [id,zh]of galaxies)assert((await page.locator(`.galaxyOverviewName[data-object-id="cosmos-${id}"]`).textContent()).includes(zh));}
  async function inside(g){await ready();const [id,zh,bm,en]=g,label=page.locator(`.galaxyDetailName[data-object-id="cosmos-${id}"]`);await label.waitFor({state:'visible'});assert((await label.locator('[lang=ms]').textContent()).includes(bm));assert((await label.locator('[lang=en]').textContent()).includes(en));assert((await label.locator('[lang=zh-Hans]').textContent()).includes(zh));assert.deepEqual(await label.locator('[lang]').evaluateAll(els=>els.map(el=>el.lang)),['ms','en','zh-Hans']);}
  await ready();await overview();
  for(const viewport of ['desktop','mobile']){
   if(viewport==='mobile'){await app.evaluate(({BrowserWindow})=>{const w=BrowserWindow.getAllWindows()[0];w.setMinimumSize(320,400);w.setContentSize(390,844);});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));}
   await overview();await page.screenshot({path:path.join(out,lower+'-'+viewport+'-overview.png')});
   const boxes=await page.locator('.galaxyOverviewName').evaluateAll(els=>els.map(el=>{const b=el.getBoundingClientRect();return {id:el.dataset.objectId,x:b.x,y:b.y,w:b.width,h:b.height,visible:getComputedStyle(el).display!=='none'};}));const size=await page.evaluate(()=>({w:innerWidth,h:innerHeight}));for(const b of boxes)assert(b.visible&&b.x>=0&&b.x+b.w<=size.w&&b.y>=0&&b.y+b.h<=size.h,'Overview label out of view: '+b.id);for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],b=boxes[j];assert(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y),'Overview names overlap');}
   assert(boxes.find(b=>b.id==='cosmos-smc').y>boxes.find(b=>b.id==='cosmos-milky').y,'Small Magellanic Cloud label must remain near the cloud below the Milky Way');
   for(const g of galaxies){
    await page.locator(`.galaxyOverviewName[data-object-id="cosmos-${g[0]}"]`).press('Enter');await inside(g);
    if(g[0]==='m31'){
     const controls=await page.locator('#chapterTopicsToggle,#lessonTimeline').evaluateAll(els=>els.map(el=>{const b=el.getBoundingClientRect();return {x:b.x,y:b.y,w:b.width,h:b.height};}));const [a,b]=controls;assert(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y),'Topic switch must not cover playback controls');
     await page.screenshot({path:path.join(out,lower+'-'+viewport+'-andromeda.png')});
     await page.getByRole('button',{name:'探索星云',exact:true}).press('Enter');await page.waitForFunction(()=>document.querySelector('#lessonTimeline').dataset.kind==='birth');await ready();await page.keyboard.press('Escape');await inside(g);
    }
    await page.getByRole('button',{name:'返回上一层场景',exact:true}).click();await overview();
   }
  }
  // A direct type lesson must not inherit the last named galaxy.
  await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption('galaxy:1');await page.locator('#startLesson').click();await ready();assert((await page.locator('.galaxyDetailName [lang=ms]').textContent()).includes('Galaksi elips'));assert(!(await page.locator('.galaxyDetailName').textContent()).includes('M110'));
  assert.deepEqual(errors,[]);console.log(edition+' PASS: all seven Chinese overview labels, seven trilingual entries at desktop/mobile sizes, specific galaxy retained through Back, direct lessons clear stale names, no runtime errors');
 }finally{await app.close();}
}})().catch(e=>{console.error(e);process.exit(1);});
