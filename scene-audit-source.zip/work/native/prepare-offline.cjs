const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),esbuild=require('../node_modules/esbuild');
const root=path.resolve(__dirname,'..'),target=path.join(__dirname,'offline');
(async()=>{fs.mkdirSync(target,{recursive:true});for(const student of [false,true]){
 const edition=student?'student':'teacher',out=path.join(target,'web',edition);fs.mkdirSync(out,{recursive:true});
 const plugins=[{name:'offline-edition',setup(b){
  b.onLoad({filter:/app-install\.js$/},()=>({contents:'export function setupAppInstall(){}',loader:'js'}));
  if(student){
   for(const [file,contents] of [['slide-builds','export const slideBuilds={};'],['slide-videos','export const slideVideos={};'],['course-reader','export function createReader(){return {visible:false,open(){},close(){}}}'],['new-source-pages','export const newSources=[];'],['course-pages','export const pages={};']])b.onLoad({filter:new RegExp(file+'\\.js$')},()=>({contents,loader:'js'}));
   b.onLoad({filter:/topic-page-map\.json$/},()=>({contents:'[]',loader:'json'}));
  }
 }}];
 const result=await esbuild.build({entryPoints:[path.join(root,'app.js')],outdir:path.join(out,'assets'),bundle:true,minify:true,format:'iife',entryNames:'offline-app',assetNames:'[name]-[hash]',publicPath:'/assets',metafile:true,loader:{'.html':'file','.mp4':'file','.jpg':'file','.png':'file','.webp':'file'},define:{__STUDENT__:String(student)},plugins});
 const title='宇宙漫游 · '+(student?'学生版':'教师版')+' · 离线版';
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace(/<title>.*?<\/title>/,'<title>'+title+'</title>').replace('__CSS__',fs.readFileSync(path.join(root,'style.css'),'utf8')).replace('<script>__JS__</script>','<script src="/assets/offline-app.js"></script>');
 fs.writeFileSync(path.join(out,'index.html'),html);fs.writeFileSync(path.join(target,edition+'-index.html'),html);fs.copyFileSync(path.join(out,'assets/offline-app.js'),path.join(target,edition+'-app.js'));
 const base=student?'https://universe-explorer-f2-student.vercel.app/':'https://universe-explorer-f2-chi.vercel.app/';
 const files=Object.keys(result.metafile.outputs).filter(p=>!p.endsWith('offline-app.js')).map(p=>{const relative=path.relative(out,path.resolve(p)).replaceAll('\\','/'),buffer=fs.readFileSync(p);return {path:relative,url:base+relative,bytes:buffer.length,sha256:crypto.createHash('sha256').update(buffer).digest('hex')};});
 fs.writeFileSync(path.join(target,edition+'-assets.json'),JSON.stringify(files));
 console.log(JSON.stringify({edition,assets:files.length,bytes:files.reduce((n,f)=>n+f.bytes,0),videos:files.filter(f=>f.path.endsWith('.mp4')).length}));
}
})().catch(e=>{console.error(e);process.exit(1)});
