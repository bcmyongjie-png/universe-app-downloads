// Chapter checkboxes filter the classroom; only the explicit lesson button navigates.
const {_electron}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
(async()=>{for(const edition of process.env.EDITION?[process.env.EDITION]:['Teacher','Student']){
 const lower=edition.toLowerCase();
 const exe=process.env.QA_EXECUTABLE||(process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`);
 const app=await _electron.launch({executablePath:exe,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-selection-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  const ready=()=>page.waitForFunction(()=>document.querySelector('#space canvas')&&document.querySelector('#labels')?.style.visibility!=='hidden'&&!document.body.classList.contains('diving'));
  async function select(chapters){
   await page.locator('#teacherToggle').click();
   for(const ch of chapters)await page.locator(`.chapterCheck input[value="${ch}"]`).check();
   for(const ch of [11,12,13].filter(n=>!chapters.includes(n)))await page.locator(`.chapterCheck input[value="${ch}"]`).uncheck();
   await page.locator('#teacherPanel header button').click();await ready();if(await page.locator('#chapterTopics').isVisible())await page.locator('.chapterTopicsHeader button').click();
  }
  async function boundary(chapters){
   await ready();const location=await page.locator('#location').textContent();
   const chapter=/^C(11|12|13)\b/.exec(location)?.[1];
   assert(chapter?chapters.includes(Number(chapter)):/本星系群|银河系/.test(location)?chapters.includes(11):/太阳系|地球/.test(location),location);
   for(const selector of ['#sceneTopics a','#microDetail [data-related]','#lessonSelect option']){
    const keys=await page.locator(selector).evaluateAll(els=>els.map(el=>el.dataset.topic||el.dataset.related||el.value));
    assert(keys.every(k=>chapters.includes(k.startsWith('galaxy:')?11:k.startsWith('visitors:')?13:12)),selector+' leaks a chapter');
   }
  }
  await ready();const overview=await page.locator('#location').textContent();
  await select([11]);assert.equal(await page.locator('#location').textContent(),overview,'Unchecking unrelated chapters must keep the overview, not start the first lesson');
  await page.locator('[data-object-id="cosmos-milky"]').click();
  await page.waitForFunction(()=>document.querySelector('#location').textContent.includes('Bima Sakti'));await ready();
  const milky=await page.locator('#location').textContent();
  assert.equal(await page.getByRole('button',{name:'探索太阳系',exact:true}).count(),1,'Shared Sun context remains accessible in C11');
  await select([11,12,13]);assert.equal(await page.locator('#location').textContent(),milky);
  assert.equal(await page.getByRole('button',{name:'探索太阳系',exact:true}).count(),1,'Adding C12 must restore its scene entrance');
  await select([11]);assert.equal(await page.locator('#location').textContent(),milky);
  assert.equal(await page.getByRole('button',{name:'探索太阳系',exact:true}).count(),1,'Shared Sun context remains accessible in C11');
  await select([11,12,13]);await page.getByRole('button',{name:'探索恒星的一生',exact:true}).press('Enter');await ready();
  await page.locator('.motionSeek').evaluate(el=>{el.value='520';el.dispatchEvent(new Event('input',{bubbles:true}));});
  await page.locator('.motionSpeed').selectOption('2');
  const title=(await page.locator('#location').textContent()).split(' · ').slice(0,2).join(' · ');
  const label=await page.locator('.lifeMapLabel').first().elementHandle();
  for(const chapters of [[11],[11,12],[11,13],[11,12,13]]){
   await select(chapters);await boundary(chapters);
   assert.equal((await page.locator('#location').textContent()).split(' · ').slice(0,2).join(' · '),title);
   assert.equal(await page.locator('.motionSeek').inputValue(),'520','Selection must preserve animation progress');
   assert.equal(await page.locator('.motionPlay').getAttribute('aria-pressed'),'false');
   assert.equal(await page.locator('.motionSpeed').inputValue(),'2');
   assert(await label.evaluate(el=>el.isConnected),'The existing model and labels must not be rebuilt');
  }
  await page.keyboard.press('Escape');await ready();assert.equal(await page.locator('#location').textContent(),milky,'Allowed Back history is retained');
  for(const chapters of [[12],[13],[12,13],[11,12,13],[11,13],[11,12],[11]]){
   await select(chapters);await boundary(chapters);
   for(let i=0;i<3;i++){await page.keyboard.press('Escape');await boundary(chapters);}
   await page.reload();await boundary(chapters);
  }
  assert.deepEqual(errors,[]);
  console.log(edition+' PASS: checkboxes keep allowed overview/model/progress/speed/history; restore entrances; all 7 chapter combinations, Back and reload remain restricted');
 }finally{await app.close();}
}})().catch(e=>{console.error(e);process.exit(1);});
