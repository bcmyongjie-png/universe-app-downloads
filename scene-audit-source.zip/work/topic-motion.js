import * as T from 'three';
// Scanning comparisons animates the explanation, never the physical size or temperature.
export function completeTopicMotion(w,d,update){
 const compare={spectrum:'viz-color',starsize:'viz-size',sizes:'viz-',composition:'viz-'}[d.kind];
 if(compare){
  const items=w.meshes.filter(m=>m.userData.id.startsWith(compare)&&(d.kind!=='sizes'||!m.userData.id.includes('sun')));
  const marker=new T.Mesh(new T.TorusGeometry(1,.014,6,96),new T.MeshBasicMaterial({color:'#9bdef5',transparent:true,opacity:.65,depthWrite:false}));w.root.add(marker);
  const positions=new Float32Array(6),geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(positions,3));const measure=new T.Line(geo,new T.LineBasicMaterial({color:'#bce4ed',transparent:true,opacity:.55}));w.root.add(measure);
  const original=update;
  update=(p,t)=>{original(p,t);const chosen=items[Math.min(items.length-1,Math.floor(p*items.length))];if(!chosen)return;const r=chosen.userData.r||1;marker.position.copy(chosen.position);marker.scale.setScalar(r*1.14+.18);marker.lookAt(w.camera.position);positions.set([chosen.position.x-r,chosen.position.y-r-.4,chosen.position.z,chosen.position.x+r,chosen.position.y-r-.4,chosen.position.z]);geo.attributes.position.needsUpdate=true;geo.computeBoundingSphere();};
 }
 if(d.kind==='belt'){
  const original=update;update=(p,t)=>{original(p,t);if(w.belt)w.belt.rotation.y=p*Math.PI*.7};
 }
 const motion=update;
 return(p,t)=>{
  motion(p,t);
  // Surface shaders and asteroid tumbles obey seeking/pause/replay too.
  w.root.traverse(o=>{if(o.material?.uniforms?.time)o.material.uniforms.time.value=t;if(o.userData.tumble){o.rotation.x=t*.035;o.rotation.y=t*.13}});
 };
}
