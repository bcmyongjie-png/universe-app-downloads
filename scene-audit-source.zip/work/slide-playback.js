import {mountPptTools} from './ppt-tools.js';
import {showProjectorSetup} from './projector-setup.js';
import {updateAudience} from './audience-bridge.js';
// Original PowerPoint click groups are exported as successive visual states.
import {slideBuilds} from './slide-builds.js';
import {slideVideos} from './slide-videos.js';
// Retain decoded upcoming frames, avoiding network/decode work on each click.
const decodedFrames=new Map();
function readyFrame(url){if(decodedFrames.has(url))return decodedFrames.get(url);const image=new Image();image.decoding='async';image.src=url;const task=image.decode().then(()=>image).catch(error=>{decodedFrames.delete(url);throw error;});decodedFrames.set(url,task);if(decodedFrames.size>18)decodedFrames.delete(decodedFrames.keys().next().value);return task;}
export function mountSlidePlayback(host){
 const stage=host.querySelector('.examSlideStage'),img=stage.querySelector('img');
 img.classList.add('slideCurrentFrame');
 const previous=document.createElement('img');previous.className='slidePreviousFrame';previous.alt='';previous.setAttribute('aria-hidden','true');stage.prepend(previous);
 stage.tabIndex=0;stage.setAttribute('role','button');stage.setAttribute('aria-label','点击显示下一项幻灯片内容');
 const controls=host.querySelector('.slideMotionControls');
 controls.innerHTML='<button type="button" data-build="back" aria-label="上一项或上一张" title="上一项或上一张">‹</button><button type="button" data-build="next" aria-label="下一项或下一张" title="下一项或下一张">›</button><span class="slideBuildStatus" role="status"></span><button type="button" data-build="audience" aria-label="打开学生投影窗口" title="学生投影窗口">▣</button><button type="button" data-build="full" aria-label="全屏播放幻灯片" title="全屏">⛶</button>';

 let frames=[],step=0,serial=0,busy=false,title='',failedTarget=null,media=null,video=null,playButton=null;
 const positionVideo=()=>{if(!video||!media)return;const r=img.getBoundingClientRect(),s=stage.getBoundingClientRect(),[x,y,w,h]=media.bounds;for(const el of [video,playButton])if(el)Object.assign(el.style,{left:(r.left-s.left+x*r.width)+'px',top:(r.top-s.top+y*r.height)+'px',width:w*r.width+'px',height:h*r.height+'px'});};
 const observer=new ResizeObserver(positionVideo);observer.observe(stage);observer.observe(img);
 const publish=()=>updateAudience({src:img.src,title,next:frames.slice(step+1,step+4).map(u=>new URL(u,location.href).href),video:video?{src:video.src,bounds:media.bounds,time:video.currentTime,paused:video.paused}:null},{advance,back:retreat});
 function clearVideo(){if(video){video.pause();video.removeAttribute('src');video.load();video.remove();}playButton?.remove();video=null;playButton=null;}
 function mountVideo(){if(!media||video)return;video=document.createElement('video');video.className='slideEmbeddedVideo';video.controls=true;video.playsInline=true;video.preload='metadata';video.src=media.src;video.poster=media.poster;video.setAttribute('aria-label','课件原视频');stage.append(video);playButton=document.createElement('button');playButton.className='slideVideoStart';playButton.type='button';playButton.textContent='▶';playButton.setAttribute('aria-label','播放课件原视频');stage.append(playButton);
  playButton.onclick=e=>{e.stopPropagation();video.play().catch(()=>{status.textContent='请再点击播放';});};video.onclick=e=>e.stopPropagation();video.onkeydown=e=>e.stopPropagation();
  let lastSync=0;video.addEventListener('timeupdate',()=>{if(video&&!video.paused&&performance.now()-lastSync>2000){lastSync=performance.now();publish();}});
  video.addEventListener('play',()=>{playButton.hidden=true;publish();});video.addEventListener('pause',publish);video.addEventListener('seeked',publish);video.addEventListener('ended',publish);video.addEventListener('error',()=>{status.textContent='视频加载失败，请重新打开这一页';});positionVideo();
 }
 const status=controls.querySelector('.slideBuildStatus'),back=controls.querySelector('[data-build="back"]'),next=controls.querySelector('[data-build="next"]');
 const skipButtons=[-10,10].map(seconds=>{const button=document.createElement('button');button.type='button';button.hidden=true;button.className='pptMediaSkip';button.textContent=seconds<0?'↶10':'10↷';button.setAttribute('aria-label',seconds<0?'视频后退 10 秒':'视频前进 10 秒');button.onclick=()=>{if(video&&Number.isFinite(video.duration))video.currentTime=Math.max(0,Math.min(video.duration,video.currentTime+seconds));};status.before(button);return button;});
 const canPrevious=()=>{const b=host.querySelector('#previousExamSlide');return b&&!b.disabled;};
 const canNext=()=>{const b=host.querySelector('#nextExamSlide');return b&&!b.disabled;};
 function refresh(){skipButtons.forEach(b=>{b.hidden=!media;});back.disabled=busy||(step===0&&!canPrevious());next.disabled=busy||(failedTarget===null&&step===frames.length-1&&!canNext());const page=host.querySelector('#examSlideCount')?.textContent||'';status.textContent=busy?'加载中…':page||(frames.length>1?(step+1)+' / '+frames.length:'');stage.setAttribute('role',media?'group':'button');stage.setAttribute('aria-disabled','false');}

 async function show(target,animate=true){
  const token=++serial;busy=true;refresh();const url=frames[target];
  try{await readyFrame(url);}catch{if(token===serial){busy=false;failedTarget=target;refresh();status.textContent='加载失败，点击右箭头重试';}return;}
  if(token!==serial)return;
  if(img.getAttribute('src')){previous.src=img.src;previous.hidden=false;}else previous.hidden=true;img.getAnimations().forEach(a=>a.cancel());img.src=url;img.alt=title+' · 动画 '+target;step=target;busy=false;failedTarget=null;
  if(animate&&previous.getAttribute('src')&&!matchMedia('(prefers-reduced-motion: reduce)').matches){img.animate([{opacity:0},{opacity:1}],{duration:180,easing:'linear'});}
  mountVideo();positionVideo();refresh();publish();ppt.changed();frames.slice(step+1,step+4).forEach(u=>{void readyFrame(u).catch(()=>{});});
 }
 const advance=()=>{if(busy)return;if(failedTarget!==null){show(failedTarget,false);return;}if(step<frames.length-1)show(step+1);else if(canNext())host.querySelector('#nextExamSlide').click();};
 const retreat=()=>{if(busy)return;if(step>0)show(step-1);else if(canPrevious())host.querySelector('#previousExamSlide').click();};
 stage.onclick=advance;stage.setAttribute('aria-label','点击播放下一项或下一张幻灯片');
 host.addEventListener('keydown',e=>{if(host.classList.contains('showSlideOverview')||e.target.closest('input,select,video,.pptToolMenu')||(e.target.closest('button')&&[' ','Enter'].includes(e.key)))return;if([' ','Enter','ArrowRight','PageDown'].includes(e.key)){e.preventDefault();advance();}else if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();retreat();}});
 back.onclick=retreat;next.onclick=advance;
 controls.querySelector('[data-build="audience"]').onclick=showProjectorSetup;
 const full=controls.querySelector('[data-build="full"]');let presentation=null,marker=null;
 const collapse=()=>{if(!presentation)return;marker.replaceWith(host);host.classList.remove('slidePresentation');presentation.close();presentation.remove();presentation=null;full.textContent='⛶';full.setAttribute('aria-label','全屏播放幻灯片');full.focus();};
 full.onclick=()=>{if(presentation){collapse();return;}if(window.universeDesktop?.openProjector){showProjectorSetup();return;}marker=document.createComment('slide position');host.before(marker);presentation=document.createElement('dialog');presentation.className='slidePresentationDialog';presentation.setAttribute('aria-label','全屏幻灯片');document.body.append(presentation);presentation.append(host);host.classList.add('slidePresentation');full.textContent='⤢';full.setAttribute('aria-label','退出幻灯片全屏');presentation.addEventListener('cancel',e=>{e.preventDefault();collapse();});presentation.showModal();stage.focus();};

 const ppt=mountPptTools(host);
 return {load(page,label){serial++;ppt.load(page.doc+':'+page.number);clearVideo();media=slideVideos[page.doc+':'+page.number]||null;frames=slideBuilds[page.doc+':'+page.number]||[page.image];step=0;title=label;failedTarget=null;previous.hidden=true;show(0,false);frames.slice(1,4).forEach(u=>{void readyFrame(u).catch(()=>{});});}};
}

