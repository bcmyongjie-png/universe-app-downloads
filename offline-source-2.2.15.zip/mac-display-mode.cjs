// CoreGraphics is accessed only by the bundled native helper, never AppleScript,
// sudo, UI automation, or changes to system/security preferences.
const {execFile}=require('node:child_process');
function valid(rows){
 if(!Array.isArray(rows)||!rows.length||rows.length>32||new Set(rows.map(r=>r.id)).size!==rows.length||rows.some(r=>
  !Number.isInteger(r.id)||typeof r.uuid!=='string'||!r.uuid||typeof r.builtin!=='boolean'||typeof r.active!=='boolean'||typeof r.hardwareMirror!=='boolean'||typeof r.fixedMirror!=='boolean'||
  !Number.isInteger(r.mirror)||!Number.isInteger(r.mode)||![r.x,r.y,r.width,r.height,r.rotation].every(Number.isFinite)||r.width<=0||r.height<=0))throw Error('Invalid Mac display state');
 return rows.slice().sort((a,b)=>a.id-b.id);
}
function signature(rows){return JSON.stringify(valid(rows).map(r=>[r.id,r.uuid,r.builtin,r.active,r.mirror,r.hardwareMirror,r.fixedMirror,r.x,r.y,r.width,r.height,r.mode,r.rotation]));}
const separate=(a,b)=>a.x>=b.x+b.width||b.x>=a.x+a.width||a.y>=b.y+b.height||b.y>=a.y+a.height;
function extended(rows){const home=rows.find(r=>r.builtin&&r.active&&!r.mirror);return home&&rows.some(r=>r.id!==home.id&&r.active&&!r.mirror&&separate(home,r));}
function createMacDisplaySession({helperPath}){
 let original=null,applied=null;
 const run=(...args)=>new Promise((resolve,reject)=>execFile(helperPath,args,{timeout:15000,maxBuffer:128*1024},(error,stdout)=>{
  if(error)return reject(error);
  try{const response=JSON.parse(stdout);if(!response.ok)throw Error(response.error||'Mac display change failed');resolve(valid(response.displays));}catch(e){reject(e);}
 }));
 const clear=()=>{original=null;applied=null;};
 return {
  async extend(){
   const before=await run('snapshot');if(extended(before))return;
   const home=before.find(r=>r.builtin),other=before.find(r=>!r.builtin);
   // Only automatically change a known two-display MacBook mirror pair. Never
   // enable/disable hardware, change an unknown multi-monitor setup or use a
   // closed laptop as the control screen.
   if(before.length!==2||!home||!other||(!home.active&&!home.mirror)||before.some(r=>r.fixedMirror)||
    !(home.mirror===other.id||other.mirror===home.id))throw Error('A connected MacBook mirror pair is required');
   const target=before.map(r=>({...r,active:true,mirror:0,hardwareMirror:false,x:r.id===home.id?0:home.width,y:0}));
   original=before;applied=null;
   applied=await run('apply',JSON.stringify(before),JSON.stringify(target));
   if(!extended(applied))throw Error('Mac did not provide two independent active screens');
  },
  async capture(){
   if(!applied)return;
   // Do not expand ownership to include a manual adjustment during startup.
   if(signature(await run('snapshot'))!==signature(applied))clear();
  },
  async restore(){
   if(!original||!applied){clear();return;}
   const current=await run('snapshot');
   if(signature(current)!==signature(applied)){clear();return;}
   const restored=await run('apply',JSON.stringify(current),JSON.stringify(original));
   if(signature(restored)!==signature(original))throw Error('Mac did not restore the original display layout');
   clear();
  }
 };
}
module.exports={createMacDisplaySession};
