// Short, aligned Malay / English / Simplified Chinese points for lower-secondary learners.
// Keep exam terms, but introduce one idea at a time. Source slides remain original material.
export const learnerTopics={
 'galaxy-0':[
  ['**Galaksi** ialah kumpulan sangat besar yang mengandungi bintang, gas dan debu. Graviti menarik semuanya bersama.','A **galaxy** is a huge group of stars, gas and dust. Gravity holds them together.','**星系**里有很多恒星、气体和尘埃。引力把它们拉在一起。'],
  ['Kita tinggal dalam **Bima Sakti**. Sistem Suria ialah sebahagian kecil daripadanya.','We live in the **Milky Way**. Our Solar System is a small part of it.','我们住在**银河系**里。太阳系只是其中的一小部分。'],
  ['Bima Sakti ialah **galaksi berpilin berpalang**. Lihat jalur di tengah dan lengan yang melengkung.','The Milky Way is a **barred spiral galaxy**. Look for the bar in the centre and the curved arms.','银河系是**棒旋星系**。看一看中间的长条和弯弯的旋臂。']],
 'galaxy-1':[['**Galaksi elips** berbentuk bulat atau bujur. Ia tiada lengan berpilin. Contoh: M87.','An **elliptical galaxy** is round or oval. It has no spiral arms. M87 is an example.','**椭圆星系**像圆形或椭圆形，没有旋臂。例如 M87。']],
 'galaxy-2':[['**Galaksi tidak seragam** tiada bentuk yang tetap. Awan Magellan ialah contohnya.','An **irregular galaxy** has no regular shape. The Magellanic Clouds are examples.','**不规则星系**没有固定形状。大、小麦哲伦云就是例子。']],
 birth:[
  ['**Nebula** ialah awan besar gas dan debu di angkasa. Bintang boleh terbentuk di dalamnya.','A **nebula** is a large cloud of gas and dust in space. Stars can form inside it.','**星云**是太空中的一大团气体和尘埃。恒星可以在里面形成。'],
  ['**Graviti** menarik gas bersama. Gas menjadi semakin padat dan panas.','**Gravity** pulls the gas together. The gas becomes more tightly packed and hotter.','**引力**把气体拉到一起。气体被压得更紧，也变得更热。'],
  ['Apabila pusat cukup panas, **pelakuran nuklear** bermula. Bintang mula menghasilkan tenaga.','When the centre is hot enough, **nuclear fusion** begins. The star starts producing energy.','中心够热时，**核聚变**就会开始。恒星开始产生能量。']],
 fusion:[
  ['Di pusat bintang, **hidrogen bergabung menjadi helium**. Proses ini dipanggil pelakuran nuklear.','Inside a star, **hydrogen joins to form helium**. This process is called nuclear fusion.','恒星中心的**氢结合成氦**。这个过程叫核聚变。'],
  ['Proses ini membebaskan **cahaya dan haba**. Itulah cara Matahari menghasilkan tenaga.','This process releases **light and heat**. This is how the Sun makes energy.','这个过程会释放**光和热**。太阳就是这样产生能量的。'],
  ['Matahari ialah **bintang** yang bercahaya sendiri. Planet memantulkan cahaya Matahari.','The Sun is a **star** that makes its own light. Planets reflect sunlight.','太阳是会自己发光的**恒星**。行星反射太阳光。']],
 giant:[
  ['Bintang seperti Matahari berubah apabila **hidrogen di pusat hampir habis**.','A star like the Sun changes when **hydrogen in its centre runs low**.','像太阳这样的恒星，**中心的氢快用完时**就会发生变化。'],
  ['Lapisan luar mengembang dan menjadi lebih sejuk. Bintang menjadi **raksasa merah**.','The outer layers grow larger and become cooler. The star becomes a **red giant**.','外层变大，也变冷。恒星成为**红巨星**。']],
 supernova:[
  ['Bintang yang **berjisim besar** boleh menjadi superraksasa merah. Jisim ialah jumlah bahan dalam sesuatu objek.','A star with **a lot of mass** can become a red supergiant. Mass tells us how much matter an object contains.','**质量很大**的恒星可能成为红超巨星。质量表示物体含有多少物质。'],
  ['Pusat bintang boleh runtuh ke dalam lalu mencetuskan **supernova**. Letupan ini menyebarkan bahan ke angkasa.','The centre can collapse and trigger a **supernova**. This explosion throws material into space.','中心可能向内塌下，引起**超新星爆炸**。爆炸把物质抛向太空。']],
 remnants:[
  ['**Nebula** ialah awan gas dan debu. Gas berkumpul lalu membentuk bintang.','A **nebula** is a cloud of gas and dust. The gas gathers to form a star.','**星云**里的气体聚在一起，可以形成恒星。'],
  ['Bintang seperti Matahari: **raksasa merah → gas luar terlepas → kerdil putih**.','A star like the Sun: **red giant → outer gas escapes → white dwarf**.','像太阳的恒星：**红巨星 → 外层气体散开 → 白矮星**。'],
  ['Bintang berjisim besar: **superraksasa → supernova → bintang neutron ATAU lohong hitam**. Jisim yang tinggal menentukan hasilnya.','A massive star: **supergiant → supernova → neutron star OR black hole**. The mass left behind determines the outcome.','大质量恒星：**超巨星 → 超新星爆炸 → 中子星或黑洞**。结果要看剩下多少质量。']],
 spectrum:[
  ['Warna membantu kita mengenali **suhu permukaan** bintang. Bintang merah lebih sejuk daripada bintang biru.','Colour helps us compare a star’s **surface temperature**. Red stars are cooler than blue stars.','颜色能帮助我们比较恒星的**表面温度**。红色恒星比蓝色恒星冷。'],
  ['Dari lebih sejuk ke lebih panas: **merah → jingga → kuning → putih → biru**. Ini susunan ringkas.','From cooler to hotter: **red → orange → yellow → white → blue**. This is a simple guide.','从较冷到较热，先记：**红 → 橙 → 黄 → 白 → 蓝**。这是简化的顺序。']],
 brightness:[
  ['Bandingkan **dua bintang yang sama**. Bintang yang lebih dekat kelihatan lebih terang.','Compare **two identical stars**. The nearer star looks brighter.','比较**两颗一样的恒星**。较近的那颗看起来更亮。'],
  ['Kecerahan yang kita lihat bergantung pada **jarak** dan jumlah cahaya bintang.','How bright a star looks depends on its **distance** and how much light it gives out.','我们看到恒星有多亮，要看它的**距离**和它发出多少光。'],
  ['Matahari ialah **bintang paling dekat** dengan Bumi. Cahayanya sampai dalam kira-kira 8 minit 20 saat.','The Sun is the **nearest star** to Earth. Its light takes about 8 minutes 20 seconds to reach us.','太阳是**离地球最近的恒星**。太阳光约用 8 分 20 秒到达地球。']],
 spaceflight:[
  ['**Sheikh Muszaphar Shukor** ialah rakyat Malaysia pertama ke angkasa. Beliau berlepas pada **10 Oktober 2007**.','**Sheikh Muszaphar Shukor** was the first Malaysian in space. He launched on **10 October 2007**.','**谢赫·穆扎法尔·舒库尔**是第一位进入太空的马来西亚人。他在 **2007 年 10 月 10 日**出发。'],
  ['Roket membawa kapal angkasa meninggalkan permukaan Bumi. Perjalanan ke orbit Bumi jauh lebih dekat daripada perjalanan ke bintang lain.','A rocket carries a spacecraft away from Earth’s surface. Earth orbit is much nearer than other stars.','火箭把飞船送离地面。到地球轨道，比到其他恒星近得多。']],
 sunlife:[
  ['Bayangkan Bumi tidak mendapat cahaya Matahari. Bumi akan **semakin sejuk**.','Imagine Earth gets no sunlight. Earth would **gradually become colder**.','想一想：如果没有阳光，地球会**慢慢变冷**。'],
  ['Tumbuhan tidak dapat melakukan **fotosintesis** tanpa cahaya. Rantaian makanan juga terjejas. Ini situasi andaian.','Plants cannot carry out **photosynthesis** without light. Food chains are affected too. This is an imagined situation.','没有光，植物就不能进行**光合作用**，食物链也会受影响。这是假设的情况。']],
 starsize:[
  ['Bintang mempunyai **saiz** yang berbeza. Bandingkan bintang kerdil, raksasa dan superraksasa.','Stars have different **sizes**. Compare dwarf stars, giants and supergiants.','恒星的**大小**不同。比较矮星、巨星和超巨星。'],
  ['Bintang yang lebih besar **tidak semestinya lebih panas**. Saiz dan suhu ialah dua ciri berbeza.','A bigger star is **not always hotter**. Size and temperature are different features.','恒星较大，**不一定更热**。大小和温度是两回事。']],
 sizes:[
  ['Dari Matahari: **Utarid → Zuhrah → Bumi → Marikh → Musytari → Zuhal → Uranus → Neptun**.','From the Sun: **Mercury → Venus → Earth → Mars → Jupiter → Saturn → Uranus → Neptune**.','从太阳往外：**水星 → 金星 → 地球 → 火星 → 木星 → 土星 → 天王星 → 海王星**。'],
  ['**Musytari** paling besar. **Utarid** paling kecil. Saiz planet dalam perbandingan ini menggunakan skala yang sama.','**Jupiter** is the largest. **Mercury** is the smallest. This size comparison uses the same scale for each planet.','**木星**最大，**水星**最小。这个比较画面的行星大小使用同一比例。'],
  ['Empat planet paling dekat dengan Matahari ialah **planet berbatu**. Empat planet di luar jauh lebih besar.','The four planets nearest the Sun are **rocky planets**. The four outer planets are much larger.','靠近太阳的四颗是**岩石行星**。外面的四颗行星大得多。']],
 au:[
  ['**1 AU** ialah jarak purata Bumi ke Matahari. Nilainya kira-kira **150 juta km**.','**1 AU** is the average Earth–Sun distance. It is about **150 million km**.','**1 AU（天文单位）**是地球到太阳的平均距离，约 **1.5 亿千米**。'],
  ['Ingat: **1 AU ≈ 1.5 × 10⁸ km**. Untuk menukar AU kepada km, darab dengan nilai ini.','Remember: **1 AU ≈ 1.5 × 10⁸ km**. To change AU to km, multiply by this value.','记住：**1 AU ≈ 1.5 × 10⁸ 千米**。把 AU 换成千米，就乘这个数。'],
  ['Contoh: **3 AU ≈ 450 juta km**. Untuk menukar km kepada AU, bahagi dengan 150 juta.','Example: **3 AU ≈ 450 million km**. To change km to AU, divide by 150 million.','例如：**3 AU ≈ 4.5 亿千米**。把千米换成 AU，就除以 1.5 亿。']],
 lightyear:[
  ['**Tahun cahaya** mengukur jarak, bukan masa. Satu tahun cahaya ialah jarak yang dilalui cahaya dalam setahun.','A **light-year** measures distance, not time. It is the distance light travels in one year.','**光年**表示距离，不是时间。1 光年就是光走一年的距离。'],
  ['**1 tahun cahaya ≈ 9.5 × 10¹² km**. Unit ini digunakan untuk jarak yang sangat jauh.','**1 light-year ≈ 9.5 × 10¹² km**. We use it for very large distances.','**1 光年 ≈ 9.5 × 10¹² 千米**。距离很远时，用光年来表示比较方便。']],
 orbit:[
  ['**Peredaran** ialah gerakan planet mengelilingi Matahari. **Orbit** ialah laluannya.','**Revolution** means a planet travels around the Sun. Its path is its **orbit**.','**公转**是行星绕太阳运行。运行的路线叫**轨道**。'],
  ['Planet yang lebih jauh mengambil **masa lebih lama** untuk satu orbit. Bumi mengambil kira-kira 365 hari.','A farther planet takes **longer** to orbit the Sun. Earth takes about 365 days.','离太阳较远的行星，绕一圈通常**要更久**。地球约要 365 天。']],
 rotation:[
  ['**Putaran** bermaksud planet berpusing pada paksinya sendiri. Ini berbeza daripada mengelilingi Matahari.','**Rotation** means a planet spins on its own axis. This differs from travelling around the Sun.','**自转**是行星绕自己的轴转，和绕太阳公转不同。'],
  ['Kebanyakan planet berputar dari **barat ke timur**. Zuhrah berputar ke arah bertentangan.','Most planets rotate from **west to east**. Venus turns in the opposite direction.','多数行星从**西向东**自转。金星的方向相反。'],
  ['Paksi Uranus sangat condong. Ia kelihatan seperti **berpusing sambil berbaring**.','Uranus has a very tilted axis. It looks as if it **spins on its side**.','天王星的轴很斜，看起来像**侧躺着转**。']],
 greenhouse:[
  ['Atmosfera Zuhrah sangat tebal dan banyak mengandungi **karbon dioksida**. Haba sukar keluar ke angkasa.','Venus has a thick atmosphere with lots of **carbon dioxide**. Heat has difficulty escaping to space.','金星的大气层很厚，含有大量**二氧化碳**，热量不容易散到太空。'],
  ['Ini ialah **kesan rumah hijau**. Zuhrah lebih panas daripada Utarid walaupun Utarid lebih dekat dengan Matahari.','This is the **greenhouse effect**. Venus is hotter than Mercury, even though Mercury is nearer the Sun.','这叫**温室效应**。水星虽然更靠近太阳，金星却更热。']],
 gravity:[
  ['**Graviti** menarik objek ke arah planet. Sebab itu bola yang dilepaskan jatuh ke tanah.','**Gravity** pulls objects towards a planet. That is why a dropped ball falls to the ground.','**引力**把物体拉向行星，所以放开球后，球会掉向地面。'],
  ['Lepaskan objek dari **ketinggian yang sama**. Tanpa rintangan udara, objek jatuh lebih cepat apabila graviti lebih kuat.','Drop objects from the **same height**. Without air resistance, stronger gravity makes them fall faster.','从**相同高度**放开物体。不考虑空气阻力时，引力越强，物体掉得越快。'],
  ['**Jisim** ialah jumlah bahan dalam objek. **Berat** ialah daya tarikan graviti pada objek itu.','**Mass** tells us how much matter an object contains. **Weight** is the force of gravity on it.','**质量**表示含有多少物质。**重量**是物体受到的引力大小。']],
 moons:[
  ['**Satelit semula jadi** mengelilingi planet. Bulan ialah satelit semula jadi Bumi.','A **natural satellite** travels around a planet. The Moon is Earth’s natural satellite.','**天然卫星**绕行星运行。月球是地球的天然卫星。'],
  ['Bulan **berputar sendiri** dan **mengelilingi Bumi**. Kedua-duanya mengambil kira-kira 27.3 hari.','The Moon **spins** and **orbits Earth**. Each takes about 27.3 days.','月球会**自转**，也会**绕地球公转**。两者都约用 27.3 天。']],
 daynight:[
  ['Bahagian Bumi yang menghadap Matahari mengalami **siang**. Bahagian yang membelakangi Matahari mengalami **malam**.','The side of Earth facing the Sun has **day**. The side facing away has **night**.','地球朝向太阳的一面是**白天**，背向太阳的一面是**夜晚**。'],
  ['Bumi terus **berputar**. Sebab itu siang dan malam silih berganti.','Earth keeps **rotating**. That is why day and night take turns.','地球不断**自转**，所以我们会经历白天和夜晚。']],
 habitat:[
  ['Bumi mempunyai **air cecair** dan suhu yang sesuai. Keadaan ini membantu hidupan hidup.','Earth has **liquid water** and suitable temperatures. These conditions help life survive.','地球有**液态水**和合适的温度，适合生命生存。'],
  ['**Atmosfera** ialah lapisan gas di sekeliling Bumi. Ia membantu melindungi hidupan.','The **atmosphere** is the layer of gas around Earth. It helps protect life.','**大气层**是围着地球的一层气体，能帮助保护生命。'],
  ['Manusia dan banyak haiwan memerlukan **oksigen** untuk bernafas. Cahaya Matahari pula membantu tumbuhan membuat makanan.','Humans and many animals need **oxygen** to breathe. Sunlight helps plants make food.','人和许多动物需要**氧气**来呼吸。阳光帮助植物制造食物。']],
 climate:[
  ['Jika Bumi berputar lebih perlahan, **siang dan malam menjadi lebih panjang**.','If Earth spins more slowly, **day and night last longer**.','如果地球转慢了，**白天和夜晚都会更长**。'],
  ['Siang yang panjang memberi lebih masa untuk menjadi panas. Malam yang panjang memberi lebih masa untuk menjadi sejuk.','A longer day gives more time for heating. A longer night gives more time for cooling.','白天长，受热时间就更长。夜晚长，变冷的时间也更长。'],
  ['Bulan membantu menghasilkan **pasang surut**. Tanpa Bulan, pasang surut masih berlaku kerana tarikan Matahari.','The Moon helps cause **tides**. Without the Moon, the Sun’s pull would still cause tides.','月球帮助形成**潮汐**，就是海水涨落。没有月球，太阳的引力仍会引起潮汐。']],
 footprint:[
  ['**Jejak ekologi** menunjukkan penggunaan sumber alam oleh manusia. Contohnya makanan, tanah dan tenaga.','An **ecological footprint** shows people’s use of nature’s resources. Examples include food, land and energy.','**生态足迹**表示人们用了多少自然资源，例如食物、土地和能源。'],
  ['Jika kita menggunakan sumber terlalu cepat, alam tidak sempat menggantikannya. **Kurangkan pembaziran**.','If we use resources too quickly, nature cannot replace them fast enough. **Reduce waste**.','资源用得太快，大自然就来不及补充。我们要**减少浪费**。'],
  ['Mulakan dengan tindakan kecil: **jimat air dan elektrik**, habiskan makanan dan guna semula barang.','Start with small actions: **save water and electricity**, avoid wasting food and reuse things.','从小事做起：**节约水电**、不浪费食物、重复使用物品。']],
 composition:[
  ['**Meteoroid** ialah serpihan kecil batu atau logam di angkasa. **Asteroid** biasanya lebih besar.','A **meteoroid** is a small piece of rock or metal in space. An **asteroid** is usually larger.','**流星体**是太空中的小块岩石或金属。**小行星**通常更大。'],
  ['**Komet** mengandungi ais, debu dan batu. Apabila dekat dengan Matahari, ekornya lebih jelas.','A **comet** contains ice, dust and rock. Near the Sun, its tails become easier to see.','**彗星**含有冰、尘埃和岩石。靠近太阳时，彗尾会更明显。']],
 speeds:[
  ['Bandingkan **jarak yang dilalui dalam masa yang sama**. Objek yang bergerak lebih jauh mempunyai laju lebih tinggi.','Compare **distance travelled in the same time**. The object that travels farther is moving faster.','比较物体在**相同时间内走多远**。走得更远的，速度更快。'],
  ['Contoh dalam nota: meteoroid **42 km/s**, asteroid **25 km/s**, komet **10–70 km/s**. Laju sebenar boleh berbeza.','Examples in the notes: meteoroid **42 km/s**, asteroid **25 km/s**, comet **10–70 km/s**. Actual speeds can differ.','笔记举例：流星体 **42 千米/秒**，小行星 **25 千米/秒**，彗星 **10–70 千米/秒**。实际速度会不同。']],
 belt:[
  ['**Jalur asteroid utama** terletak antara Marikh dengan Musytari. Banyak asteroid bergerak mengelilingi Matahari di sini.','The **main asteroid belt** lies between Mars and Jupiter. Many asteroids orbit the Sun here.','**主小行星带**在火星和木星之间。许多小行星在这里绕太阳运行。'],
  ['Vesta ialah contoh asteroid. **Ceres** juga berada di kawasan ini, tetapi dikelaskan sebagai planet kerdil.','Vesta is an asteroid. **Ceres** is also in this region, but is classed as a dwarf planet.','灶神星是一颗小行星。**谷神星**也在这里，但被归类为矮行星。']],
 meteor:[
  ['Di angkasa, serpihan batu atau logam dipanggil **meteoroid**.','In space, a piece of rock or metal is called a **meteoroid**.','在太空中的岩石或金属碎片，叫**流星体**。'],
  ['Apabila masuk ke atmosfera, ia menghasilkan jalur cahaya. Jalur cahaya itu ialah **meteor**.','When it enters the atmosphere, it makes a streak of light. That streak is a **meteor**.','进入大气层后产生的发光轨迹，叫**流星**。'],
  ['Baki pepejal yang sampai ke tanah ialah **meteorit**. Kebanyakan serpihan kecil habis sebelum sampai ke tanah.','A solid piece that reaches the ground is a **meteorite**. Most small pieces do not reach the ground.','剩下的固体落到地面，叫**陨石**。多数小碎片到不了地面。']],
 shower:[
  ['Bumi kadangkala melalui banyak serpihan yang ditinggalkan komet. Serpihan memasuki atmosfera lalu menghasilkan **hujan meteor**.','Earth sometimes passes through many pieces left by a comet. They enter the atmosphere and produce a **meteor shower**.','地球有时会穿过彗星留下的一群碎片。碎片进入大气层，就可能出现**流星雨**。'],
  ['Lihat banyak jalur cahaya di langit. Ia kelihatan datang dari **kawasan yang sama**.','Watch the many streaks of light. They seem to come from **the same area** of the sky.','看天空里的许多光线。它们看起来从**同一个区域**散开。']],
 near:[
  ['Sesetengah asteroid bergerak dekat dengan Bumi. **Dekat tidak bermaksud pasti berlanggar**.','Some asteroids travel near Earth. **Being near does not mean they will hit Earth**.','有些小行星会靠近地球。**靠近不代表一定会撞上**。'],
  ['Untuk berlanggar, dua objek mesti sampai ke **tempat yang sama pada masa yang sama**.','To collide, two objects must reach **the same place at the same time**.','两个物体要在**同一时间到达同一地点**，才会碰撞。']],
 deflect:[
  ['**Kesan asteroid lebih awal**. Saintis menggunakan teleskop untuk mengesan dan mengikuti laluannya.','**Find an asteroid early**. Scientists use telescopes to find it and follow its path.','**及早发现小行星**。科学家用望远镜寻找它，并追踪它的路线。'],
  ['Perubahan kecil pada gerakan asteroid boleh mengubah laluannya. Jika dibuat cukup awal, asteroid boleh **terlepas Bumi**.','A small change in an asteroid’s motion can change its path. Done early enough, it can make the asteroid **miss Earth**.','让小行星的运动发生一点改变，就能改变路线。做得够早，它就可能**避开地球**。']],
 comet:[
  ['Dekat dengan Matahari, ais komet berubah terus menjadi gas. Ini dipanggil **pemejalwapan**.','Near the Sun, comet ice changes directly into gas. This is called **sublimation**.','靠近太阳时，彗星的冰直接变成气体。这叫**升华**。'],
  ['Gas dan debu membentuk awan di sekeliling komet serta **ekor**. Ekor menjadi lebih jelas dekat dengan Matahari.','Gas and dust form a cloud around the comet and its **tails**. The tails become clearer near the Sun.','气体和尘埃围着彗星形成云团，也形成**彗尾**。靠近太阳时更明显。'],
  ['Ekor ion menghala **menjauhi Matahari**. Ekor debu pula boleh melengkung.','The ion tail points **away from the Sun**. The dust tail can curve.','离子尾指向**背离太阳**的方向。尘埃尾可以是弯的。']],
 impact:[
  ['Asteroid yang besar boleh membentuk **kawah** apabila menghentam tanah. Impak besar di laut boleh mencetuskan tsunami.','A large asteroid can make a **crater** when it hits land. A large ocean impact can cause a tsunami.','大型小行星撞到地面，可能形成**撞击坑**。撞入海洋，可能引起海啸。'],
  ['Debu daripada impak besar boleh menghalang cahaya Matahari. Tumbuhan dan **rantaian makanan** boleh terjejas.','Dust from a large impact can block sunlight. Plants and **food chains** can be affected.','大型撞击产生的尘埃可能挡住阳光，影响植物和**食物链**。']],
 sextant:[
  ['**Sekstan** mengukur sudut. Gunakannya untuk melihat berapa tinggi bintang di atas ufuk.','A **sextant** measures angles. Use it to measure how high a star is above the horizon.','**六分仪**用来量角度，可以量恒星在地平线上方多高。'],
  ['**Ufuk** ialah garisan tempat langit kelihatan bertemu dengan bumi atau laut.','The **horizon** is the line where the sky seems to meet the land or sea.','**地平线**就是天空看起来与地面或海面相接的那条线。']],
 comparison:[
  ['Pilih satu ciri untuk dibandingkan, seperti **jarak atau diameter**. Lajur yang lebih tinggi menunjukkan nilai lebih besar.','Choose one feature, such as **distance or diameter**. A taller bar means a larger value.','选一个项目来比较，例如**距离或直径**。柱子越高，数值越大。'],
  ['**Saiz** ialah besar atau kecil. **Jisim** ialah jumlah bahan. Kedua-duanya berbeza.','**Size** tells us how big something is. **Mass** tells us how much matter it contains. They are different.','**大小**表示有多大。**质量**表示含多少物质。两者不同。'],
  ['**Ketumpatan** membandingkan jisim bagi isipadu yang sama. Bandingkan dua bongkah yang sama besar.','**Density** compares mass in the same volume. Think of two blocks of equal size.','**密度**比较相同体积里有多少质量。可以想成比较两块一样大的物体。']],
 conversion:[
  ['Pilih unit dan masukkan nombor. **1 AU ≈ 150 juta km**. Cuba masukkan 3 AU.','Choose a unit and enter a number. **1 AU ≈ 150 million km**. Try entering 3 AU.','选择单位，再输入数字。**1 AU ≈ 1.5 亿千米**。试着输入 3 AU。'],
  ['Tukar AU kepada km: **darab dengan 150 juta**. Tukar km kepada AU: **bahagi dengan 150 juta**.','Change AU to km: **multiply by 150 million**. Change km to AU: **divide by 150 million**.','AU 换成千米：**乘以 1.5 亿**。千米换成 AU：**除以 1.5 亿**。'],
  ['Untuk tahun cahaya, gunakan **1 tahun cahaya ≈ 9.5 × 10¹² km**. Cara darab dan bahagi adalah sama.','For light-years, use **1 light-year ≈ 9.5 × 10¹² km**. Multiply or divide in the same way.','光年的换算用 **1 光年 ≈ 9.5 × 10¹² 千米**，同样用乘法或除法。']],
 locked:[
  ['Bulan **berputar sekali** sambil **mengelilingi Bumi sekali**. Kedua-duanya mengambil masa yang sama.','The Moon **spins once** while **going around Earth once**. Both take the same time.','月球**自转一圈**，也刚好**绕地球一圈**。两者用的时间相同。'],
  ['Sebab itu kita hampir selalu melihat **sisi Bulan yang sama**. Bulan masih berputar.','That is why we nearly always see **the same side of the Moon**. The Moon still rotates.','所以我们几乎总看到**月球的同一面**。月球并不是没有自转。']]
};
export const learnerPlanets={
 mercury:[['**Utarid** ialah planet paling dekat dengan Matahari dan paling kecil. Permukaannya berbatu dan mempunyai banyak kawah.','**Mercury** is the nearest planet to the Sun and the smallest. It has a rocky surface with many craters.','**水星**最靠近太阳，也是最小的行星。表面是岩石，有许多撞击坑。'],['Utarid hampir tiada atmosfera. Suhunya **sangat panas pada siang** dan **sangat sejuk pada malam**.','Mercury has almost no atmosphere. It is **very hot by day** and **very cold at night**.','水星几乎没有大气层，**白天很热，晚上很冷**。']],
 venus:[['**Zuhrah** hampir sama besar dengan Bumi. Tetapi Zuhrah ialah planet **paling panas**.','**Venus** is nearly Earth’s size. But Venus is the **hottest planet**.','**金星**的大小接近地球，却是**最热的行星**。'],['Atmosferanya tebal dan banyak mengandungi **karbon dioksida**. Haba sukar keluar.','Its thick atmosphere contains lots of **carbon dioxide**. Heat has difficulty escaping.','它的大气层很厚，含大量**二氧化碳**，热量不容易散出去。']],
 earth:learnerTopics.habitat,
 mars:[['**Marikh** kelihatan merah kerana oksida besi, seperti bahan dalam karat. Permukaannya mempunyai gunung berapi dan kawah.','**Mars** looks red because of iron oxides, like those in rust. Its surface has volcanoes and craters.','**火星**因氧化铁而显得红，类似铁锈的颜色。表面有火山和撞击坑。'],['Marikh mempunyai dua bulan: **Phobos dan Deimos**. Terdapat ais di kawasan kutubnya.','Mars has two moons: **Phobos and Deimos**. There is ice at its poles.','火星有**火卫一、火卫二**两颗卫星，两极有冰。']],
 jupiter:[['**Musytari** ialah planet paling besar. Ia ialah **gergasi gas**, terutamanya hidrogen dan helium.','**Jupiter** is the largest planet. It is a **gas giant**, made mainly of hydrogen and helium.','**木星**是最大的行星。它是**气态巨行星**，主要由氢和氦组成。'],['Lihat jalur awan dan **Bintik Merah Besar**. Bintik itu ialah ribut yang sangat besar.','Look at the cloud bands and the **Great Red Spot**. The spot is a huge storm.','观察云带和**大红斑**。大红斑是一个巨大的风暴。']],
 saturn:[['**Zuhal** terkenal dengan gelangnya. Gelang itu terdiri daripada banyak kepingan ais, batu dan debu.','**Saturn** is known for its rings. They contain many pieces of ice, rock and dust.','**土星**最明显的特点是行星环。环由许多冰块、岩石和尘埃组成。'],['Gelang itu **bukan satu keping cakera pepejal**. Zuhal ialah planet kedua terbesar.','The rings are **not one solid disc**. Saturn is the second-largest planet.','行星环**不是一整块实心圆盘**。土星是第二大的行星。']],
 uranus:[['**Uranus** kelihatan biru-hijau. Paksi putarannya sangat condong, seperti berpusing sambil berbaring.','**Uranus** looks blue-green. Its axis is very tilted, so it seems to spin on its side.','**天王星**呈蓝绿色。它的轴很斜，看起来像侧躺着转。'],['Uranus ialah **gergasi ais**. Ia mengambil kira-kira **84 tahun Bumi** untuk mengelilingi Matahari.','Uranus is an **ice giant**. It takes about **84 Earth years** to orbit the Sun.','天王星是**冰巨行星**，绕太阳一圈约要 **84 个地球年**。']],
 neptune:[['**Neptun** ialah planet kelapan dan paling jauh dari Matahari. Anginnya sangat kencang.','**Neptune** is the eighth and farthest planet from the Sun. It has very strong winds.','**海王星**是第八颗行星，离太阳最远。它的风非常强。'],['Neptun ialah **gergasi ais**. Satu orbit mengambil kira-kira **165 tahun Bumi**.','Neptune is an **ice giant**. One orbit takes about **165 Earth years**.','海王星是**冰巨行星**，公转一圈约要 **165 个地球年**。']]
};
