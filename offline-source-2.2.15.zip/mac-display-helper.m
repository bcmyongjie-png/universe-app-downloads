// A narrow, non-privileged CoreGraphics bridge. Built on macOS, for both chips.
// Every mutation compares the live state with the caller's snapshot first.
// Configurations are session-scoped, not written as permanent user settings.
#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ColorSync/ColorSync.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static void fail(NSString *message) {
    @throw [NSException exceptionWithName:@"DisplayError" reason:message userInfo:nil];
}
static void check(CGError error, NSString *operation) {
    if (error != kCGErrorSuccess) fail([NSString stringWithFormat:@"%@: %d", operation, error]);
}
static NSArray *snapshot(void) {
    CGDirectDisplayID ids[32]; uint32_t count = 0;
    check(CGGetOnlineDisplayList(32, ids, &count), @"Read connected displays");
    if (!count || count >= 32) fail(@"Unsupported display count");
    NSMutableArray *rows = [NSMutableArray array];
    for (uint32_t i = 0; i < count; i++) {
        CGDirectDisplayID display = ids[i];
        CFUUIDRef uuid = CGDisplayCreateUUIDFromDisplayID(display);
        if (!uuid) fail(@"Display identifier unavailable");
        NSString *key = CFBridgingRelease(CFUUIDCreateString(NULL, uuid)); CFRelease(uuid);
        CGDisplayModeRef mode = CGDisplayCopyDisplayMode(display);
        if (!mode) fail(@"Display mode unavailable");
        int32_t modeId = CGDisplayModeGetIODisplayModeID(mode); CGDisplayModeRelease(mode);
        CGRect bounds = CGDisplayBounds(display);
        [rows addObject:@{@"id":@(display), @"uuid":key,
            @"builtin":@(CGDisplayIsBuiltin(display) != 0), @"active":@(CGDisplayIsActive(display) != 0),
            @"mirror":@(CGDisplayMirrorsDisplay(display)), @"hardwareMirror":@(CGDisplayIsInHWMirrorSet(display) != 0),
            @"fixedMirror":@(CGDisplayIsAlwaysInMirrorSet(display) != 0),
            @"x":@(bounds.origin.x), @"y":@(bounds.origin.y), @"width":@(bounds.size.width), @"height":@(bounds.size.height),
            @"mode":@(modeId), @"rotation":@(CGDisplayRotation(display))}];
    }
    [rows sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) { return [a[@"id"] compare:b[@"id"]]; }];
    return rows;
}
static NSArray *decode(const char *text) {
    if (strlen(text) > 32768) fail(@"Display request too large");
    NSData *data = [[NSString stringWithUTF8String:text] dataUsingEncoding:NSUTF8StringEncoding];
    id rows = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if (![rows isKindOfClass:[NSArray class]] || [rows count] != 2) fail(@"Expected two connected displays");
    return rows;
}
static CGDisplayModeRef findMode(CGDirectDisplayID display, int32_t modeId) {
    CGDisplayModeRef current = CGDisplayCopyDisplayMode(display);
    if (current && CGDisplayModeGetIODisplayModeID(current) == modeId) return current;
    if (current) CGDisplayModeRelease(current);
    CFArrayRef modes = CGDisplayCopyAllDisplayModes(display, NULL);
    CGDisplayModeRef result = NULL;
    if (modes) {
        for (CFIndex i = 0; i < CFArrayGetCount(modes); i++) {
            CGDisplayModeRef mode = (CGDisplayModeRef)CFArrayGetValueAtIndex(modes, i);
            if (CGDisplayModeGetIODisplayModeID(mode) == modeId) { result = CGDisplayModeRetain(mode); break; }
        }
        CFRelease(modes);
    }
    return result;
}
static NSArray *apply(NSArray *expected, NSArray *target) {
    NSArray *live = snapshot();
    if (![expected isEqual:live]) fail(@"Displays changed; no configuration was applied");
    CGDisplayModeRef modes[2] = {NULL, NULL};
    CGDisplayConfigRef config = NULL;
    @try {
        BOOL hasHome = NO; unsigned rootCount = 0;
        for (NSUInteger i = 0; i < 2; i++) {
            NSDictionary *before = live[i], *after = target[i];
            if (![after isKindOfClass:[NSDictionary class]]) fail(@"Invalid target display");
            for (NSString *key in @[@"id", @"uuid", @"builtin", @"fixedMirror", @"rotation"])
                if (![before[key] isEqual:after[key]]) fail(@"Cannot replace or rotate a display");
            if ([before[@"fixedMirror"] boolValue]) fail(@"Fixed mirroring cannot be changed");
            for (NSString *key in @[@"active", @"mirror", @"x", @"y", @"width", @"height", @"mode"])
                if (![after[key] isKindOfClass:[NSNumber class]]) fail(@"Invalid display field");
            uint32_t mirror = [after[@"mirror"] unsignedIntValue];
            if (mirror && mirror != [target[1-i][@"id"] unsignedIntValue]) fail(@"Invalid mirror source");
            if ([after[@"builtin"] boolValue] && ([after[@"active"] boolValue] || mirror)) hasHome = YES;
            if (!mirror) {
                rootCount++;
                if (![after[@"active"] boolValue]) fail(@"Cannot switch a screen off");
                modes[i] = findMode([after[@"id"] unsignedIntValue], [after[@"mode"] intValue]);
                if (!modes[i]) fail(@"Requested display mode is no longer available");
            }
            if (fabs([after[@"x"] doubleValue]) > 100000 || fabs([after[@"y"] doubleValue]) > 100000)
                fail(@"Invalid display position");
        }
        if (!hasHome || !rootCount) fail(@"The laptop display must remain usable");
        // A second snapshot reduces the window between validation and commit.
        if (![expected isEqual:snapshot()]) fail(@"Displays changed during validation");
        check(CGBeginDisplayConfiguration(&config), @"Begin display configuration");
        for (NSDictionary *before in live)
            if ([before[@"mirror"] unsignedIntValue])
                check(CGConfigureDisplayMirrorOfDisplay(config, [before[@"id"] unsignedIntValue], kCGNullDirectDisplay), @"Leave mirroring");
        for (NSUInteger i = 0; i < 2; i++) {
            NSDictionary *after = target[i]; CGDirectDisplayID display = [after[@"id"] unsignedIntValue];
            if (![after[@"mirror"] unsignedIntValue]) {
                check(CGConfigureDisplayWithDisplayMode(config, display, modes[i], NULL), @"Keep display resolution");
                check(CGConfigureDisplayOrigin(config, display, [after[@"x"] intValue], [after[@"y"] intValue]), @"Position display");
            }
        }
        for (NSDictionary *after in target)
            if ([after[@"mirror"] unsignedIntValue])
                check(CGConfigureDisplayMirrorOfDisplay(config, [after[@"id"] unsignedIntValue], [after[@"mirror"] unsignedIntValue]), @"Restore mirroring");
        CGError result = CGCompleteDisplayConfiguration(config, kCGConfigureForSession); config = NULL;
        check(result, @"Apply display configuration");
        return snapshot();
    } @finally {
        if (config) CGCancelDisplayConfiguration(config);
        for (NSUInteger i = 0; i < 2; i++) if (modes[i]) CGDisplayModeRelease(modes[i]);
    }
}
int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSDictionary *response;
        @try {
            NSArray *rows;
            if (argc == 2 && strcmp(argv[1], "snapshot") == 0) rows = snapshot();
            else if (argc == 4 && strcmp(argv[1], "apply") == 0) rows = apply(decode(argv[2]), decode(argv[3]));
            else { fail(@"Unsupported display command"); return 1; }
            response = @{@"ok":@YES, @"displays":rows};
        } @catch (NSException *error) {
            response = @{@"ok":@NO, @"error":error.reason ?: @"Display configuration failed"};
        }
        NSData *json = [NSJSONSerialization dataWithJSONObject:response options:NSJSONWritingSortedKeys error:NULL];
        if (!json) return 1;
        fwrite(json.bytes, 1, json.length, stdout); fputc('\n', stdout);
    }
    return 0;
}
