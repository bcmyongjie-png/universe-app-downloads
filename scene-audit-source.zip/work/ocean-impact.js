import * as T from 'three';

// A local sea-surface illustration: outward-travelling displacement decays.
// This is not a tsunami forecast or a simulation of a named impact.
export function oceanImpact(w){
 w.stars.visible=false;
 const sky=new T.Mesh(new T.SphereGeometry(180,32,20),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,
  vertexShader:'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:'varying float h;void main(){gl_FragColor=vec4(mix(vec3(.38,.48,.54),vec3(.07,.18,.31),smoothstep(0.,.8,h)),1.);}'
 }));w.root.add(sky);
 const water=new T.Mesh(new T.PlaneGeometry(120,120,200,200),new T.ShaderMaterial({uniforms:{age:{value:0}},
  vertexShader:`uniform float age;varying vec3 world;
   void main(){vec3 p=position;float r=length(p.xy),front=age*22.;
    float envelope=exp(-pow((r-front)/1.65,2.))*sin(min(age*6.,1.)*1.5708)*pow(1.-age,1.5);
    p.z=.42*sin((r-front)*4.)*envelope;
    world=(modelMatrix*vec4(p,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(world,1.);}`,
  fragmentShader:`varying vec3 world;void main(){vec3 n=normalize(cross(dFdx(world),dFdy(world)));if(n.y<0.)n=-n;
   vec3 eye=normalize(cameraPosition-world),light=normalize(vec3(-.4,1.,.3));
   float spec=pow(max(dot(reflect(-light,n),eye),0.),90.);
   float fresnel=pow(1.-max(dot(n,eye),0.),4.);
   vec3 c=mix(vec3(.025,.085,.115),vec3(.27,.38,.43),fresnel)+vec3(.45)*spec;
   gl_FragColor=vec4(c,1.);}`,side:T.DoubleSide
 }));water.rotation.x=-Math.PI/2;water.position.y=-3;w.root.add(water);
 const rock=w.sphere('viz-asteroid',.4,'#756e65');
 w.camera.position.set(0,9,23);w.controls.target.set(0,-2,0);w.controls.update();
 return p=>{rock.position.lerpVectors(new T.Vector3(-5,6,0),new T.Vector3(0,-3.5,0),Math.min(1,p/.4));rock.visible=p<.4;water.material.uniforms.age.value=Math.max(0,(p-.4)/.6);};
}
