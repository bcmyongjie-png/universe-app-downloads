import * as T from 'three';
import {loadSceneTexture} from './scene-textures.js';
import {cometAtmosphere} from './comet-art.js';
import {ellipsePosition} from './orbital-motion.js';
import {nearEarthOrbits,orbitAngle,progradePosition} from './celestial-motion.js';
import dayURL from './earth.jpg';
import normalURL from './earth_normal_2048.jpg';
import seaURL from './earth_specular_2048.jpg';
import cloudsURL from './earth_clouds_1024.png';

const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z);
const noise=`float hash(vec3 p){p=fract(p*.3183099+vec3(.17,.31,.53));p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}`;
const vertex=`varying vec3 p,n,w;void main(){p=position;n=normalize(mat3(modelMatrix)*normal);w=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(w,1.);}`;

// Exposure-controlled visible-light illustration. Granulation evolves on an
// accelerated classroom timescale.
function photosphere(cutaway=false){return new T.ShaderMaterial({
 uniforms:{time:{value:0}},vertexShader:vertex,
 fragmentShader:`uniform float time;varying vec3 p,n,w;${noise}
 void main(){${cutaway?'if(p.x>0.&&p.z>0.)discard;':''}
 vec3 s=normalize(p);float a=time*.014;
 s=mat3(cos(a),0.,sin(a),0.,1.,0.,-sin(a),0.,cos(a))*s;
 float grain=noise(s*92.+vec3(0.,time*.12,0.));
 float fine=noise(s*185.+vec3(time*.08,0.,0.));
 float limb=.32+.68*pow(max(dot(normalize(n),normalize(cameraPosition-w)),0.),.48);
 vec3 light=vec3(.75,.69,.58)*(.88+.12*(grain*.7+fine*.3));
 gl_FragColor=vec4(light*limb,1.);}`
});}
function sun(w,r,position,cutaway=false){
 const m=new T.Mesh(new T.SphereGeometry(r,96,64),photosphere(cutaway));
 m.position.copy(position);m.userData={id:'viz-sun',r};w.root.add(m);w.meshes.push(m);return m;
}

export function fusionScene(w){
 // Cutaway of a Sun-like star: core ~0.25 R, radiation to ~0.7 R,
 // convection above it. These layer colours are explanatory, not photographs.
 const r=4;sun(w,r,V(),true);
 const interior=new T.ShaderMaterial({uniforms:{time:{value:0}},side:T.DoubleSide,vertexShader:vertex,
  fragmentShader:`uniform float time;varying vec3 p,n,w;${noise}
  void main(){float q=length(p)/4.;if(q<.25||q>1.)discard;
   float theta=atan(p.y,p.x+p.z);float field=noise(vec3(theta*22.,q*40.-time*.15,0.));
   float cells=sin(theta*31.+sin(q*26.+time*.3))*sin(q*35.-time*.35);
   vec3 radiative=mix(vec3(.42,.20,.055),vec3(.26,.105,.025),smoothstep(.25,.7,q));
   vec3 convective=vec3(.30,.17,.055)*(.82+.14*cells+.13*field);
   gl_FragColor=vec4(mix(radiative,convective,smoothstep(.69,.72,q)),1.);}`
 });
 const face=new T.CircleGeometry(r,96,-Math.PI/2,Math.PI);
 const front=new T.Mesh(face,interior);w.root.add(front);
 const side=new T.Mesh(face.clone(),interior);side.rotation.y=-Math.PI/2;w.root.add(side);
 const core=new T.Mesh(new T.SphereGeometry(r*.25,64,40),new T.ShaderMaterial({uniforms:{time:{value:0}},vertexShader:vertex,
  fragmentShader:`uniform float time;varying vec3 p,n,w;${noise}
  void main(){float limb=.55+.45*max(dot(normalize(n),normalize(cameraPosition-w)),0.);
   float grain=.96+.04*noise(p*12.+time*.08);
   gl_FragColor=vec4(vec3(.8,.55,.23)*limb*grain,1.);}`
 }));w.root.add(core);
 const label=new T.Object3D();label.position.set(1.5,-1.2,1.5);w.root.add(label);w.label('fusion-core','核心 · H → He',label);
 const caption=new T.Object3D();caption.position.set(0,5.1,0);w.root.add(caption);w.label('fusion-cutaway','太阳内部剖面示意',caption);
 w.camera.position.set(8,3,19);w.controls.target.set(0,0,0);w.controls.update();
 return()=>{}; // Shader time is supplied by the shared seek/pause clock.
}

export function habitatScene(w,kind='habitat'){
 const r=4.2,globe=new T.Group();globe.rotation.z=-T.MathUtils.degToRad(23.44);w.root.add(globe);
 const texture=(url,srgb=false)=>loadSceneTexture(url,{anisotropy:8,...(srgb?{colorSpace:T.SRGBColorSpace}:{})});
 const earth=new T.Mesh(new T.SphereGeometry(r,96,64),new T.MeshPhongMaterial({
  map:texture(dayURL,true),normalMap:texture(normalURL),normalScale:new T.Vector2(.28,.28),
  specularMap:texture(seaURL),specular:new T.Color('#293b49'),shininess:85
 }));earth.userData={id:'viz-earth',r};globe.add(earth);w.meshes.push(earth);
 const clouds=new T.Mesh(new T.SphereGeometry(r*1.002,96,64),new T.MeshPhongMaterial({map:texture(cloudsURL,true),transparent:true,opacity:.82,depthWrite:false,shininess:0}));globe.add(clouds);
 const sunlight=V(-.8,.35,1).normalize();w.keyLight.intensity=0;
 const light=new T.DirectionalLight('#fffaf1',2.1);light.position.copy(sunlight).multiplyScalar(30);w.root.add(light);
 const air=new T.Mesh(new T.SphereGeometry(r*1.015,80,48),new T.ShaderMaterial({
  uniforms:{sunlight:{value:sunlight}},vertexShader:vertex,transparent:true,depthWrite:false,side:T.BackSide,blending:T.AdditiveBlending,
  fragmentShader:`uniform vec3 sunlight;varying vec3 p,n,w;void main(){
   float rim=pow(1.-abs(dot(normalize(n),normalize(cameraPosition-w))),4.);
   float daylight=smoothstep(-.22,.35,dot(normalize(n),sunlight));
   gl_FragColor=vec4(vec3(.10,.32,.65),rim*daylight*.42);}`
 }));globe.add(air);
 w.camera.position.set(0,1.2,19);w.controls.update();
 return(p,t)=>{
  earth.rotation.y=1.8+(kind==='daynight'?p*Math.PI*2:kind==='climate'?Math.PI*4*(p-p*p/2):t*.075);
  clouds.rotation.y=earth.rotation.y+t*.006;
  if(kind==='climate')document.querySelector('#visualMeasure').textContent='自转速度 · '+Math.round((1-p)*100)+'%';
 };
}

export function cometScene(w){
 const a=9,b=6.8,focus=Math.sqrt(a*a-b*b),star=V(focus,0,0);
 sun(w,.85,star);
 const nucleus=w.sphere('viz-comet',.13,'#554e43');
 nucleus.material.uniforms.cometSun={value:star};
 nucleus.material.fragmentShader='uniform vec3 cometSun;'+nucleus.material.fragmentShader.replace('vec3(-.6,.8,1.)','normalize(cometSun-vW)');
 const tail=cometAtmosphere(w,10);
 // No physical ellipse line in space. The motion itself follows Kepler's law.
 w.camera.position.set(3,24,38);w.controls.target.set(3,-3.2,0);w.controls.update();
 return(p,t)=>{
  nucleus.position.set(...ellipsePosition(a,b,Math.PI+p*Math.PI*2,focus));
  const away=nucleus.position.clone().sub(star),distance=away.length();
  tail.position.copy(nucleus.position);tail.quaternion.setFromUnitVectors(V(1,0,0),away.normalize());
  const activity=T.MathUtils.clamp(Math.pow(3.2/distance,1.5),.07,1);
  tail.scale.setScalar(.5+activity*.65);tail.userData.setActivity(activity);
 };
}

export function nearEarthScene(w){
 sun(w,.55,V());w.keyLight.intensity=0;const light=new T.PointLight('#fffaf1',3,0,0);w.root.add(light);
 const earth=w.sphere('viz-earth',.32,'#589dcb');earth.material.dispose();earth.material=new T.MeshPhongMaterial({map:loadSceneTexture(dayURL,{colorSpace:T.SRGBColorSpace})});
 const trace=(positions,color)=>w.root.add(new T.Line(new T.BufferGeometry().setFromPoints(positions.map(p=>V(...p))),new T.LineBasicMaterial({color,transparent:true,opacity:.3})));
 trace(Array.from({length:161},(_,i)=>progradePosition(5,i/160*Math.PI*2)),'#8398ac');
 const rocks=nearEarthOrbits.map((o,i)=>{const a=o.a*5,b=a*Math.sqrt(1-o.e*o.e);trace(Array.from({length:161},(_,k)=>ellipsePosition(a,b,-k/160*Math.PI*2)),['#d6b578','#b7a0d4','#91bbaa'][i]);
  const rock=w.sphere('viz-asteroid',.1,'#998775');rock.userData.id='viz-'+o.name;rock.material.uniforms.sunlit.value=1;w.label('viz-'+o.name,o.name,rock,V(0,1.1,0));return{rock,a,b,au:o.a};});
 w.camera.position.set(0,18,23);w.controls.target.set(-1,0,0);w.controls.update();
 return p=>{const phase=p*Math.PI*2;earth.position.set(...progradePosition(5,phase));rocks.forEach(({rock,a,b,au})=>rock.position.set(...ellipsePosition(a,b,-orbitAngle(phase,au))));};
}
