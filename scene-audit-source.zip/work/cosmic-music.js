// Original instrumental score; no film recording or film melody is used.
export function createSpaceAudio(host){
 let ctx,master,dry,wet,active=false,volume=.45,nextBeat=0,beat=0,lastCue=-10;
 const tempo=60/68;
 const chords=[[50,57,62,65,69],[46,53,58,62,65],[53,60,65,69,72],[48,55,60,64,67],[50,57,62,65,72],[46,53,58,65,69],[55,62,67,70,74],[48,55,60,64,69]];
 const melody=[74,null,77,76,74,null,69,null,72,null,74,77,76,null,72,null];
 const button=document.createElement('button');button.id='soundControl';button.type='button';host.append(button);
 const hz=n=>440*Math.pow(2,(n-69)/12);
 function paint(){button.textContent=active?'音乐已开':'开启音乐';button.setAttribute('aria-pressed',String(active));button.setAttribute('aria-label',active?'关闭宇宙背景音乐':'开启宇宙背景音乐');}
 function level(){if(ctx)master.gain.setTargetAtTime(active?volume*.55:0,ctx.currentTime,.25);}
 function voice(note,t,duration,gain=.04,pan=0,type='sine',attack=.05){
  const osc=ctx.createOscillator(),amp=ctx.createGain(),filter=ctx.createBiquadFilter(),stereo=ctx.createStereoPanner();
  osc.type=type;osc.frequency.value=hz(note);filter.type='lowpass';filter.frequency.value=type==='sawtooth'?1100:4200;filter.Q.value=.35;stereo.pan.value=pan;
  amp.gain.setValueAtTime(0,t);amp.gain.linearRampToValueAtTime(gain,t+attack);amp.gain.setTargetAtTime(gain*.65,t+attack+.1,.45);amp.gain.setTargetAtTime(0,t+duration*.65,Math.max(.12,duration*.12));amp.gain.linearRampToValueAtTime(0,t+duration+.5);
  osc.connect(filter);filter.connect(amp);amp.connect(stereo);stereo.connect(dry);stereo.connect(wet);osc.start(t);osc.stop(t+duration+.6);
  osc.onended=()=>[osc,filter,amp,stereo].forEach(n=>n.disconnect());
 }
 function schedule(){
  if(!active||ctx?.state!=='running')return;
  if(nextBeat<ctx.currentTime)nextBeat=ctx.currentTime+.06;
  while(nextBeat<ctx.currentTime+.25){
   const t=nextBeat,chord=chords[Math.floor(beat/8)%chords.length],bar=Math.floor(beat/8);
   if(beat%8===0){
    chord.forEach((n,i)=>{voice(n,t,tempo*9,.018,(i-2)*.3,'sawtooth',1.4);voice(n+.045,t,tempo*9,.018,(2-i)*.3,'sine',1.6);});
    voice(chord[0]-12,t,tempo*8,.08,0,'sine',.35);
   }
   const arp=chord[[1,2,3,2,4,3,2,1][beat%8]]+12;
   voice(arp,t,tempo*2.6,.023,Math.sin(beat*.7)*.55,'sine',.025);
   voice(arp+12,t,tempo*1.3,.005,-Math.sin(beat*.7)*.45,'sine',.015);
   if(bar%4>=2&&beat%2===0){const n=melody[Math.floor(beat/2)%melody.length];if(n!==null)voice(n,t,tempo*3.2,.03,.15,'triangle',.25);}
   if(beat%4===0)voice(chord[0]-12,t,tempo*.8,.026,0,'sine',.03);
   beat++;nextBeat+=tempo;
  }
 }
 function init(){
  const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw Error('Audio unavailable');ctx=new Audio();
  master=ctx.createGain();master.gain.value=0;const limit=ctx.createDynamicsCompressor();limit.threshold.value=-18;limit.knee.value=20;limit.ratio.value=3;master.connect(limit);limit.connect(ctx.destination);
  dry=ctx.createGain();dry.gain.value=.8;dry.connect(master);wet=ctx.createGain();wet.gain.value=.38;
  const reverb=ctx.createConvolver(),impulse=ctx.createBuffer(2,Math.floor(ctx.sampleRate*4),ctx.sampleRate);
  for(let c=0;c<2;c++){const a=impulse.getChannelData(c);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*Math.pow(1-i/a.length,3)*.4;}
  reverb.buffer=impulse;wet.connect(reverb);reverb.connect(master);
 }
 button.onclick=async e=>{e.stopPropagation();try{if(!ctx)init();if(active)active=false;else{await ctx.resume();active=ctx.state==='running';nextBeat=ctx.currentTime+.05;}level();paint();schedule();}catch{active=false;paint();button.textContent='音乐不可用';}};
 document.addEventListener('input',e=>{if(e.target.id==='soundVolume'){volume=Number(e.target.value)/100;level();}});
 // Resource panels and videos do not own music playback. Only the music
 // control/volume changes it; resume an interrupted context on returning.
 document.addEventListener('visibilitychange',()=>{if(ctx&&active&&!document.hidden&&ctx.state!=='running')void ctx.resume().then(()=>{nextBeat=ctx.currentTime+.1;level();schedule();}).catch(()=>{active=false;paint();});});
 window.addEventListener('pagehide',()=>{if(ctx)void ctx.suspend().catch(()=>{});});
 window.addEventListener('pageshow',()=>{if(ctx&&active)void ctx.resume().then(()=>{nextBeat=ctx.currentTime+.1;level();}).catch(()=>{});});
 setInterval(schedule,100);paint();
 return {setScene(){},setLesson(){},motion(){},cue(type){if(!active||ctx?.state!=='running'||ctx.currentTime-lastCue<.35)return;lastCue=ctx.currentTime;if(type==='enter'||type==='lesson'){voice(81,ctx.currentTime,.8,.012,-.3);voice(86,ctx.currentTime+.12,1,.009,.3);}}};
}
