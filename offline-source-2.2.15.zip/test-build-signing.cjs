const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
async function configuration(platform,env={}){
 const builds=[],errors=[],warnings=[],writes=[],helperBuilds=[];let exitCode=0;
 const target={createTarget:()=>({})};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'build.cjs'),'utf8'),{
  process:{platform,env,exit:code=>{exitCode=code;}},
  console:{error:e=>errors.push(String(e)),warn:e=>warnings.push(String(e))},
  require:name=>{
   if(name==='electron-builder')return {build:async options=>{builds.push(options);},Platform:{MAC:target,WINDOWS:target},Arch:{universal:'universal',x64:'x64'}};
   if(name==='fs')return {writeFileSync:(...args)=>writes.push(args),copyFileSync:(...args)=>writes.push(args)};
   if(name==='./package.json')return {version:'2.2.15'};
   if(name==='./build-mac-helper.cjs')return {buildMacHelper:()=>helperBuilds.push('universal')};
   return require(name);
  }
 },{filename:'build.cjs'});
 await new Promise(resolve=>setImmediate(resolve));
 return {builds,errors,warnings,writes,helperBuilds,exitCode};
}
test('Windows release without signing credentials fails before altering or building an app',async()=>{
 const result=await configuration('win32');
 assert.equal(result.exitCode,1);assert.equal(result.builds.length,0);assert.equal(result.writes.length,0);
 assert.ok(result.errors.some(e=>/sign/i.test(e)));
});
test('both Windows editions require signatures even when credentials are provided',async()=>{
 const result=await configuration('win32',{CSC_LINK:'configured-in-CI'});
 assert.equal(result.exitCode,0);assert.equal(result.builds.length,2);
 for(const {config} of result.builds){assert.equal(config.forceCodeSigning,true);assert.equal(config.win.signAndEditExecutable,true);}
});
test('a selected certificate-store identity reaches the Windows signing tool',async()=>{
 const result=await configuration('win32',{WIN_CERT_SHA1:'1234567890ABCDEF1234567890ABCDEF12345678AB'});
 assert.equal(result.builds.length,2);
 for(const {config} of result.builds)assert.equal(config.win.signtoolOptions.certificateSha1,'1234567890ABCDEF1234567890ABCDEF12345678AB');
});
test('the Windows signing gate does not change the existing Mac build flow',async()=>{
 const result=await configuration('darwin');assert.equal(result.exitCode,0);assert.equal(result.builds.length,2);
 for(const {config} of result.builds)assert.notEqual(config.forceCodeSigning,true);
});

test('explicit unsigned distribution builds both editions and clearly records the missing publisher signature',async()=>{
 const result=await configuration('win32',{UNIVERSE_UNSIGNED_RELEASE:'1'});
 assert.equal(result.exitCode,0);assert.equal(result.builds.length,2);
 assert.ok(result.warnings.some(w=>/unsigned/i.test(w)&&/Smart App Control/.test(w)));
 for(const {config} of result.builds){assert.equal(config.forceCodeSigning,false);assert.equal(config.win.signAndEditExecutable,true);}
});

test('unsigned opt-in never overrides a configured signing identity',async()=>{
 const result=await configuration('win32',{UNIVERSE_UNSIGNED_RELEASE:'1',CSC_LINK:'configured-in-CI'});
 assert.equal(result.builds.length,2);assert.equal(result.warnings.length,0);
 for(const {config} of result.builds)assert.equal(config.forceCodeSigning,true);
});

test('Mac editions include the native display helper and its JS session before packaging',async()=>{
 const result=await configuration('darwin');assert.equal(result.exitCode,0);
 assert.equal(result.helperBuilds.length,1);
 for(const {config} of result.builds){
  assert.ok(config.files.includes('mac-display-mode.cjs'));
  assert.ok(config.extraResources.some(r=>r.from==='mac-display-helper'&&r.to==='mac-display-helper'));
 }
 const windows=await configuration('win32',{UNIVERSE_UNSIGNED_RELEASE:'1'});
 assert.equal(windows.helperBuilds.length,0);
 assert.ok(windows.builds.every(b=>!b.config.extraResources.some(r=>r.to==='mac-display-helper')));
});
