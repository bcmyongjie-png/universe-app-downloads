import {loadSceneTexture} from './scene-textures.js';
import diskUrl from './galaxy-disk.png';
import * as T from 'three';
const diskTexture=loadSceneTexture(diskUrl,{colorSpace:T.SRGBColorSpace,anisotropy:8});diskTexture.colorSpace=T.SRGBColorSpace;diskTexture.anisotropy=8;
// Procedural artistic reconstruction: dust attenuates the disk, resolved stars occupy a volume.
const vertex=`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`;
const fragment=`varying vec2 vUv;uniform float seed;uniform float kind;uniform float gain;
float hash(vec2 p){vec3 p3=fract(vec3(p.xyx)*.1031+seed*.013);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
float fbm(vec2 p){float n=0.,a=.5;for(int i=0;i<5;i++){n+=noise(p)*a;p=mat2(.8,.6,-.6,.8)*p*2.13+3.2;a*=.5;}return n;}
void main(){vec2 p=(vUv-.5)*2.;float r=length(p);if(r>1.)discard;
float angle=atan(p.y,p.x);float n=fbm(p*18.+seed),fine=fbm(p*85.+seed);
float phase=angle*2.-log(r+.12)*5.6+seed*.1;
float arms=pow(.5+.5*cos(phase+n*2.),3.);float dust=pow(.5+.5*cos(phase+.55+fine*1.8),12.)*smoothstep(.09,.25,r);
float taper=1.-smoothstep(.65,1.,r);float disk=exp(-r*3.1)*(.2+arms*.9)*(n*.9+.45)*taper;
float core=exp(-r*r*115.)*.22+exp(-r*13.)*.16;
vec3 col=mix(vec3(.23,.32,.46),vec3(.79,.58,.36),exp(-r*5.));
col*=disk*(.15+fine*fine*2.)*1.8;col*=1.-dust*.88;col+=vec3(.95,.8,.61)*core;
float knots=smoothstep(.68,.83,noise(p*110.))*arms*disk*.16;col+=vec3(.6,.23,.29)*knots;
if(kind> .5&&kind<1.5){float e=length(p*vec2(1.,1.45));col=vec3(.65,.56,.45)*(exp(-e*7.)*.9+exp(-e*e*70.)*.35)*taper;}
if(kind>1.5){float shape=exp(-dot(p*vec2(.9,1.5),p*vec2(.9,1.5))*4.);col=vec3(.35,.42,.53)*shape*pow(n,2.)*1.2*taper;}
gl_FragColor=vec4(col*gain,1.);}`;
export function galaxyArt(w,r,{kind=0,seed=1,dim=1,detail=true}={}){
 const group=new T.Group();group.userData.galaxyMotion=kind===0?.009:.003;
 // Three separated emissive sheets retain thickness when the camera circles the disk.
 for(let i=-1;i<=1;i++){const m=new T.Mesh(new T.PlaneGeometry(r*2,r*2),new T.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,uniforms:{seed:{value:seed},kind:{value:kind},gain:{value:dim*(i===0?1.3:.22)}},side:T.DoubleSide,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));if(kind===0){m.material.dispose();m.material=new T.MeshBasicMaterial({map:diskTexture,color:new T.Color().setScalar(dim*(i===0?.85:.065)),side:T.DoubleSide,transparent:true,depthWrite:false,blending:T.AdditiveBlending});}m.rotation.x=-Math.PI/2;m.rotation.z=seed*.017;m.position.y=i*r*.018;group.add(m);}
 let state=seed*137+591;const rand=()=>{state=(state*1664525+1013904223)>>>0;return state/4294967296;};
 const p=[],c=[],sizes=[],count=detail?(innerWidth<650?7000:10000):160;
 for(let i=0;i<count;i++){let rad=Math.pow(rand(),.8)*r,a=rand()*Math.PI*2;const q=rad/r;if(i%3!==0&&kind===0)a=(i%2)*Math.PI+Math.log(q+.12)*2.8+(rand()-.5)*1.3;
 let y=(rand()-.5)*r*(.025+.15*Math.exp(-q*8));let x=Math.cos(a)*rad,z=Math.sin(a)*rad;if(kind===1){y*=3;z*=.7;}if(kind===2){z*=.65;y*=2;}
 p.push(x,y,z);const warm=q<.22||kind===1,b=(.001+rand()*.006)*dim;c.push(b*(warm?1:.65),b*(warm?.82:.77),b*(warm?.65:1));sizes.push(.025+rand()*.055);}
 group.add(w.addParticles(p,c,sizes));
 return group;
}
