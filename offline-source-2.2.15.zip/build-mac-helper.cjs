const {execFileSync}=require('node:child_process');
const path=require('node:path');
function buildMacHelper(){
 if(process.platform!=='darwin')throw Error('Build the Mac display helper on macOS');
 const output=path.join(__dirname,'mac-display-helper');
 execFileSync('/usr/bin/xcrun',['clang','-fobjc-arc','-fblocks','-Wall','-Wextra','-Werror',
  '-mmacosx-version-min=13.0','-arch','arm64','-arch','x86_64',
  '-framework','Foundation','-framework','CoreGraphics','-framework','ColorSync',path.join(__dirname,'mac-display-helper.m'),'-o',output],{stdio:'inherit'});
 execFileSync('/usr/bin/lipo',[output,'-verify_arch','arm64','x86_64'],{stdio:'inherit'});
 execFileSync('/usr/bin/codesign',['--force','--sign','-','--timestamp=none',output],{stdio:'inherit'});
 execFileSync('/usr/bin/codesign',['--verify','--strict',output],{stdio:'inherit'});
 // Read-only probe: never change the build runner's display configuration.
 const result=JSON.parse(execFileSync(output,['snapshot'],{encoding:'utf8',timeout:15000}));
 if(!result.ok||!Array.isArray(result.displays)||!result.displays.length)throw Error('Mac native display query failed: '+result.error);
}
module.exports={buildMacHelper};
