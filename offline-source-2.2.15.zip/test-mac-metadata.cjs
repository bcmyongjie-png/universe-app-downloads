const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const source=fs.readFileSync(path.join(__dirname,'update-metadata.cjs'),'utf8');
function fixture(t,{missing=false}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'universe-mac-feed-'));
 t.after(()=>{assert.equal(path.dirname(path.resolve(root)),path.resolve(os.tmpdir()));assert(path.basename(root).startsWith('universe-mac-feed-'));fs.rmSync(root,{recursive:true,force:true});});
 for(const edition of ['Teacher','Student']){
  const dir=path.join(root,'dist',edition.toLowerCase());fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,`Universe-${edition}-Offline-2.2.13-Mac.dmg`),'old installer');
  if(!missing||edition==='Teacher')fs.writeFileSync(path.join(dir,`Universe-${edition}-Offline-2.2.15-Mac.dmg`),'new '+edition);
 }
 const rooted={...fs,readdirSync:p=>fs.readdirSync(path.join(root,p)),readFileSync:p=>fs.readFileSync(path.join(root,p)),writeFileSync:(p,b)=>fs.writeFileSync(path.join(root,p),b)};
 const run=()=>vm.runInNewContext(source,{require:name=>name==='fs'?rooted:name==='./package.json'?{version:'2.2.15'}:require(name)});
 return {root,run};
}
test('Mac update feeds select the exact current-version DMG when older packages remain',t=>{
 const {root,run}=fixture(t);run();
 for(const edition of ['Teacher','Student']){
  const lower=edition.toLowerCase(),m=JSON.parse(fs.readFileSync(path.join(root,'dist',lower,lower+'-mac.json'),'utf8'));
  assert.equal(m.version,'2.2.15');assert(m.url.endsWith(`Universe-${edition}-Offline-2.2.15-Mac.dmg`));
  const bytes=Buffer.from('new '+edition);assert.equal(m.size,bytes.length);assert.equal(m.sha512,crypto.createHash('sha512').update(bytes).digest('base64'));
 }
});
test('missing current-version Mac installer stops metadata publication instead of reusing an old package',t=>{
 const {root,run}=fixture(t,{missing:true});assert.throws(run,/2\.2\.15/);
 assert(!fs.existsSync(path.join(root,'dist','teacher','teacher-mac.json')),'No partial release feeds');
 assert(!fs.existsSync(path.join(root,'dist','student','student-mac.json')));
});
