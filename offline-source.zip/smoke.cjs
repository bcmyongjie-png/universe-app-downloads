const {_electron}=require('playwright'),assert=require('assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
(async()=>{fs.mkdirSync('smoke-results',{recursive:true});for(const edition of ['Teacher','Student']){
 const lower=edition.toLowerCase(),origin='https://universe-'+lower+'.local';
 const executablePath=process.platform==='darwin'?`dist/${lower}/mac-universal/Universe ${edition}.app/Contents/MacOS/Universe ${edition}`:`dist/${lower}/win-unpacked/Universe ${edition}.exe`;
 const app=await _electron.launch({executablePath,args:['--host-resolver-rules=MAP * ~NOTFOUND','--disable-background-networking'],env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-offline-'))},timeout:60000});
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.waitForURL(origin+'/**');await page.locator('#space canvas').waitFor();
  assert.equal(await page.evaluate(()=>typeof window.universeDesktop?.openProjector),'function');
  if(process.platform==='win32'){
   const config=fs.readFileSync(path.join('dist',lower,'win-unpacked','resources','app-update.yml'),'utf8');
   assert(config.includes('universe-'+lower+'-offline-updater'),'Each edition must have an independent updater cache');
  }
  assert.equal(await page.evaluate(async()=>{try{await fetch('https://example.com/');return false}catch{return true}}),true);
  // Reach a lesson and its neighbours through the scene without opening settings.
  const sceneReady=async()=>{await page.waitForFunction(()=>document.querySelector('#labels').style.visibility!=='hidden');};
  await sceneReady();
  await page.getByRole('button',{name:'探索银河系，旋涡星系',exact:true}).click();
  await page.getByRole('button',{name:'探索恒星的一生',exact:true}).waitFor({state:'visible'});
  await sceneReady();
  await page.getByRole('button',{name:'探索恒星的一生',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('#lessonTimeline')?.dataset.kind==='remnants');
  await sceneReady();assert(!(await page.locator('#teacherPanel').isVisible()));
  assert.equal(await page.locator('.lifeMapLabel').count(),9);
  assert.equal(await page.locator('.lifeMapLabel [lang="ms"]').count(),9);
  assert.equal(await page.locator('.lifeMapLabel [lang="en"]').count(),9);
  await page.locator('.motionSpeed').selectOption('2');assert.equal(await page.locator('.motionSpeed').inputValue(),'2');
  await page.locator('.motionInspect').click();await page.locator('#stellarInspect').waitFor({state:'visible'});
  assert.equal(await page.locator('.motionPlay').getAttribute('aria-pressed'),'false');
  await page.getByRole('button',{name:'放大天体',exact:true}).click();await page.getByRole('button',{name:'缩小天体',exact:true}).click();
  await page.keyboard.press('Escape');await page.locator('#lessonTimeline').waitFor({state:'visible'});assert(!(await page.locator('#stellarInspect').isVisible()));
  await page.locator('.motionSpeed').selectOption('1');
  await page.locator('#sceneTopics a[data-topic="galaxy:12"]').click();
  await page.waitForFunction(()=>document.querySelector('#lessonTimeline')?.dataset.kind==='starsize');
  await sceneReady();
  await page.getByRole('button',{name:'返回上一层场景',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('#lessonTimeline')?.dataset.kind==='remnants');
  await sceneReady();
  await page.getByRole('button',{name:'返回上一层场景',exact:true}).click();
  await page.getByRole('button',{name:'探索星云',exact:true}).waitFor({state:'visible'});
  await page.locator('#teacherToggle').click();
  await app.evaluate(()=>{globalThis.fetch=async()=>{throw Error('Test: external network unavailable')}});
  await page.locator('#appUpdateButton').waitFor();
  await page.locator('#appUpdateButton').click();
  await page.waitForFunction(()=>/暂时无法检查更新/.test(document.querySelector('#appUpdateStatus')?.textContent),{},{timeout:60000});
  const options=await page.locator('#lessonSelect option').evaluateAll(ns=>ns.map(n=>({value:n.value,label:n.textContent})));
  assert(options.length>=46);
  for(let i=0;i<options.length;i++){
   if(i)await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption(options[i].value);await page.locator('#startLesson').click();
   await page.waitForFunction(()=>document.querySelector('#labels')?.style.visibility!=='hidden');
   assert((await page.locator('#location').textContent()).includes(options[i].label.replace(/^C\d+ · /,'')));
   await page.locator('#lessonTimeline').waitFor({state:'visible'});
   const seek=async value=>{await page.locator('.motionSeek').evaluate((el,v)=>{el.value=String(v);el.dispatchEvent(new Event('input',{bubbles:true}))},value);await page.waitForTimeout(160)};
   await seek(150);const firstStage=await page.locator('.motionStage').textContent();await seek(850);assert.notEqual(await page.locator('.motionStage').textContent(),firstStage);
   assert.equal(await page.locator('.motionPlay').getAttribute('aria-pressed'),'false');
   if(options[i].value==='galaxy:7')await page.screenshot({path:'smoke-results/'+lower+'-evolution.png'});

  }
  await page.locator('.motionReplay').click();await page.waitForTimeout(700);assert(Number(await page.locator('.motionSeek').inputValue())>0);await page.locator('.motionPlay').click();
  for(const asset of require('./'+lower+'-assets.json').filter(a=>a.path.endsWith('.mp4'))){
   await page.evaluate(async src=>{const v=document.createElement('video');v.muted=true;v.src=src;document.body.append(v);try{await new Promise((resolve,reject)=>{v.onloadedmetadata=resolve;v.onerror=()=>reject(Error('Video metadata failed'));setTimeout(()=>reject(Error('Video timeout')),15000)});await new Promise((resolve,reject)=>{v.onseeked=resolve;v.currentTime=v.duration*.5;setTimeout(()=>reject(Error('Seek timeout')),15000)});await v.play();await new Promise(r=>setTimeout(r,300));if(v.paused||v.error)throw Error('Video did not play')}finally{v.pause();v.removeAttribute('src');v.load();v.remove()}},origin+'/'+asset.path);
  }
  await page.screenshot({path:'smoke-results/'+lower+'.png'});assert.deepEqual(errors,[]);
  console.log(edition+': fresh packaged app, external network blocked, all '+options.length+' scenes, all videos seek/play, bridge available; PASS');
 }finally{await app.close()}
}})().catch(e=>{console.error(e);process.exit(1)});

