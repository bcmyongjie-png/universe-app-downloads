// Opt-in only: changes the connected Windows displays to Duplicate, then checks
// that a single in-app click restores Extend and opens the fullscreen slide.
// Restores the mode measured before the test. Not for unattended CI machines.
const {_electron}=require('playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {execFile}=require('node:child_process');
if(process.platform!=='win32'||process.env.UNIVERSE_HARDWARE_DISPLAY_TEST!=='1'){
 console.log('SKIP: set UNIVERSE_HARDWARE_DISPLAY_TEST=1 on a Windows computer with two connected displays');
}else (async()=>{
 const output=process.env.QA_OUTPUT||fs.mkdtempSync(path.join(os.tmpdir(),'universe-projector-hardware-'));
 fs.mkdirSync(output,{recursive:true});
 const switchMode=mode=>new Promise((resolve,reject)=>execFile(path.join(process.env.SystemRoot,'System32/DisplaySwitch.exe'),[mode],{windowsHide:true,timeout:10000},e=>e?reject(e):resolve()));
 const executablePath=process.env.QA_EXECUTABLE||path.join(__dirname,'dist/teacher/win-unpacked/Universe Teacher.exe');
 const app=await _electron.launch({executablePath,env:{...process.env,UNIVERSE_TEST_DATA:fs.mkdtempSync(path.join(os.tmpdir(),'universe-projector-profile-'))},timeout:60000});
 let changed=false;
 const {readDisplayState}=require('./display-mode.cjs');
 const originalMode=(await readDisplayState()).mode;
 assert.ok(['clone','extend','internal','external'].includes(originalMode));
 const displays=()=>app.evaluate(({screen})=>screen.getAllDisplays().map(({id,internal,bounds})=>({id,internal,bounds})));
 const separated=ds=>ds.some(a=>ds.some(b=>a.id!==b.id&&(a.bounds.x>=b.bounds.x+b.bounds.width||b.bounds.x>=a.bounds.x+a.bounds.width||a.bounds.y>=b.bounds.y+b.bounds.height||b.bounds.y>=a.bounds.y+a.bounds.height)));
 const waitUntil=async fn=>{for(let i=0;i<60;i++){if(await fn())return;await new Promise(r=>setTimeout(r,250));}throw Error('Timed out waiting for display state');};
 try{
  const page=await app.firstWindow(),errors=[];page.setDefaultTimeout(60000);page.on('pageerror',e=>errors.push(e.message));
  await page.locator('#space canvas').waitFor();
  const initial=await displays();assert.ok(separated(initial),'Connect two extended displays before running this opt-in test');
  const click=name=>page.getByRole('button',{name,exact:true}).click();
  await page.locator('#teacherToggle').click();await page.locator('#lessonSelect').selectOption({label:'C12 · 行星大小'});await page.locator('#startLesson').click();
  await click('打开本主题考题');await click('查看第 1 张幻灯片');await click('更多放映选项');await click('全屏 / 退出全屏');
  changed=true;await switchMode('/clone');await waitUntil(async()=>!separated(await displays()));
  const duplicate=await displays();console.log('Verified Duplicate:',JSON.stringify(duplicate));
  const dialogs=[];page.on('dialog',async dialog=>{dialogs.push(dialog.message());await dialog.dismiss();});
  const opening=app.waitForEvent('window',{timeout:30000});
  const started=Date.now();await click('连接投影仪');const audience=await opening;
  await audience.waitForFunction(()=>document.querySelector('#screen')?.naturalWidth>0);
  await waitUntil(()=>app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().some(w=>/audience-window-/.test(w.webContents.getURL())&&w.isFullScreen())));
  const extended=await displays();assert.ok(separated(extended));
  const windows=await app.evaluate(({BrowserWindow,screen})=>BrowserWindow.getAllWindows().map(w=>({url:w.webContents.getURL(),bounds:w.getBounds(),fullscreen:w.isFullScreen(),display:screen.getDisplayMatching(w.getBounds()).id})));
  const teacherWindow=windows.find(w=>!w.url.includes('audience-window-')),audienceWindow=windows.find(w=>w.url.includes('audience-window-'));
  assert.notEqual(teacherWindow.display,audienceWindow.display);assert.ok(audienceWindow.fullscreen);
  const internal=extended.find(d=>d.internal);if(internal)assert.equal(teacherWindow.display,internal.id);
  await audience.screenshot({path:path.join(output,'audience-fullscreen.png')});
  const original=await audience.locator('#screen').getAttribute('src');await click('打开幻灯片总览');
  assert.equal(await audience.locator('#screen').getAttribute('src'),original);
  await click('查看第 2 张幻灯片');await audience.waitForFunction(old=>document.querySelector('#screen').getAttribute('src')!==old,original);
  const closed=audience.waitForEvent('close');await audience.keyboard.press('Escape').catch(e=>{if(!audience.isClosed())throw e;});await closed;
  const reopening=app.waitForEvent('window');await click('连接投影仪');const reopened=await reopening;
  await reopened.waitForFunction(()=>document.querySelector('#screen')?.naturalWidth>0);
  const ended=reopened.waitForEvent('close');await click('更多放映选项');await click('结束放映');await ended;
  assert.deepEqual(dialogs,[]);assert.deepEqual(errors,[]);
  const report={passed:true,executablePath,initial,duplicate,extended,windows,elapsedMs:Date.now()-started,privateSorter:true,slideSync:true,escape:true,reopen:true,endSlideshow:true,dialogs,errors};
  fs.writeFileSync(path.join(output,'hardware-results.json'),JSON.stringify(report,null,2));
  console.log('PASS: Duplicate → one Projector click → Extend; audience fullscreen on external display; teacher stays on internal display; private sorter, slide sync, Escape, reopen, end slideshow');
 }finally{try{await app.close();}finally{if(changed)await switchMode('/'+originalMode);}}
})().catch(e=>{console.error(e);process.exitCode=1;});
