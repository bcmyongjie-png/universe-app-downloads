import * as T from 'three';
// Schematic coma and two diffuse tails. Local +X is the anti-solar direction.
export function cometAtmosphere(w,length=8){
 const group=new T.Group();w.root.add(group);let seed=7183;const materials=[];
 const random=()=>{seed=(seed*1664525+1013904223)>>>0;return (seed+.5)/4294967296;};
 const normal=()=>Math.sqrt(-2*Math.log(random()))*Math.cos(random()*Math.PI*2);
 function cloud(count,kind){
  const p=[],c=[],s=[];
  for(let i=0;i<count;i++){
   const q=random();p.push(q,normal(),normal());
   if(kind===0){c.push(.014,.016,.016);s.push(.8+random()*.3);}
   else if(kind===1){c.push(.10,.09,.07);s.push(.55+random()*.5);}
   else{c.push(.022,.048,.085);s.push(.45+random()*.3);}
  }
  const points=w.addParticles(p,c,s);group.add(points);
  // Positions are seeds; culling must cover the shader's full streaming tail.
  points.geometry.boundingSphere=new T.Sphere(new T.Vector3(),length*1.5);
  const material=points.material;materials.push(material);
  material.uniforms={time:{value:0},activity:{value:1}};
  material.vertexShader=`attribute float aSize;varying vec3 vColor;varying float fade;
   uniform float time,activity;
   void main(){float q=fract(position.x+time*${kind===0?'.085':kind===1?'.033':'.075'});
    vec3 flow;
    ${kind===0?`float a=position.y*3.14159;float z=clamp(position.z*.45,-.98,.98);float h=sqrt(1.-z*z);
     flow=vec3(cos(a)*h,z,sin(a)*h)*(.1+q*.75);`:
     kind===1?`float spread=.055+q*.72;flow=vec3(q*${(length*.88).toFixed(4)},position.y*spread*.45,-q*q*${(length*.28).toFixed(4)}+position.z*spread);`:
     `float spread=.035+q*.19;flow=vec3(q*${length.toFixed(4)},position.y*spread,position.z*spread);`}
    fade=smoothstep(0.,.06,q)*pow(1.-q,${kind===0?'2.':'1.5'})*activity;
    vColor=color;vec4 mv=modelViewMatrix*vec4(flow,1.);
    gl_PointSize=clamp(aSize*250./-mv.z,1.,64.);gl_Position=projectionMatrix*mv;}`;
  material.fragmentShader=`varying vec3 vColor;varying float fade;void main(){
   float d=length(gl_PointCoord-.5)*2.;if(d>1.)discard;
   gl_FragColor=vec4(vColor,pow(1.-d,2.)*fade);}`;
 }
 cloud(600,0);cloud(2200,1);cloud(1000,2);
 group.userData.setActivity=value=>materials.forEach(m=>m.uniforms.activity.value=value);
 return group;
}
