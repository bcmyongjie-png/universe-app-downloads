const assert=require('node:assert/strict'),fs=require('fs'),crypto=require('crypto'),path=require('path');
const {createContentHandler}=require('./local-content.cjs');
(async()=>{for(const edition of ['teacher','student']){
 const root=path.join(__dirname,'web',edition),origin='https://universe-'+edition+'.local',handler=createContentHandler(root,origin);
 const assets=require('./'+edition+'-assets.json');
 for(const asset of assets){const b=fs.readFileSync(path.join(root,asset.path));assert.equal(b.length,asset.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),asset.sha256)}
 const video=assets.find(a=>a.path.endsWith('.mp4')),b=fs.readFileSync(path.join(root,video.path));
 for(const [range,start,end] of [['bytes=0-1023',0,1024],['bytes=-100',b.length-100,b.length],['bytes=1024-',1024,b.length]]){const r=await handler(new Request(origin+'/'+video.path,{headers:{range}}));assert.equal(r.status,206);assert.deepEqual(Buffer.from(await r.arrayBuffer()),b.subarray(start,end))}
 assert.equal((await handler(new Request(origin+'/'+video.path,{headers:{range:'bytes=999999999-'}}))).status,416);
 assert.equal((await handler(new Request('https://example.com/'))).status,403);
 assert.equal((await handler(new Request(origin+'/missing'))).status,404);
 const head=await handler(new Request(origin+'/'+video.path,{method:'HEAD'}));assert.equal(head.headers.get('content-length'),String(b.length));assert.equal((await head.text()).length,0);
 console.log(edition+': '+assets.length+' bundled assets verified; video ranges, seeking responses, HEAD, missing and foreign URLs pass');
}})().catch(e=>{console.error(e);process.exit(1)});
